.class public Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;
.super Ljava/lang/Object;
.source "TypeResolver.java"


# static fields
.field private static final TYPE_ARRAY:I = 0x14

.field private static final TYPE_BOOLEAN:I = 0x2

.field private static final TYPE_BYREF:I = 0x10

.field private static final TYPE_CHAR:I = 0x3

.field private static final TYPE_CLASS:I = 0x12

.field private static final TYPE_GENERICINST:I = 0x15

.field private static final TYPE_I:I = 0x18

.field private static final TYPE_I1:I = 0x4

.field private static final TYPE_I2:I = 0x6

.field private static final TYPE_I4:I = 0x8

.field private static final TYPE_I8:I = 0xa

.field private static final TYPE_MVAR:I = 0x1e

.field private static final TYPE_OBJECT:I = 0x1c

.field private static final TYPE_PTR:I = 0xf

.field private static final TYPE_R4:I = 0xc

.field private static final TYPE_R8:I = 0xd

.field private static final TYPE_STRING:I = 0xe

.field private static final TYPE_SZARRAY:I = 0x1d

.field private static final TYPE_TYPEDBYREF:I = 0x16

.field private static final TYPE_U:I = 0x19

.field private static final TYPE_U1:I = 0x5

.field private static final TYPE_U2:I = 0x7

.field private static final TYPE_U4:I = 0x9

.field private static final TYPE_U8:I = 0xb

.field private static final TYPE_VALUETYPE:I = 0x11

.field private static final TYPE_VAR:I = 0x13

.field private static final TYPE_VOID:I = 0x1


# instance fields
.field private final bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

.field private final elf:Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

.field private enumTypeDef:I

.field private handleMode:Z

.field private final metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

.field private final pointerSize:I

.field private searchReport:Ljava/lang/String;

.field private typeDefBase:J

.field private typesCount:I

.field private typesVA:J

.field private valueTypeTypeDef:I

.field private final version:D


# direct methods
.method public constructor <init>(Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;)V
    .locals 9

    .prologue
    .line 64
    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move-object v5, v1

    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    move-object v5, v1

    const-string v6, ""

    iput-object v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->searchReport:Ljava/lang/String;

    move-object v5, v1

    const/4 v6, -0x1

    int-to-long v6, v6

    iput-wide v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->typeDefBase:J

    move-object v5, v1

    const/4 v6, -0x1

    iput v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->enumTypeDef:I

    move-object v5, v1

    const/4 v6, -0x1

    iput v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->valueTypeTypeDef:I

    .line 65
    move-object v5, v1

    move-object v6, v2

    iput-object v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    .line 66
    move-object v5, v1

    move-object v6, v3

    invoke-virtual {v6}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->elf()Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

    move-result-object v6

    iput-object v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->elf:Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

    .line 67
    move-object v5, v1

    move-object v6, v1

    iget-object v6, v6, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->elf:Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

    invoke-virtual {v6}, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;->stream()Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    move-result-object v6

    iput-object v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    .line 68
    move-object v5, v1

    move-object v6, v3

    invoke-virtual {v6}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->pointerSize()I

    move-result v6

    iput v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->pointerSize:I

    .line 69
    move-object v5, v1

    move-object v6, v2

    invoke-virtual {v6}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->version()D

    move-result-wide v6

    iput-wide v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->version:D

    .line 70
    move-object v5, v1

    move-object v6, v3

    invoke-direct {v5, v6}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->findTypesArray(Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;)V

    .line 71
    move-object v5, v3

    move-object v6, v1

    iget-wide v6, v6, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->typesVA:J

    move-object v8, v1

    iget v8, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->typesCount:I

    invoke-virtual {v5, v6, v7, v8}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->setTypesArray(JI)V

    .line 72
    move-object v5, v1

    invoke-direct {v5}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->findWellKnownTypes()V

    return-void
.end method

.method private arrayName(JI)Ljava/lang/String;
    .locals 27

    .prologue
    .line 497
    move-object/from16 v3, p0

    move-wide/from16 v4, p1

    move/from16 v6, p3

    move-object/from16 v18, v3

    move-wide/from16 v19, v4

    invoke-direct/range {v18 .. v20}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->dataOf(J)J

    move-result-wide v18

    move-wide/from16 v8, v18

    .line 498
    move-object/from16 v18, v3

    move-object/from16 v0, v18

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->elf:Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

    move-object/from16 v18, v0

    move-wide/from16 v19, v8

    invoke-virtual/range {v18 .. v20}, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;->mapVirtualAddress(J)J

    move-result-wide v18

    move-wide/from16 v10, v18

    .line 499
    move-wide/from16 v18, v10

    const/16 v20, 0x0

    move/from16 v0, v20

    int-to-long v0, v0

    move-wide/from16 v20, v0

    cmp-long v18, v18, v20

    if-gez v18, :cond_0

    .line 500
    const-string v18, "object[]"

    move-object/from16 v3, v18

    .line 510
    :goto_0
    return-object v3

    .line 502
    :cond_0
    move-object/from16 v18, v3

    move-object/from16 v0, v18

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    move-object/from16 v18, v0

    move-wide/from16 v19, v10

    move-wide/from16 v0, v19

    long-to-int v0, v0

    move/from16 v19, v0

    invoke-virtual/range {v18 .. v19}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readPointerAt(I)J

    move-result-wide v18

    move-wide/from16 v12, v18

    .line 503
    move-object/from16 v18, v3

    move-object/from16 v0, v18

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    move-object/from16 v18, v0

    move-wide/from16 v19, v10

    move-object/from16 v21, v3

    move-object/from16 v0, v21

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->pointerSize:I

    move/from16 v21, v0

    move/from16 v0, v21

    int-to-long v0, v0

    move-wide/from16 v21, v0

    add-long v19, v19, v21

    move-wide/from16 v0, v19

    long-to-int v0, v0

    move/from16 v19, v0

    invoke-virtual/range {v18 .. v19}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readIntAt(I)I

    move-result v18

    move/from16 v14, v18

    .line 504
    new-instance v18, Ljava/lang/StringBuilder;

    move-object/from16 v25, v18

    move-object/from16 v18, v25

    move-object/from16 v19, v25

    move-object/from16 v20, v3

    move-wide/from16 v21, v12

    move/from16 v23, v6

    const/16 v24, 0x1

    add-int/lit8 v23, v23, 0x1

    invoke-virtual/range {v20 .. v23}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->nameOf(JI)Ljava/lang/String;

    move-result-object v20

    invoke-direct/range {v19 .. v20}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    move-object/from16 v15, v18

    .line 505
    move-object/from16 v18, v15

    const/16 v19, 0x5b

    invoke-virtual/range {v18 .. v19}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v18

    .line 506
    const/16 v18, 0x1

    move/from16 v16, v18

    :goto_1
    move/from16 v18, v16

    move/from16 v19, v14

    move/from16 v0, v18

    move/from16 v1, v19

    if-ge v0, v1, :cond_1

    move/from16 v18, v16

    const/16 v19, 0x20

    move/from16 v0, v18

    move/from16 v1, v19

    if-lt v0, v1, :cond_2

    .line 509
    :cond_1
    move-object/from16 v18, v15

    const/16 v19, 0x5d

    invoke-virtual/range {v18 .. v19}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v18

    .line 510
    move-object/from16 v18, v15

    invoke-virtual/range {v18 .. v18}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v18

    move-object/from16 v3, v18

    goto/16 :goto_0

    .line 507
    :cond_2
    move-object/from16 v18, v15

    const/16 v19, 0x2c

    invoke-virtual/range {v18 .. v19}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v18

    .line 506
    add-int/lit8 v16, v16, 0x1

    goto :goto_1
.end method

.method private baseName(JII)Ljava/lang/String;
    .locals 17

    .prologue
    .line 422
    move-object/from16 v1, p0

    move-wide/from16 v2, p1

    move/from16 v4, p3

    move/from16 v5, p4

    move v9, v4

    packed-switch v9, :pswitch_data_0

    .line 491
    :pswitch_0
    const-string v9, "object"

    move-object v1, v9

    :goto_0
    return-object v1

    .line 424
    :pswitch_1
    const-string v9, "void"

    move-object v1, v9

    goto :goto_0

    .line 426
    :pswitch_2
    const-string v9, "bool"

    move-object v1, v9

    goto :goto_0

    .line 428
    :pswitch_3
    const-string v9, "char"

    move-object v1, v9

    goto :goto_0

    .line 430
    :pswitch_4
    const-string v9, "sbyte"

    move-object v1, v9

    goto :goto_0

    .line 432
    :pswitch_5
    const-string v9, "byte"

    move-object v1, v9

    goto :goto_0

    .line 434
    :pswitch_6
    const-string v9, "short"

    move-object v1, v9

    goto :goto_0

    .line 436
    :pswitch_7
    const-string v9, "ushort"

    move-object v1, v9

    goto :goto_0

    .line 438
    :pswitch_8
    const-string v9, "int"

    move-object v1, v9

    goto :goto_0

    .line 440
    :pswitch_9
    const-string v9, "uint"

    move-object v1, v9

    goto :goto_0

    .line 442
    :pswitch_a
    const-string v9, "long"

    move-object v1, v9

    goto :goto_0

    .line 444
    :pswitch_b
    const-string v9, "ulong"

    move-object v1, v9

    goto :goto_0

    .line 446
    :pswitch_c
    const-string v9, "float"

    move-object v1, v9

    goto :goto_0

    .line 448
    :pswitch_d
    const-string v9, "double"

    move-object v1, v9

    goto :goto_0

    .line 450
    :pswitch_e
    const-string v9, "string"

    move-object v1, v9

    goto :goto_0

    .line 452
    :pswitch_f
    const-string v9, "object"

    move-object v1, v9

    goto :goto_0

    .line 454
    :pswitch_10
    const-string v9, "TypedReference"

    move-object v1, v9

    goto :goto_0

    .line 456
    :pswitch_11
    const-string v9, "IntPtr"

    move-object v1, v9

    goto :goto_0

    .line 458
    :pswitch_12
    const-string v9, "UIntPtr"

    move-object v1, v9

    goto :goto_0

    .line 462
    :pswitch_13
    move-object v9, v1

    move-wide v10, v2

    invoke-virtual {v9, v10, v11}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->typeDefIndexOf(J)I

    move-result v9

    move v7, v9

    .line 463
    move v9, v7

    const/4 v10, 0x0

    if-ge v9, v10, :cond_0

    .line 464
    const-string v9, "object"

    move-object v1, v9

    goto :goto_0

    .line 466
    :cond_0
    move-object v9, v1

    iget-object v9, v9, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    move-object v10, v1

    iget-object v10, v10, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    invoke-virtual {v10}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->types()[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;

    move-result-object v10

    move v11, v7

    aget-object v10, v10, v11

    invoke-virtual {v9, v10}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->fullName(Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;)Ljava/lang/String;

    move-result-object v9

    move-object v1, v9

    goto :goto_0

    .line 470
    :pswitch_14
    new-instance v9, Ljava/lang/StringBuffer;

    move-object v15, v9

    move-object v9, v15

    move-object v10, v15

    invoke-direct {v10}, Ljava/lang/StringBuffer;-><init>()V

    move-object v10, v1

    move-object v11, v1

    move-wide v12, v2

    invoke-direct {v11, v12, v13}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->dataOf(J)J

    move-result-wide v11

    move v13, v5

    const/4 v14, 0x1

    add-int/lit8 v13, v13, 0x1

    invoke-virtual {v10, v11, v12, v13}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->nameOf(JI)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    const-string v10, "*"

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v9

    move-object v1, v9

    goto/16 :goto_0

    .line 473
    :pswitch_15
    move-object v9, v1

    move-object v10, v1

    move-wide v11, v2

    invoke-direct {v10, v11, v12}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->dataOf(J)J

    move-result-wide v10

    move v12, v5

    const/4 v13, 0x1

    add-int/lit8 v12, v12, 0x1

    invoke-virtual {v9, v10, v11, v12}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->nameOf(JI)Ljava/lang/String;

    move-result-object v9

    move-object v1, v9

    goto/16 :goto_0

    .line 476
    :pswitch_16
    new-instance v9, Ljava/lang/StringBuffer;

    move-object v15, v9

    move-object v9, v15

    move-object v10, v15

    invoke-direct {v10}, Ljava/lang/StringBuffer;-><init>()V

    move-object v10, v1

    move-object v11, v1

    move-wide v12, v2

    invoke-direct {v11, v12, v13}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->dataOf(J)J

    move-result-wide v11

    move v13, v5

    const/4 v14, 0x1

    add-int/lit8 v13, v13, 0x1

    invoke-virtual {v10, v11, v12, v13}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->nameOf(JI)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    const-string v10, "[]"

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v9

    move-object v1, v9

    goto/16 :goto_0

    .line 479
    :pswitch_17
    move-object v9, v1

    move-wide v10, v2

    move v12, v5

    invoke-direct {v9, v10, v11, v12}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->arrayName(JI)Ljava/lang/String;

    move-result-object v9

    move-object v1, v9

    goto/16 :goto_0

    .line 482
    :pswitch_18
    move-object v9, v1

    move-wide v10, v2

    move v12, v5

    invoke-direct {v9, v10, v11, v12}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->genericName(JI)Ljava/lang/String;

    move-result-object v9

    move-object v1, v9

    goto/16 :goto_0

    .line 485
    :pswitch_19
    move-object v9, v1

    move-wide v10, v2

    const-string v12, "T"

    invoke-direct {v9, v10, v11, v12}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->genericParameterName(JLjava/lang/String;)Ljava/lang/String;

    move-result-object v9

    move-object v1, v9

    goto/16 :goto_0

    .line 488
    :pswitch_1a
    move-object v9, v1

    move-wide v10, v2

    const-string v12, "TMethod"

    invoke-direct {v9, v10, v11, v12}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->genericParameterName(JLjava/lang/String;)Ljava/lang/String;

    move-result-object v9

    move-object v1, v9

    goto/16 :goto_0

    .line 422
    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_4
        :pswitch_5
        :pswitch_6
        :pswitch_7
        :pswitch_8
        :pswitch_9
        :pswitch_a
        :pswitch_b
        :pswitch_c
        :pswitch_d
        :pswitch_e
        :pswitch_14
        :pswitch_15
        :pswitch_13
        :pswitch_13
        :pswitch_19
        :pswitch_17
        :pswitch_18
        :pswitch_10
        :pswitch_0
        :pswitch_11
        :pswitch_12
        :pswitch_0
        :pswitch_0
        :pswitch_f
        :pswitch_16
        :pswitch_1a
    .end packed-switch
.end method

.method private bitsOf(J)I
    .locals 13

    .prologue
    .line 98
    move-object v0, p0

    move-wide v1, p1

    move-object v7, v0

    iget-object v7, v7, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->elf:Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

    move-wide v8, v1

    invoke-virtual {v7, v8, v9}, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;->mapVirtualAddress(J)J

    move-result-wide v7

    move-wide v4, v7

    .line 99
    move-wide v7, v4

    const/4 v9, 0x0

    int-to-long v9, v9

    cmp-long v7, v7, v9

    if-gez v7, :cond_0

    .line 100
    const/4 v7, -0x1

    move v0, v7

    .line 102
    :goto_0
    return v0

    :cond_0
    move-object v7, v0

    iget-object v7, v7, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    move-wide v8, v4

    move-object v10, v0

    iget v10, v10, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->pointerSize:I

    int-to-long v10, v10

    add-long/2addr v8, v10

    long-to-int v8, v8

    invoke-virtual {v7, v8}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readIntAt(I)I

    move-result v7

    move v0, v7

    goto :goto_0
.end method

.method private dataOf(J)J
    .locals 13

    .prologue
    .line 90
    move-object v1, p0

    move-wide v2, p1

    move-object v8, v1

    iget-object v8, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->elf:Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

    move-wide v9, v2

    invoke-virtual {v8, v9, v10}, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;->mapVirtualAddress(J)J

    move-result-wide v8

    move-wide v5, v8

    .line 91
    move-wide v8, v5

    const/4 v10, 0x0

    int-to-long v10, v10

    cmp-long v8, v8, v10

    if-gez v8, :cond_0

    .line 92
    const/4 v8, -0x1

    int-to-long v8, v8

    move-wide v1, v8

    .line 94
    :goto_0
    return-wide v1

    :cond_0
    move-object v8, v1

    iget-object v8, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    move-wide v9, v5

    long-to-int v9, v9

    invoke-virtual {v8, v9}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readPointerAt(I)J

    move-result-wide v8

    move-wide v1, v8

    goto :goto_0
.end method

.method private findTypesArray(Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;)V
    .locals 30
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;",
            ")V"
        }
    .end annotation

    .prologue
    .line 143
    move-object/from16 v2, p0

    move-object/from16 v3, p1

    new-instance v15, Ljava/lang/StringBuilder;

    move-object/from16 v27, v15

    move-object/from16 v15, v27

    move-object/from16 v16, v27

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuilder;-><init>()V

    move-object v5, v15

    .line 144
    const/4 v15, 0x0

    move v6, v15

    .line 146
    const/4 v15, 0x0

    move v7, v15

    :goto_0
    move v15, v7

    const/16 v16, 0x10

    move/from16 v0, v16

    if-le v15, v0, :cond_0

    .line 167
    move v15, v6

    const/16 v16, 0x4b

    move/from16 v0, v16

    if-lt v15, v0, :cond_4

    .line 168
    move-object v15, v2

    move-object/from16 v16, v5

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v16

    move-object/from16 v0, v16

    iput-object v0, v15, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->searchReport:Ljava/lang/String;

    .line 184
    :goto_1
    return-void

    .line 147
    :cond_0
    move-object v15, v3

    move/from16 v16, v7

    invoke-virtual/range {v15 .. v16}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->registrationField(I)J

    move-result-wide v15

    move-wide v8, v15

    .line 148
    move-object v15, v3

    move/from16 v16, v7

    const/16 v17, 0x1

    add-int/lit8 v16, v16, 0x1

    invoke-virtual/range {v15 .. v16}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->registrationField(I)J

    move-result-wide v15

    move-wide v10, v15

    .line 149
    move-wide v15, v8

    const/16 v17, 0x0

    move/from16 v0, v17

    int-to-long v0, v0

    move-wide/from16 v17, v0

    cmp-long v15, v15, v17

    if-lez v15, :cond_1

    move-wide v15, v8

    const v17, 0x3d0900

    move/from16 v0, v17

    int-to-long v0, v0

    move-wide/from16 v17, v0

    cmp-long v15, v15, v17

    if-gtz v15, :cond_1

    move-object v15, v2

    iget-object v15, v15, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->elf:Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

    move-wide/from16 v16, v10

    invoke-virtual/range {v15 .. v17}, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;->isValidPointer(J)Z

    move-result v15

    if-nez v15, :cond_2

    .line 146
    :cond_1
    :goto_2
    move v15, v7

    const/16 v16, 0x2

    add-int/lit8 v15, v15, 0x2

    move v7, v15

    goto :goto_0

    .line 153
    :cond_2
    move-object v15, v2

    move-wide/from16 v16, v10

    move-wide/from16 v18, v8

    move-wide/from16 v0, v18

    long-to-int v0, v0

    move/from16 v18, v0

    invoke-direct/range {v15 .. v18}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->scoreTypesArray(JI)[J

    move-result-object v15

    move-object v12, v15

    .line 154
    move-object v15, v12

    const/16 v16, 0x0

    aget-wide v15, v15, v16

    long-to-int v15, v15

    move v13, v15

    .line 155
    move v15, v13

    move/from16 v16, v6

    move/from16 v0, v16

    if-le v15, v0, :cond_1

    .line 156
    move v15, v13

    move v6, v15

    .line 157
    move-object v15, v2

    move-wide/from16 v16, v10

    move-wide/from16 v0, v16

    iput-wide v0, v15, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->typesVA:J

    .line 158
    move-object v15, v2

    move-wide/from16 v16, v8

    move-wide/from16 v0, v16

    long-to-int v0, v0

    move/from16 v16, v0

    move/from16 v0, v16

    iput v0, v15, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->typesCount:I

    .line 159
    move-object v15, v2

    move-object/from16 v16, v12

    const/16 v17, 0x1

    aget-wide v16, v16, v17

    const/16 v18, 0x0

    move/from16 v0, v18

    int-to-long v0, v0

    move-wide/from16 v18, v0

    cmp-long v16, v16, v18

    if-nez v16, :cond_3

    const/16 v16, 0x0

    :goto_3
    move/from16 v0, v16

    iput-boolean v0, v15, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->handleMode:Z

    .line 160
    move-object v15, v2

    move-object/from16 v16, v12

    const/16 v17, 0x2

    aget-wide v16, v16, v17

    move-wide/from16 v0, v16

    iput-wide v0, v15, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->typeDefBase:J

    .line 161
    move-object v15, v5

    const/16 v16, 0x0

    invoke-virtual/range {v15 .. v16}, Ljava/lang/StringBuilder;->setLength(I)V

    .line 162
    move-object v15, v5

    new-instance v16, Ljava/lang/StringBuffer;

    move-object/from16 v27, v16

    move-object/from16 v16, v27

    move-object/from16 v17, v27

    invoke-direct/range {v17 .. v17}, Ljava/lang/StringBuffer;-><init>()V

    const-string v17, "types \u043d\u0430\u0439\u0434\u0435\u043d \u043d\u0430 \u043f\u043e\u0437\u0438\u0446\u0438\u0438 %d: 0x%X, \u0437\u0430\u043f\u0438\u0441\u0435\u0439 %d,"

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v16

    const-string v17, " \u0441\u0445\u043e\u0434\u0438\u043c\u043e\u0441\u0442\u044c %d%%"

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v16

    const/16 v17, 0x4

    move/from16 v0, v17

    new-array v0, v0, [Ljava/lang/Object;

    move-object/from16 v17, v0

    move-object/from16 v27, v17

    move-object/from16 v17, v27

    move-object/from16 v18, v27

    const/16 v19, 0x0

    move/from16 v20, v7

    new-instance v21, Ljava/lang/Integer;

    move/from16 v27, v20

    move-object/from16 v28, v21

    move-object/from16 v20, v28

    move/from16 v21, v27

    move-object/from16 v22, v28

    move/from16 v27, v21

    move-object/from16 v28, v22

    move-object/from16 v21, v28

    move/from16 v22, v27

    invoke-direct/range {v21 .. v22}, Ljava/lang/Integer;-><init>(I)V

    aput-object v20, v18, v19

    move-object/from16 v27, v17

    move-object/from16 v17, v27

    move-object/from16 v18, v27

    const/16 v19, 0x1

    move-wide/from16 v20, v10

    new-instance v22, Ljava/lang/Long;

    move-wide/from16 v27, v20

    move-object/from16 v29, v22

    move-object/from16 v20, v29

    move-wide/from16 v21, v27

    move-object/from16 v23, v29

    move-wide/from16 v27, v21

    move-object/from16 v29, v23

    move-object/from16 v21, v29

    move-wide/from16 v22, v27

    move-object/from16 v24, v29

    invoke-direct/range {v21 .. v23}, Ljava/lang/Long;-><init>(J)V

    aput-object v20, v18, v19

    move-object/from16 v27, v17

    move-object/from16 v17, v27

    move-object/from16 v18, v27

    const/16 v19, 0x2

    move-wide/from16 v20, v8

    new-instance v22, Ljava/lang/Long;

    move-wide/from16 v27, v20

    move-object/from16 v29, v22

    move-object/from16 v20, v29

    move-wide/from16 v21, v27

    move-object/from16 v23, v29

    move-wide/from16 v27, v21

    move-object/from16 v29, v23

    move-object/from16 v21, v29

    move-wide/from16 v22, v27

    move-object/from16 v24, v29

    invoke-direct/range {v21 .. v23}, Ljava/lang/Long;-><init>(J)V

    aput-object v20, v18, v19

    move-object/from16 v27, v17

    move-object/from16 v17, v27

    move-object/from16 v18, v27

    const/16 v19, 0x3

    move/from16 v20, v13

    new-instance v21, Ljava/lang/Integer;

    move/from16 v27, v20

    move-object/from16 v28, v21

    move-object/from16 v20, v28

    move/from16 v21, v27

    move-object/from16 v22, v28

    move/from16 v27, v21

    move-object/from16 v28, v22

    move-object/from16 v21, v28

    move/from16 v22, v27

    invoke-direct/range {v21 .. v22}, Ljava/lang/Integer;-><init>(I)V

    aput-object v20, v18, v19

    invoke-static/range {v16 .. v17}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v16

    invoke-virtual/range {v15 .. v16}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v15

    goto/16 :goto_2

    .line 159
    :cond_3
    const/16 v16, 0x1

    goto/16 :goto_3

    .line 173
    :cond_4
    move-object v15, v2

    invoke-direct {v15}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->scanForTypesArray()[J

    move-result-object v15

    move-object v7, v15

    .line 174
    move-object v15, v7

    if-eqz v15, :cond_6

    .line 175
    move-object v15, v2

    move-object/from16 v16, v7

    const/16 v17, 0x0

    aget-wide v16, v16, v17

    move-wide/from16 v0, v16

    iput-wide v0, v15, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->typesVA:J

    .line 176
    move-object v15, v2

    move-object/from16 v16, v7

    const/16 v17, 0x1

    aget-wide v16, v16, v17

    move-wide/from16 v0, v16

    long-to-int v0, v0

    move/from16 v16, v0

    move/from16 v0, v16

    iput v0, v15, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->typesCount:I

    .line 177
    move-object v15, v2

    move-object/from16 v16, v7

    const/16 v17, 0x2

    aget-wide v16, v16, v17

    const/16 v18, 0x0

    move/from16 v0, v18

    int-to-long v0, v0

    move-wide/from16 v18, v0

    cmp-long v16, v16, v18

    if-nez v16, :cond_5

    const/16 v16, 0x0

    :goto_4
    move/from16 v0, v16

    iput-boolean v0, v15, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->handleMode:Z

    .line 178
    move-object v15, v2

    move-object/from16 v16, v7

    const/16 v17, 0x3

    aget-wide v16, v16, v17

    move-wide/from16 v0, v16

    iput-wide v0, v15, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->typeDefBase:J

    .line 179
    move-object v15, v2

    new-instance v16, Ljava/lang/StringBuffer;

    move-object/from16 v27, v16

    move-object/from16 v16, v27

    move-object/from16 v17, v27

    invoke-direct/range {v17 .. v17}, Ljava/lang/StringBuffer;-><init>()V

    const-string v17, "types \u043d\u0430\u0439\u0434\u0435\u043d \u043f\u0435\u0440\u0435\u0431\u043e\u0440\u043e\u043c \u043f\u043e \u043e\u0431\u0440\u0430\u0437\u0443: 0x%X,"

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v16

    const-string v17, " \u0437\u0430\u043f\u0438\u0441\u0435\u0439 %d, \u0441\u0445\u043e\u0434\u0438\u043c\u043e\u0441\u0442\u044c %d%%"

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v16

    const/16 v17, 0x3

    move/from16 v0, v17

    new-array v0, v0, [Ljava/lang/Object;

    move-object/from16 v17, v0

    move-object/from16 v27, v17

    move-object/from16 v17, v27

    move-object/from16 v18, v27

    const/16 v19, 0x0

    move-object/from16 v20, v7

    const/16 v21, 0x0

    aget-wide v20, v20, v21

    new-instance v22, Ljava/lang/Long;

    move-wide/from16 v27, v20

    move-object/from16 v29, v22

    move-object/from16 v20, v29

    move-wide/from16 v21, v27

    move-object/from16 v23, v29

    move-wide/from16 v27, v21

    move-object/from16 v29, v23

    move-object/from16 v21, v29

    move-wide/from16 v22, v27

    move-object/from16 v24, v29

    invoke-direct/range {v21 .. v23}, Ljava/lang/Long;-><init>(J)V

    aput-object v20, v18, v19

    move-object/from16 v27, v17

    move-object/from16 v17, v27

    move-object/from16 v18, v27

    const/16 v19, 0x1

    move-object/from16 v20, v7

    const/16 v21, 0x1

    aget-wide v20, v20, v21

    new-instance v22, Ljava/lang/Long;

    move-wide/from16 v27, v20

    move-object/from16 v29, v22

    move-object/from16 v20, v29

    move-wide/from16 v21, v27

    move-object/from16 v23, v29

    move-wide/from16 v27, v21

    move-object/from16 v29, v23

    move-object/from16 v21, v29

    move-wide/from16 v22, v27

    move-object/from16 v24, v29

    invoke-direct/range {v21 .. v23}, Ljava/lang/Long;-><init>(J)V

    aput-object v20, v18, v19

    move-object/from16 v27, v17

    move-object/from16 v17, v27

    move-object/from16 v18, v27

    const/16 v19, 0x2

    move-object/from16 v20, v7

    const/16 v21, 0x4

    aget-wide v20, v20, v21

    new-instance v22, Ljava/lang/Long;

    move-wide/from16 v27, v20

    move-object/from16 v29, v22

    move-object/from16 v20, v29

    move-wide/from16 v21, v27

    move-object/from16 v23, v29

    move-wide/from16 v27, v21

    move-object/from16 v29, v23

    move-object/from16 v21, v29

    move-wide/from16 v22, v27

    move-object/from16 v24, v29

    invoke-direct/range {v21 .. v23}, Ljava/lang/Long;-><init>(J)V

    aput-object v20, v18, v19

    invoke-static/range {v16 .. v17}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v16

    move-object/from16 v0, v16

    iput-object v0, v15, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->searchReport:Ljava/lang/String;

    .line 184
    :goto_5
    goto/16 :goto_1

    .line 177
    :cond_5
    const/16 v16, 0x1

    goto/16 :goto_4

    .line 181
    :cond_6
    move v15, v6

    const/16 v16, 0x0

    move/from16 v0, v16

    if-le v15, v0, :cond_7

    .line 182
    move-object v15, v2

    new-instance v16, Ljava/lang/StringBuffer;

    move-object/from16 v27, v16

    move-object/from16 v16, v27

    move-object/from16 v17, v27

    invoke-direct/range {v17 .. v17}, Ljava/lang/StringBuffer;-><init>()V

    move-object/from16 v17, v5

    invoke-virtual/range {v17 .. v17}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v17

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v16

    const-string v17, "  (\u0441\u043b\u0430\u0431\u0430\u044f \u0441\u0445\u043e\u0434\u0438\u043c\u043e\u0441\u0442\u044c)"

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v16

    move-object/from16 v0, v16

    iput-object v0, v15, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->searchReport:Ljava/lang/String;

    goto :goto_5

    .line 184
    :cond_7
    move-object v15, v2

    const-string v16, "types \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d \u043d\u0438 \u0432 \u0441\u0442\u0440\u0443\u043a\u0442\u0443\u0440\u0435, \u043d\u0438 \u043f\u0435\u0440\u0435\u0431\u043e\u0440\u043e\u043c"

    move-object/from16 v0, v16

    iput-object v0, v15, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->searchReport:Ljava/lang/String;

    goto :goto_5
.end method

.method private findWellKnownTypes()V
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 358
    move-object v0, p0

    move-object v7, v0

    iget-object v7, v7, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    invoke-virtual {v7}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->types()[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;

    move-result-object v7

    move-object v2, v7

    .line 359
    const/4 v7, 0x0

    move v3, v7

    :goto_0
    move v7, v3

    move-object v8, v2

    array-length v8, v8

    if-lt v7, v8, :cond_0

    .line 361
    :goto_1
    return-void

    .line 360
    :cond_0
    move-object v7, v0

    iget v7, v7, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->enumTypeDef:I

    const/4 v8, 0x0

    if-lt v7, v8, :cond_1

    move-object v7, v0

    iget v7, v7, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->valueTypeTypeDef:I

    const/4 v8, 0x0

    if-lt v7, v8, :cond_1

    .line 361
    goto :goto_1

    .line 363
    :cond_1
    move-object v7, v0

    iget-object v7, v7, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    move-object v8, v2

    move v9, v3

    aget-object v8, v8, v9

    iget v8, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->namespaceIndex:I

    invoke-virtual {v7, v8}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->getString(I)Ljava/lang/String;

    move-result-object v7

    move-object v4, v7

    .line 364
    const-string v7, "System"

    move-object v8, v4

    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_3

    .line 359
    :cond_2
    :goto_2
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    .line 367
    :cond_3
    move-object v7, v0

    iget-object v7, v7, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    move-object v8, v2

    move v9, v3

    aget-object v8, v8, v9

    iget v8, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->nameIndex:I

    invoke-virtual {v7, v8}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->getString(I)Ljava/lang/String;

    move-result-object v7

    move-object v5, v7

    .line 368
    move-object v7, v0

    iget v7, v7, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->enumTypeDef:I

    const/4 v8, 0x0

    if-ge v7, v8, :cond_4

    const-string v7, "Enum"

    move-object v8, v5

    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_4

    .line 369
    move-object v7, v0

    move v8, v3

    iput v8, v7, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->enumTypeDef:I

    goto :goto_2

    .line 370
    :cond_4
    move-object v7, v0

    iget v7, v7, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->valueTypeTypeDef:I

    const/4 v8, 0x0

    if-ge v7, v8, :cond_2

    const-string v7, "ValueType"

    move-object v8, v5

    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_2

    .line 371
    move-object v7, v0

    move v8, v3

    iput v8, v7, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->valueTypeTypeDef:I

    goto :goto_2
.end method

.method private genericName(JI)Ljava/lang/String;
    .locals 41

    .prologue
    .line 518
    move-object/from16 v3, p0

    move-wide/from16 v4, p1

    move/from16 v6, p3

    move-object/from16 v30, v3

    move-wide/from16 v31, v4

    invoke-direct/range {v30 .. v32}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->dataOf(J)J

    move-result-wide v30

    move-wide/from16 v8, v30

    .line 519
    move-object/from16 v30, v3

    move-object/from16 v0, v30

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->elf:Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

    move-object/from16 v30, v0

    move-wide/from16 v31, v8

    invoke-virtual/range {v30 .. v32}, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;->mapVirtualAddress(J)J

    move-result-wide v30

    move-wide/from16 v10, v30

    .line 520
    move-wide/from16 v30, v10

    const/16 v32, 0x0

    move/from16 v0, v32

    int-to-long v0, v0

    move-wide/from16 v32, v0

    cmp-long v30, v30, v32

    if-gez v30, :cond_0

    .line 521
    const-string v30, "object"

    move-object/from16 v3, v30

    .line 557
    :goto_0
    return-object v3

    .line 524
    :cond_0
    move-object/from16 v30, v3

    move-object/from16 v0, v30

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    move-object/from16 v30, v0

    move-wide/from16 v31, v10

    move-wide/from16 v0, v31

    long-to-int v0, v0

    move/from16 v31, v0

    invoke-virtual/range {v30 .. v31}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readPointerAt(I)J

    move-result-wide v30

    move-wide/from16 v12, v30

    .line 525
    const-string v30, "object"

    move-object/from16 v14, v30

    .line 526
    move-object/from16 v30, v3

    move-object/from16 v0, v30

    iget-boolean v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->handleMode:Z

    move/from16 v30, v0

    if-eqz v30, :cond_3

    move-object/from16 v30, v3

    move-wide/from16 v31, v12

    invoke-direct/range {v30 .. v32}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->indexFromHandle(J)I

    move-result v30

    :goto_1
    move/from16 v15, v30

    .line 527
    move/from16 v30, v15

    const/16 v31, 0x0

    move/from16 v0, v30

    move/from16 v1, v31

    if-lt v0, v1, :cond_1

    move/from16 v30, v15

    move-object/from16 v31, v3

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    move-object/from16 v31, v0

    invoke-virtual/range {v31 .. v31}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->types()[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;

    move-result-object v31

    move-object/from16 v0, v31

    array-length v0, v0

    move/from16 v31, v0

    move/from16 v0, v30

    move/from16 v1, v31

    if-ge v0, v1, :cond_1

    .line 528
    move-object/from16 v30, v3

    move-object/from16 v0, v30

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    move-object/from16 v30, v0

    move-object/from16 v31, v3

    move-object/from16 v0, v31

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    move-object/from16 v31, v0

    invoke-virtual/range {v31 .. v31}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->types()[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;

    move-result-object v31

    move/from16 v32, v15

    aget-object v31, v31, v32

    invoke-virtual/range {v30 .. v31}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->fullName(Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;)Ljava/lang/String;

    move-result-object v30

    move-object/from16 v14, v30

    .line 530
    :cond_1
    move-object/from16 v30, v14

    const/16 v31, 0x60

    invoke-virtual/range {v30 .. v31}, Ljava/lang/String;->indexOf(I)I

    move-result v30

    move/from16 v16, v30

    .line 531
    move/from16 v30, v16

    const/16 v31, 0x0

    move/from16 v0, v30

    move/from16 v1, v31

    if-le v0, v1, :cond_2

    .line 532
    move-object/from16 v30, v14

    const/16 v31, 0x0

    move/from16 v32, v16

    invoke-virtual/range {v30 .. v32}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v30

    move-object/from16 v14, v30

    .line 535
    :cond_2
    move-object/from16 v30, v3

    move-object/from16 v0, v30

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    move-object/from16 v30, v0

    move-wide/from16 v31, v10

    move-object/from16 v33, v3

    move-object/from16 v0, v33

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->pointerSize:I

    move/from16 v33, v0

    move/from16 v0, v33

    int-to-long v0, v0

    move-wide/from16 v33, v0

    add-long v31, v31, v33

    move-wide/from16 v0, v31

    long-to-int v0, v0

    move/from16 v31, v0

    invoke-virtual/range {v30 .. v31}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readPointerAt(I)J

    move-result-wide v30

    move-wide/from16 v17, v30

    .line 536
    move-object/from16 v30, v3

    move-object/from16 v0, v30

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->elf:Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

    move-object/from16 v30, v0

    move-wide/from16 v31, v17

    invoke-virtual/range {v30 .. v32}, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;->mapVirtualAddress(J)J

    move-result-wide v30

    move-wide/from16 v19, v30

    .line 537
    move-wide/from16 v30, v19

    const/16 v32, 0x0

    move/from16 v0, v32

    int-to-long v0, v0

    move-wide/from16 v32, v0

    cmp-long v30, v30, v32

    if-gez v30, :cond_4

    .line 538
    move-object/from16 v30, v14

    move-object/from16 v3, v30

    goto/16 :goto_0

    .line 526
    :cond_3
    move-wide/from16 v30, v12

    move-wide/from16 v0, v30

    long-to-int v0, v0

    move/from16 v30, v0

    goto/16 :goto_1

    .line 540
    :cond_4
    move-object/from16 v30, v3

    move-object/from16 v0, v30

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    move-object/from16 v30, v0

    move-wide/from16 v31, v19

    move-wide/from16 v0, v31

    long-to-int v0, v0

    move/from16 v31, v0

    invoke-virtual/range {v30 .. v31}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readPointerAt(I)J

    move-result-wide v30

    move-wide/from16 v21, v30

    .line 541
    move-object/from16 v30, v3

    move-object/from16 v0, v30

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    move-object/from16 v30, v0

    move-wide/from16 v31, v19

    move-object/from16 v33, v3

    move-object/from16 v0, v33

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->pointerSize:I

    move/from16 v33, v0

    move/from16 v0, v33

    int-to-long v0, v0

    move-wide/from16 v33, v0

    add-long v31, v31, v33

    move-wide/from16 v0, v31

    long-to-int v0, v0

    move/from16 v31, v0

    invoke-virtual/range {v30 .. v31}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readPointerAt(I)J

    move-result-wide v30

    move-wide/from16 v23, v30

    .line 542
    move-object/from16 v30, v3

    move-object/from16 v0, v30

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->elf:Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

    move-object/from16 v30, v0

    move-wide/from16 v31, v23

    invoke-virtual/range {v30 .. v32}, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;->mapVirtualAddress(J)J

    move-result-wide v30

    move-wide/from16 v25, v30

    .line 543
    move-wide/from16 v30, v21

    const/16 v32, 0x0

    move/from16 v0, v32

    int-to-long v0, v0

    move-wide/from16 v32, v0

    cmp-long v30, v30, v32

    if-lez v30, :cond_5

    move-wide/from16 v30, v21

    const/16 v32, 0x20

    move/from16 v0, v32

    int-to-long v0, v0

    move-wide/from16 v32, v0

    cmp-long v30, v30, v32

    if-gtz v30, :cond_5

    move-wide/from16 v30, v25

    const/16 v32, 0x0

    move/from16 v0, v32

    int-to-long v0, v0

    move-wide/from16 v32, v0

    cmp-long v30, v30, v32

    if-gez v30, :cond_6

    .line 544
    :cond_5
    move-object/from16 v30, v14

    move-object/from16 v3, v30

    goto/16 :goto_0

    .line 547
    :cond_6
    new-instance v30, Ljava/lang/StringBuilder;

    move-object/from16 v40, v30

    move-object/from16 v30, v40

    move-object/from16 v31, v40

    move-object/from16 v32, v14

    invoke-direct/range {v31 .. v32}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    move-object/from16 v27, v30

    .line 548
    move-object/from16 v30, v27

    const/16 v31, 0x3c

    invoke-virtual/range {v30 .. v31}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v30

    .line 549
    const/16 v30, 0x0

    move/from16 v28, v30

    :goto_2
    move/from16 v30, v28

    move/from16 v0, v30

    int-to-long v0, v0

    move-wide/from16 v30, v0

    move-wide/from16 v32, v21

    cmp-long v30, v30, v32

    if-ltz v30, :cond_7

    .line 556
    move-object/from16 v30, v27

    const/16 v31, 0x3e

    invoke-virtual/range {v30 .. v31}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v30

    .line 557
    move-object/from16 v30, v27

    invoke-virtual/range {v30 .. v30}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v30

    move-object/from16 v3, v30

    goto/16 :goto_0

    .line 550
    :cond_7
    move/from16 v30, v28

    const/16 v31, 0x0

    move/from16 v0, v30

    move/from16 v1, v31

    if-le v0, v1, :cond_8

    .line 551
    move-object/from16 v30, v27

    const-string v31, ", "

    invoke-virtual/range {v30 .. v31}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v30

    .line 553
    :cond_8
    move-object/from16 v30, v27

    move-object/from16 v31, v3

    move-object/from16 v32, v3

    move-object/from16 v0, v32

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    move-object/from16 v32, v0

    move-wide/from16 v33, v25

    move/from16 v35, v28

    move/from16 v0, v35

    int-to-long v0, v0

    move-wide/from16 v35, v0

    move-object/from16 v37, v3

    move-object/from16 v0, v37

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->pointerSize:I

    move/from16 v37, v0

    move/from16 v0, v37

    int-to-long v0, v0

    move-wide/from16 v37, v0

    mul-long v35, v35, v37

    add-long v33, v33, v35

    move-wide/from16 v0, v33

    long-to-int v0, v0

    move/from16 v33, v0

    invoke-virtual/range {v32 .. v33}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readPointerAt(I)J

    move-result-wide v32

    move/from16 v34, v6

    const/16 v35, 0x1

    add-int/lit8 v34, v34, 0x1

    invoke-virtual/range {v31 .. v34}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->nameOf(JI)Ljava/lang/String;

    move-result-object v31

    invoke-virtual/range {v30 .. v31}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v30

    .line 549
    add-int/lit8 v28, v28, 0x1

    goto :goto_2
.end method

.method private genericParameterName(JLjava/lang/String;)Ljava/lang/String;
    .locals 21

    .prologue
    .line 575
    move-object/from16 v2, p0

    move-wide/from16 v3, p1

    move-object/from16 v5, p3

    move-object/from16 v16, v2

    move-wide/from16 v17, v3

    invoke-direct/range {v16 .. v18}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->dataOf(J)J

    move-result-wide v16

    move-wide/from16 v7, v16

    .line 576
    move-wide/from16 v16, v7

    const/16 v18, 0x0

    move/from16 v0, v18

    int-to-long v0, v0

    move-wide/from16 v18, v0

    cmp-long v16, v16, v18

    if-gez v16, :cond_0

    .line 577
    move-object/from16 v16, v5

    move-object/from16 v2, v16

    .line 591
    :goto_0
    return-object v2

    .line 579
    :cond_0
    move-object/from16 v16, v2

    move-object/from16 v0, v16

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    move-object/from16 v16, v0

    invoke-virtual/range {v16 .. v16}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->header()Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;

    move-result-object v16

    const-string v17, "genericParameters"

    invoke-virtual/range {v16 .. v17}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;->count(Ljava/lang/String;)I

    move-result v16

    move/from16 v9, v16

    .line 580
    move-object/from16 v16, v2

    move-object/from16 v0, v16

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    move-object/from16 v16, v0

    invoke-virtual/range {v16 .. v16}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->header()Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;

    move-result-object v16

    const-string v17, "genericParameters"

    invoke-virtual/range {v16 .. v17}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;->offset(Ljava/lang/String;)I

    move-result v16

    move/from16 v10, v16

    .line 581
    move/from16 v16, v9

    const/16 v17, 0x10

    div-int/lit8 v16, v16, 0x10

    move/from16 v11, v16

    .line 582
    const/16 v16, -0x1

    move/from16 v12, v16

    .line 583
    move-wide/from16 v16, v7

    move/from16 v18, v11

    move/from16 v0, v18

    int-to-long v0, v0

    move-wide/from16 v18, v0

    cmp-long v16, v16, v18

    if-gez v16, :cond_1

    .line 584
    move-wide/from16 v16, v7

    move-wide/from16 v0, v16

    long-to-int v0, v0

    move/from16 v16, v0

    move/from16 v12, v16

    .line 586
    :cond_1
    move/from16 v16, v12

    const/16 v17, 0x0

    move/from16 v0, v16

    move/from16 v1, v17

    if-ge v0, v1, :cond_2

    .line 587
    move-object/from16 v16, v5

    move-object/from16 v2, v16

    goto :goto_0

    .line 589
    :cond_2
    move-object/from16 v16, v2

    move-object/from16 v0, v16

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    move-object/from16 v16, v0

    invoke-virtual/range {v16 .. v16}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->stream()Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    move-result-object v16

    move/from16 v17, v10

    move/from16 v18, v12

    const/16 v19, 0x10

    mul-int/lit8 v18, v18, 0x10

    add-int v17, v17, v18

    const/16 v18, 0x4

    add-int/lit8 v17, v17, 0x4

    invoke-virtual/range {v16 .. v17}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readIntAt(I)I

    move-result v16

    move/from16 v13, v16

    .line 590
    move-object/from16 v16, v2

    move-object/from16 v0, v16

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    move-object/from16 v16, v0

    move/from16 v17, v13

    invoke-virtual/range {v16 .. v17}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->getString(I)Ljava/lang/String;

    move-result-object v16

    move-object/from16 v14, v16

    .line 591
    move-object/from16 v16, v14

    invoke-virtual/range {v16 .. v16}, Ljava/lang/String;->length()I

    move-result v16

    const/16 v17, 0x0

    move/from16 v0, v16

    move/from16 v1, v17

    if-le v0, v1, :cond_3

    move-object/from16 v16, v14

    :goto_1
    move-object/from16 v2, v16

    goto/16 :goto_0

    :cond_3
    move-object/from16 v16, v5

    goto :goto_1
.end method

.method private indexFromHandle(J)I
    .locals 15

    .prologue
    .line 561
    move-object v0, p0

    move-wide/from16 v1, p1

    move-object v10, v0

    iget-wide v10, v10, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->typeDefBase:J

    const/4 v12, 0x0

    int-to-long v12, v12

    cmp-long v10, v10, v12

    if-gez v10, :cond_0

    .line 562
    const/4 v10, -0x1

    move v0, v10

    .line 570
    :goto_0
    return v0

    .line 564
    :cond_0
    move-wide v10, v1

    move-object v12, v0

    iget-wide v12, v12, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->typeDefBase:J

    sub-long/2addr v10, v12

    move-wide v4, v10

    .line 565
    move-object v10, v0

    iget-object v10, v10, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    invoke-virtual {v10}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->typeStructSize()I

    move-result v10

    move v6, v10

    .line 566
    move-wide v10, v4

    const/4 v12, 0x0

    int-to-long v12, v12

    cmp-long v10, v10, v12

    if-ltz v10, :cond_1

    move-wide v10, v4

    move v12, v6

    int-to-long v12, v12

    rem-long/2addr v10, v12

    const/4 v12, 0x0

    int-to-long v12, v12

    cmp-long v10, v10, v12

    if-eqz v10, :cond_2

    .line 567
    :cond_1
    const/4 v10, -0x1

    move v0, v10

    goto :goto_0

    .line 569
    :cond_2
    move-wide v10, v4

    move v12, v6

    int-to-long v12, v12

    div-long/2addr v10, v12

    move-wide v7, v10

    .line 570
    move-wide v10, v7

    move-object v12, v0

    iget-object v12, v12, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    invoke-virtual {v12}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->types()[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;

    move-result-object v12

    array-length v12, v12

    int-to-long v12, v12

    cmp-long v10, v10, v12

    if-gez v10, :cond_3

    move-wide v10, v7

    long-to-int v10, v10

    :goto_1
    move v0, v10

    goto :goto_0

    :cond_3
    const/4 v10, -0x1

    goto :goto_1
.end method

.method private isByref(J)Z
    .locals 11

    .prologue
    .line 116
    move-object v0, p0

    move-wide v1, p1

    move-object v6, v0

    move-wide v7, v1

    invoke-direct {v6, v7, v8}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->bitsOf(J)I

    move-result v6

    move v4, v6

    .line 117
    move v6, v4

    const/4 v7, 0x0

    if-ge v6, v7, :cond_0

    .line 118
    const/4 v6, 0x0

    move v0, v6

    .line 121
    :goto_0
    return v0

    :cond_0
    move-object v6, v0

    iget-wide v6, v6, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->version:D

    const/16 v8, 0x1b

    int-to-double v8, v8

    cmpl-double v6, v6, v8

    if-ltz v6, :cond_2

    move v6, v4

    const/high16 v7, 0x20000000

    and-int/2addr v6, v7

    const/4 v7, 0x0

    if-ne v6, v7, :cond_1

    const/4 v6, 0x0

    :goto_1
    move v0, v6

    goto :goto_0

    :cond_1
    const/4 v6, 0x1

    goto :goto_1

    :cond_2
    move v6, v4

    const/high16 v7, 0x40000000    # 2.0f

    and-int/2addr v6, v7

    const/4 v7, 0x0

    if-ne v6, v7, :cond_3

    const/4 v6, 0x0

    goto :goto_1

    :cond_3
    const/4 v6, 0x1

    goto :goto_1
.end method

.method private measureArray(JJ)I
    .locals 21

    .prologue
    .line 253
    move-object/from16 v3, p0

    move-wide/from16 v4, p1

    move-wide/from16 v6, p3

    const/16 v16, 0x0

    move/from16 v9, v16

    .line 254
    move-wide/from16 v16, v4

    move-wide/from16 v10, v16

    .line 255
    :goto_0
    move-wide/from16 v16, v10

    move-object/from16 v18, v3

    move-object/from16 v0, v18

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->pointerSize:I

    move/from16 v18, v0

    move/from16 v0, v18

    int-to-long v0, v0

    move-wide/from16 v18, v0

    add-long v16, v16, v18

    move-wide/from16 v18, v6

    cmp-long v16, v16, v18

    if-gtz v16, :cond_0

    move/from16 v16, v9

    const v17, 0x3d0900

    move/from16 v0, v16

    move/from16 v1, v17

    if-lt v0, v1, :cond_1

    .line 267
    :cond_0
    :goto_1
    move/from16 v16, v9

    move/from16 v3, v16

    return v3

    .line 256
    :cond_1
    move-object/from16 v16, v3

    move-object/from16 v0, v16

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    move-object/from16 v16, v0

    move-wide/from16 v17, v10

    move-wide/from16 v0, v17

    long-to-int v0, v0

    move/from16 v17, v0

    invoke-virtual/range {v16 .. v17}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readPointerAt(I)J

    move-result-wide v16

    move-wide/from16 v12, v16

    .line 257
    move-object/from16 v16, v3

    move-object/from16 v0, v16

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->elf:Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

    move-object/from16 v16, v0

    move-wide/from16 v17, v12

    invoke-virtual/range {v16 .. v18}, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;->isValidPointer(J)Z

    move-result v16

    if-nez v16, :cond_2

    .line 258
    goto :goto_1

    .line 260
    :cond_2
    move-object/from16 v16, v3

    move-wide/from16 v17, v12

    invoke-virtual/range {v16 .. v18}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->kindOf(J)I

    move-result v16

    move/from16 v14, v16

    .line 261
    move/from16 v16, v14

    const/16 v17, 0x0

    move/from16 v0, v16

    move/from16 v1, v17

    if-le v0, v1, :cond_3

    move/from16 v16, v14

    const/16 v17, 0x21

    move/from16 v0, v16

    move/from16 v1, v17

    if-le v0, v1, :cond_4

    .line 262
    :cond_3
    goto :goto_1

    .line 264
    :cond_4
    add-int/lit8 v9, v9, 0x1

    .line 265
    move-wide/from16 v16, v10

    move-object/from16 v18, v3

    move-object/from16 v0, v18

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->pointerSize:I

    move/from16 v18, v0

    move/from16 v0, v18

    int-to-long v0, v0

    move-wide/from16 v18, v0

    add-long v16, v16, v18

    move-wide/from16 v10, v16

    goto/16 :goto_0
.end method

.method private scanForTypesArray()[J
    .locals 33

    .prologue
    .line 198
    move-object/from16 v2, p0

    move-object/from16 v26, v2

    move-object/from16 v0, v26

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    move-object/from16 v26, v0

    invoke-virtual/range {v26 .. v26}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->types()[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;

    move-result-object v26

    move-object/from16 v4, v26

    .line 199
    const/16 v26, -0x1

    move/from16 v5, v26

    .line 200
    move-object/from16 v26, v4

    move-object/from16 v0, v26

    array-length v0, v0

    move/from16 v26, v0

    const/16 v27, 0x2

    div-int/lit8 v26, v26, 0x2

    move/from16 v6, v26

    :goto_0
    move/from16 v26, v6

    move-object/from16 v27, v4

    move-object/from16 v0, v27

    array-length v0, v0

    move/from16 v27, v0

    move/from16 v0, v26

    move/from16 v1, v27

    if-lt v0, v1, :cond_0

    .line 206
    :goto_1
    move/from16 v26, v5

    const/16 v27, 0x0

    move/from16 v0, v26

    move/from16 v1, v27

    if-ge v0, v1, :cond_2

    .line 207
    const/16 v26, 0x0

    check-cast v26, [J

    move-object/from16 v2, v26

    .line 248
    :goto_2
    return-object v2

    .line 201
    :cond_0
    move-object/from16 v26, v4

    move/from16 v27, v6

    aget-object v26, v26, v27

    move-object/from16 v0, v26

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->byvalTypeIndex:I

    move/from16 v26, v0

    const/16 v27, 0x0

    move/from16 v0, v26

    move/from16 v1, v27

    if-le v0, v1, :cond_1

    move-object/from16 v26, v4

    move/from16 v27, v6

    aget-object v26, v26, v27

    move-object/from16 v0, v26

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->fieldCount:I

    move/from16 v26, v0

    const/16 v27, 0x0

    move/from16 v0, v26

    move/from16 v1, v27

    if-le v0, v1, :cond_1

    .line 202
    move/from16 v26, v6

    move/from16 v5, v26

    .line 203
    goto :goto_1

    .line 200
    :cond_1
    add-int/lit8 v6, v6, 0x1

    goto :goto_0

    .line 209
    :cond_2
    move-object/from16 v26, v4

    move/from16 v27, v5

    aget-object v26, v26, v27

    move-object/from16 v0, v26

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->byvalTypeIndex:I

    move/from16 v26, v0

    move/from16 v0, v26

    int-to-long v0, v0

    move-wide/from16 v26, v0

    move-object/from16 v28, v2

    move-object/from16 v0, v28

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->pointerSize:I

    move/from16 v28, v0

    move/from16 v0, v28

    int-to-long v0, v0

    move-wide/from16 v28, v0

    mul-long v26, v26, v28

    move-wide/from16 v6, v26

    .line 211
    const/16 v26, 0x0

    move/from16 v8, v26

    :goto_3
    move/from16 v26, v8

    move-object/from16 v27, v2

    move-object/from16 v0, v27

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->elf:Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

    move-object/from16 v27, v0

    invoke-virtual/range {v27 .. v27}, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;->segments()Ljava/util/List;

    move-result-object v27

    invoke-interface/range {v27 .. v27}, Ljava/util/List;->size()I

    move-result v27

    move/from16 v0, v26

    move/from16 v1, v27

    if-lt v0, v1, :cond_3

    .line 248
    const/16 v26, 0x0

    check-cast v26, [J

    move-object/from16 v2, v26

    goto :goto_2

    .line 212
    :cond_3
    move-object/from16 v26, v2

    move-object/from16 v0, v26

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->elf:Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

    move-object/from16 v26, v0

    invoke-virtual/range {v26 .. v26}, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;->segments()Ljava/util/List;

    move-result-object v26

    move/from16 v27, v8

    invoke-interface/range {v26 .. v27}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v26

    check-cast v26, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile$Segment;

    move-object/from16 v9, v26

    .line 213
    move-object/from16 v26, v9

    move-object/from16 v0, v26

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile$Segment;->type:I

    move/from16 v26, v0

    const/16 v27, 0x1

    move/from16 v0, v26

    move/from16 v1, v27

    if-eq v0, v1, :cond_5

    .line 211
    :cond_4
    add-int/lit8 v8, v8, 0x1

    goto :goto_3

    .line 216
    :cond_5
    move-object/from16 v26, v9

    move-object/from16 v0, v26

    iget-wide v0, v0, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile$Segment;->offset:J

    move-wide/from16 v26, v0

    move-object/from16 v28, v2

    move-object/from16 v0, v28

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->pointerSize:I

    move/from16 v28, v0

    move/from16 v0, v28

    int-to-long v0, v0

    move-wide/from16 v28, v0

    add-long v26, v26, v28

    const/16 v28, 0x1

    move/from16 v0, v28

    int-to-long v0, v0

    move-wide/from16 v28, v0

    sub-long v26, v26, v28

    move-object/from16 v28, v2

    move-object/from16 v0, v28

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->pointerSize:I

    move/from16 v28, v0

    move/from16 v0, v28

    int-to-long v0, v0

    move-wide/from16 v28, v0

    div-long v26, v26, v28

    move-object/from16 v28, v2

    move-object/from16 v0, v28

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->pointerSize:I

    move/from16 v28, v0

    move/from16 v0, v28

    int-to-long v0, v0

    move-wide/from16 v28, v0

    mul-long v26, v26, v28

    move-wide/from16 v10, v26

    .line 217
    move-object/from16 v26, v2

    move-object/from16 v0, v26

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    move-object/from16 v26, v0

    invoke-virtual/range {v26 .. v26}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->size()I

    move-result v26

    move/from16 v0, v26

    int-to-long v0, v0

    move-wide/from16 v26, v0

    move-object/from16 v28, v9

    move-object/from16 v0, v28

    iget-wide v0, v0, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile$Segment;->offset:J

    move-wide/from16 v28, v0

    move-object/from16 v30, v9

    move-object/from16 v0, v30

    iget-wide v0, v0, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile$Segment;->fileSize:J

    move-wide/from16 v30, v0

    add-long v28, v28, v30

    invoke-static/range {v26 .. v29}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v26

    move-wide/from16 v12, v26

    .line 219
    move-wide/from16 v26, v10

    move-wide/from16 v14, v26

    :goto_4
    move-wide/from16 v26, v14

    move-wide/from16 v28, v6

    add-long v26, v26, v28

    move-object/from16 v28, v2

    move-object/from16 v0, v28

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->pointerSize:I

    move/from16 v28, v0

    move/from16 v0, v28

    int-to-long v0, v0

    move-wide/from16 v28, v0

    add-long v26, v26, v28

    move-wide/from16 v28, v12

    cmp-long v26, v26, v28

    if-gtz v26, :cond_4

    .line 220
    move-object/from16 v26, v2

    move-object/from16 v0, v26

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    move-object/from16 v26, v0

    move-wide/from16 v27, v14

    move-wide/from16 v29, v6

    add-long v27, v27, v29

    move-wide/from16 v0, v27

    long-to-int v0, v0

    move/from16 v27, v0

    invoke-virtual/range {v26 .. v27}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readPointerAt(I)J

    move-result-wide v26

    move-wide/from16 v16, v26

    .line 221
    move-object/from16 v26, v2

    move-object/from16 v0, v26

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->elf:Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

    move-object/from16 v26, v0

    move-wide/from16 v27, v16

    invoke-virtual/range {v26 .. v28}, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;->isValidPointer(J)Z

    move-result v26

    if-nez v26, :cond_7

    .line 219
    :cond_6
    :goto_5
    move-wide/from16 v26, v14

    move-object/from16 v28, v2

    move-object/from16 v0, v28

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->pointerSize:I

    move/from16 v28, v0

    move/from16 v0, v28

    int-to-long v0, v0

    move-wide/from16 v28, v0

    add-long v26, v26, v28

    move-wide/from16 v14, v26

    goto :goto_4

    .line 224
    :cond_7
    move-object/from16 v26, v2

    move-wide/from16 v27, v16

    invoke-virtual/range {v26 .. v28}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->kindOf(J)I

    move-result v26

    move/from16 v18, v26

    .line 225
    move/from16 v26, v18

    const/16 v27, 0x12

    move/from16 v0, v26

    move/from16 v1, v27

    if-eq v0, v1, :cond_8

    move/from16 v26, v18

    const/16 v27, 0x11

    move/from16 v0, v26

    move/from16 v1, v27

    if-eq v0, v1, :cond_8

    .line 226
    goto :goto_5

    .line 228
    :cond_8
    move-object/from16 v26, v2

    move-wide/from16 v27, v16

    invoke-direct/range {v26 .. v28}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->dataOf(J)J

    move-result-wide v26

    move-wide/from16 v19, v26

    .line 229
    move-wide/from16 v26, v19

    move/from16 v28, v5

    move/from16 v0, v28

    int-to-long v0, v0

    move-wide/from16 v28, v0

    cmp-long v26, v26, v28

    if-eqz v26, :cond_9

    move-wide/from16 v26, v19

    move/from16 v28, v5

    move/from16 v0, v28

    int-to-long v0, v0

    move-wide/from16 v28, v0

    move-object/from16 v30, v2

    move-object/from16 v0, v30

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    move-object/from16 v30, v0

    invoke-virtual/range {v30 .. v30}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->typeStructSize()I

    move-result v30

    move/from16 v0, v30

    int-to-long v0, v0

    move-wide/from16 v30, v0

    mul-long v28, v28, v30

    sub-long v26, v26, v28

    const/16 v28, 0x0

    move/from16 v0, v28

    int-to-long v0, v0

    move-wide/from16 v28, v0

    cmp-long v26, v26, v28

    if-gtz v26, :cond_9

    .line 231
    goto :goto_5

    .line 234
    :cond_9
    move-object/from16 v26, v2

    move-object/from16 v0, v26

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->elf:Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

    move-object/from16 v26, v0

    move-wide/from16 v27, v14

    invoke-virtual/range {v26 .. v28}, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;->mapFileOffset(J)J

    move-result-wide v26

    move-wide/from16 v21, v26

    .line 235
    move-wide/from16 v26, v21

    const/16 v28, 0x0

    move/from16 v0, v28

    int-to-long v0, v0

    move-wide/from16 v28, v0

    cmp-long v26, v26, v28

    if-gez v26, :cond_a

    .line 236
    goto/16 :goto_5

    .line 238
    :cond_a
    move-object/from16 v26, v2

    move-wide/from16 v27, v14

    move-wide/from16 v29, v12

    invoke-direct/range {v26 .. v30}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->measureArray(JJ)I

    move-result v26

    move/from16 v23, v26

    .line 239
    move/from16 v26, v23

    move-object/from16 v27, v4

    move/from16 v28, v5

    aget-object v27, v27, v28

    move-object/from16 v0, v27

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->byvalTypeIndex:I

    move/from16 v27, v0

    move/from16 v0, v26

    move/from16 v1, v27

    if-gt v0, v1, :cond_b

    .line 240
    goto/16 :goto_5

    .line 242
    :cond_b
    move-object/from16 v26, v2

    move-wide/from16 v27, v21

    move/from16 v29, v23

    invoke-direct/range {v26 .. v29}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->scoreTypesArray(JI)[J

    move-result-object v26

    move-object/from16 v24, v26

    .line 243
    move-object/from16 v26, v24

    const/16 v27, 0x0

    aget-wide v26, v26, v27

    const/16 v28, 0x4b

    move/from16 v0, v28

    int-to-long v0, v0

    move-wide/from16 v28, v0

    cmp-long v26, v26, v28

    if-ltz v26, :cond_6

    .line 244
    const/16 v26, 0x5

    move/from16 v0, v26

    new-array v0, v0, [J

    move-object/from16 v26, v0

    move-object/from16 v32, v26

    move-object/from16 v26, v32

    move-object/from16 v27, v32

    const/16 v28, 0x0

    move-wide/from16 v29, v21

    aput-wide v29, v27, v28

    move-object/from16 v32, v26

    move-object/from16 v26, v32

    move-object/from16 v27, v32

    const/16 v28, 0x1

    move/from16 v29, v23

    move/from16 v0, v29

    int-to-long v0, v0

    move-wide/from16 v29, v0

    aput-wide v29, v27, v28

    move-object/from16 v32, v26

    move-object/from16 v26, v32

    move-object/from16 v27, v32

    const/16 v28, 0x2

    move-object/from16 v29, v24

    const/16 v30, 0x1

    aget-wide v29, v29, v30

    aput-wide v29, v27, v28

    move-object/from16 v32, v26

    move-object/from16 v26, v32

    move-object/from16 v27, v32

    const/16 v28, 0x3

    move-object/from16 v29, v24

    const/16 v30, 0x2

    aget-wide v29, v29, v30

    aput-wide v29, v27, v28

    move-object/from16 v32, v26

    move-object/from16 v26, v32

    move-object/from16 v27, v32

    const/16 v28, 0x4

    move-object/from16 v29, v24

    const/16 v30, 0x0

    aget-wide v29, v29, v30

    aput-wide v29, v27, v28

    move-object/from16 v2, v26

    goto/16 :goto_2
.end method

.method private scoreTypesArray(JI)[J
    .locals 37

    .prologue
    .line 276
    move-object/from16 v3, p0

    move-wide/from16 v4, p1

    move/from16 v6, p3

    move-object/from16 v30, v3

    move-object/from16 v0, v30

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    move-object/from16 v30, v0

    invoke-virtual/range {v30 .. v30}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->types()[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;

    move-result-object v30

    move-object/from16 v8, v30

    .line 277
    move-object/from16 v30, v3

    move-object/from16 v0, v30

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->elf:Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

    move-object/from16 v30, v0

    move-wide/from16 v31, v4

    invoke-virtual/range {v30 .. v32}, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;->mapVirtualAddress(J)J

    move-result-wide v30

    move-wide/from16 v9, v30

    .line 278
    move-wide/from16 v30, v9

    const/16 v32, 0x0

    move/from16 v0, v32

    int-to-long v0, v0

    move-wide/from16 v32, v0

    cmp-long v30, v30, v32

    if-ltz v30, :cond_0

    move-object/from16 v30, v8

    move-object/from16 v0, v30

    array-length v0, v0

    move/from16 v30, v0

    const/16 v31, 0x0

    move/from16 v0, v30

    move/from16 v1, v31

    if-ne v0, v1, :cond_1

    .line 279
    :cond_0
    const/16 v30, 0x3

    move/from16 v0, v30

    new-array v0, v0, [J

    move-object/from16 v30, v0

    move-object/from16 v36, v30

    move-object/from16 v30, v36

    move-object/from16 v31, v36

    const/16 v32, 0x0

    const/16 v33, 0x0

    move/from16 v0, v33

    int-to-long v0, v0

    move-wide/from16 v33, v0

    aput-wide v33, v31, v32

    move-object/from16 v36, v30

    move-object/from16 v30, v36

    move-object/from16 v31, v36

    const/16 v32, 0x1

    const/16 v33, 0x0

    move/from16 v0, v33

    int-to-long v0, v0

    move-wide/from16 v33, v0

    aput-wide v33, v31, v32

    move-object/from16 v36, v30

    move-object/from16 v30, v36

    move-object/from16 v31, v36

    const/16 v32, 0x2

    const/16 v33, -0x1

    move/from16 v0, v33

    int-to-long v0, v0

    move-wide/from16 v33, v0

    aput-wide v33, v31, v32

    move-object/from16 v3, v30

    .line 333
    :goto_0
    return-object v3

    .line 282
    :cond_1
    move-object/from16 v30, v8

    move-object/from16 v0, v30

    array-length v0, v0

    move/from16 v30, v0

    const/16 v31, 0x40

    invoke-static/range {v30 .. v31}, Ljava/lang/Math;->min(II)I

    move-result v30

    move/from16 v11, v30

    .line 283
    const/16 v30, 0x1

    move-object/from16 v31, v8

    move-object/from16 v0, v31

    array-length v0, v0

    move/from16 v31, v0

    move/from16 v32, v11

    div-int v31, v31, v32

    invoke-static/range {v30 .. v31}, Ljava/lang/Math;->max(II)I

    move-result v30

    move/from16 v12, v30

    .line 285
    const/16 v30, 0x0

    move/from16 v13, v30

    .line 286
    const/16 v30, 0x0

    move/from16 v14, v30

    .line 287
    const/16 v30, 0x0

    move/from16 v15, v30

    .line 288
    const/16 v30, -0x1

    move/from16 v0, v30

    int-to-long v0, v0

    move-wide/from16 v30, v0

    move-wide/from16 v16, v30

    .line 290
    const/16 v30, 0x0

    move/from16 v18, v30

    :goto_1
    move/from16 v30, v18

    move-object/from16 v31, v8

    move-object/from16 v0, v31

    array-length v0, v0

    move/from16 v31, v0

    move/from16 v0, v30

    move/from16 v1, v31

    if-ge v0, v1, :cond_2

    move/from16 v30, v13

    move/from16 v31, v11

    move/from16 v0, v30

    move/from16 v1, v31

    if-lt v0, v1, :cond_3

    .line 326
    :cond_2
    const/16 v30, 0x2

    const/16 v31, 0x8

    move-object/from16 v32, v8

    move-object/from16 v0, v32

    array-length v0, v0

    move/from16 v32, v0

    const/16 v33, 0x4

    div-int/lit8 v32, v32, 0x4

    invoke-static/range {v31 .. v32}, Ljava/lang/Math;->min(II)I

    move-result v31

    invoke-static/range {v30 .. v31}, Ljava/lang/Math;->max(II)I

    move-result v30

    move/from16 v18, v30

    .line 327
    move/from16 v30, v13

    move/from16 v31, v18

    move/from16 v0, v30

    move/from16 v1, v31

    if-ge v0, v1, :cond_c

    .line 328
    const/16 v30, 0x3

    move/from16 v0, v30

    new-array v0, v0, [J

    move-object/from16 v30, v0

    move-object/from16 v36, v30

    move-object/from16 v30, v36

    move-object/from16 v31, v36

    const/16 v32, 0x0

    const/16 v33, 0x0

    move/from16 v0, v33

    int-to-long v0, v0

    move-wide/from16 v33, v0

    aput-wide v33, v31, v32

    move-object/from16 v36, v30

    move-object/from16 v30, v36

    move-object/from16 v31, v36

    const/16 v32, 0x1

    const/16 v33, 0x0

    move/from16 v0, v33

    int-to-long v0, v0

    move-wide/from16 v33, v0

    aput-wide v33, v31, v32

    move-object/from16 v36, v30

    move-object/from16 v30, v36

    move-object/from16 v31, v36

    const/16 v32, 0x2

    const/16 v33, -0x1

    move/from16 v0, v33

    int-to-long v0, v0

    move-wide/from16 v33, v0

    aput-wide v33, v31, v32

    move-object/from16 v3, v30

    goto/16 :goto_0

    .line 291
    :cond_3
    move-object/from16 v30, v8

    move/from16 v31, v18

    aget-object v30, v30, v31

    move-object/from16 v0, v30

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->byvalTypeIndex:I

    move/from16 v30, v0

    move/from16 v19, v30

    .line 292
    move/from16 v30, v19

    const/16 v31, 0x0

    move/from16 v0, v30

    move/from16 v1, v31

    if-lt v0, v1, :cond_4

    move/from16 v30, v19

    move/from16 v31, v6

    move/from16 v0, v30

    move/from16 v1, v31

    if-lt v0, v1, :cond_5

    .line 290
    :cond_4
    :goto_2
    move/from16 v30, v18

    move/from16 v31, v12

    add-int v30, v30, v31

    move/from16 v18, v30

    goto/16 :goto_1

    .line 295
    :cond_5
    move-wide/from16 v30, v9

    move/from16 v32, v19

    move/from16 v0, v32

    int-to-long v0, v0

    move-wide/from16 v32, v0

    move-object/from16 v34, v3

    move-object/from16 v0, v34

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->pointerSize:I

    move/from16 v34, v0

    move/from16 v0, v34

    int-to-long v0, v0

    move-wide/from16 v34, v0

    mul-long v32, v32, v34

    add-long v30, v30, v32

    move-wide/from16 v20, v30

    .line 296
    move-wide/from16 v30, v20

    move-object/from16 v32, v3

    move-object/from16 v0, v32

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->pointerSize:I

    move/from16 v32, v0

    move/from16 v0, v32

    int-to-long v0, v0

    move-wide/from16 v32, v0

    add-long v30, v30, v32

    move-object/from16 v32, v3

    move-object/from16 v0, v32

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    move-object/from16 v32, v0

    invoke-virtual/range {v32 .. v32}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->size()I

    move-result v32

    move/from16 v0, v32

    int-to-long v0, v0

    move-wide/from16 v32, v0

    cmp-long v30, v30, v32

    if-lez v30, :cond_6

    .line 297
    goto :goto_2

    .line 299
    :cond_6
    move-object/from16 v30, v3

    move-object/from16 v0, v30

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    move-object/from16 v30, v0

    move-wide/from16 v31, v20

    move-wide/from16 v0, v31

    long-to-int v0, v0

    move/from16 v31, v0

    invoke-virtual/range {v30 .. v31}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readPointerAt(I)J

    move-result-wide v30

    move-wide/from16 v22, v30

    .line 300
    move-object/from16 v30, v3

    move-object/from16 v0, v30

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->elf:Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

    move-object/from16 v30, v0

    move-wide/from16 v31, v22

    invoke-virtual/range {v30 .. v32}, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;->isValidPointer(J)Z

    move-result v30

    if-nez v30, :cond_7

    .line 301
    goto :goto_2

    .line 303
    :cond_7
    move-object/from16 v30, v3

    move-wide/from16 v31, v22

    invoke-virtual/range {v30 .. v32}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->kindOf(J)I

    move-result v30

    move/from16 v24, v30

    .line 304
    move/from16 v30, v24

    const/16 v31, 0x12

    move/from16 v0, v30

    move/from16 v1, v31

    if-eq v0, v1, :cond_8

    move/from16 v30, v24

    const/16 v31, 0x11

    move/from16 v0, v30

    move/from16 v1, v31

    if-eq v0, v1, :cond_8

    .line 305
    goto/16 :goto_2

    .line 307
    :cond_8
    move-object/from16 v30, v3

    move-wide/from16 v31, v22

    invoke-direct/range {v30 .. v32}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->dataOf(J)J

    move-result-wide v30

    move-wide/from16 v25, v30

    .line 308
    move-wide/from16 v30, v25

    const/16 v32, 0x0

    move/from16 v0, v32

    int-to-long v0, v0

    move-wide/from16 v32, v0

    cmp-long v30, v30, v32

    if-gez v30, :cond_9

    .line 309
    goto/16 :goto_2

    .line 311
    :cond_9
    add-int/lit8 v13, v13, 0x1

    .line 313
    move-wide/from16 v30, v25

    move/from16 v32, v18

    move/from16 v0, v32

    int-to-long v0, v0

    move-wide/from16 v32, v0

    cmp-long v30, v30, v32

    if-nez v30, :cond_a

    .line 314
    add-int/lit8 v14, v14, 0x1

    .line 315
    goto/16 :goto_2

    .line 317
    :cond_a
    move-wide/from16 v30, v25

    move/from16 v32, v18

    move/from16 v0, v32

    int-to-long v0, v0

    move-wide/from16 v32, v0

    move-object/from16 v34, v3

    move-object/from16 v0, v34

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    move-object/from16 v34, v0

    invoke-virtual/range {v34 .. v34}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->typeStructSize()I

    move-result v34

    move/from16 v0, v34

    int-to-long v0, v0

    move-wide/from16 v34, v0

    mul-long v32, v32, v34

    sub-long v30, v30, v32

    move-wide/from16 v27, v30

    .line 318
    move-wide/from16 v30, v16

    const/16 v32, 0x0

    move/from16 v0, v32

    int-to-long v0, v0

    move-wide/from16 v32, v0

    cmp-long v30, v30, v32

    if-gez v30, :cond_b

    .line 319
    move-wide/from16 v30, v27

    move-wide/from16 v16, v30

    .line 321
    :cond_b
    move-wide/from16 v30, v27

    move-wide/from16 v32, v16

    cmp-long v30, v30, v32

    if-nez v30, :cond_4

    .line 322
    add-int/lit8 v15, v15, 0x1

    goto/16 :goto_2

    .line 330
    :cond_c
    move/from16 v30, v14

    move/from16 v31, v15

    move/from16 v0, v30

    move/from16 v1, v31

    if-lt v0, v1, :cond_d

    .line 331
    const/16 v30, 0x3

    move/from16 v0, v30

    new-array v0, v0, [J

    move-object/from16 v30, v0

    move-object/from16 v36, v30

    move-object/from16 v30, v36

    move-object/from16 v31, v36

    const/16 v32, 0x0

    move/from16 v33, v14

    const/16 v34, 0x64

    mul-int/lit8 v33, v33, 0x64

    move/from16 v34, v13

    div-int v33, v33, v34

    move/from16 v0, v33

    int-to-long v0, v0

    move-wide/from16 v33, v0

    aput-wide v33, v31, v32

    move-object/from16 v36, v30

    move-object/from16 v30, v36

    move-object/from16 v31, v36

    const/16 v32, 0x1

    const/16 v33, 0x0

    move/from16 v0, v33

    int-to-long v0, v0

    move-wide/from16 v33, v0

    aput-wide v33, v31, v32

    move-object/from16 v36, v30

    move-object/from16 v30, v36

    move-object/from16 v31, v36

    const/16 v32, 0x2

    const/16 v33, -0x1

    move/from16 v0, v33

    int-to-long v0, v0

    move-wide/from16 v33, v0

    aput-wide v33, v31, v32

    move-object/from16 v3, v30

    goto/16 :goto_0

    .line 333
    :cond_d
    const/16 v30, 0x3

    move/from16 v0, v30

    new-array v0, v0, [J

    move-object/from16 v30, v0

    move-object/from16 v36, v30

    move-object/from16 v30, v36

    move-object/from16 v31, v36

    const/16 v32, 0x0

    move/from16 v33, v15

    const/16 v34, 0x64

    mul-int/lit8 v33, v33, 0x64

    move/from16 v34, v13

    div-int v33, v33, v34

    move/from16 v0, v33

    int-to-long v0, v0

    move-wide/from16 v33, v0

    aput-wide v33, v31, v32

    move-object/from16 v36, v30

    move-object/from16 v30, v36

    move-object/from16 v31, v36

    const/16 v32, 0x1

    const/16 v33, 0x1

    move/from16 v0, v33

    int-to-long v0, v0

    move-wide/from16 v33, v0

    aput-wide v33, v31, v32

    move-object/from16 v36, v30

    move-object/from16 v30, v36

    move-object/from16 v31, v36

    const/16 v32, 0x2

    move-wide/from16 v33, v16

    aput-wide v33, v31, v32

    move-object/from16 v3, v30

    goto/16 :goto_0
.end method


# virtual methods
.method public attrsOf(J)I
    .locals 11

    .prologue
    .line 111
    move-object v1, p0

    move-wide v2, p1

    move-object v7, v1

    move-wide v8, v2

    invoke-direct {v7, v8, v9}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->bitsOf(J)I

    move-result v7

    move v5, v7

    .line 112
    move v7, v5

    const/4 v8, 0x0

    if-ge v7, v8, :cond_0

    const/4 v7, 0x0

    :goto_0
    move v1, v7

    return v1

    :cond_0
    move v7, v5

    const v8, 0xffff

    and-int/2addr v7, v8

    goto :goto_0
.end method

.method public attrsOfTypeIndex(I)I
    .locals 10

    .prologue
    .line 125
    move-object v0, p0

    move v1, p1

    move-object v6, v0

    move v7, v1

    invoke-virtual {v6, v7}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->typeVA(I)J

    move-result-wide v6

    move-wide v3, v6

    .line 126
    move-wide v6, v3

    const/4 v8, 0x0

    int-to-long v8, v8

    cmp-long v6, v6, v8

    if-gtz v6, :cond_0

    const/4 v6, 0x0

    :goto_0
    move v0, v6

    return v0

    :cond_0
    move-object v6, v0

    move-wide v7, v3

    invoke-virtual {v6, v7, v8}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->attrsOf(J)I

    move-result v6

    goto :goto_0
.end method

.method public describe()Ljava/lang/String;
    .locals 21

    .prologue
    .line 595
    move-object/from16 v0, p0

    new-instance v8, Ljava/lang/StringBuilder;

    move-object/from16 v18, v8

    move-object/from16 v8, v18

    move-object/from16 v9, v18

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    move-object v2, v8

    .line 596
    move-object v8, v2

    move-object v9, v0

    iget-object v9, v9, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->searchReport:Ljava/lang/String;

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const/16 v9, 0xa

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v8

    .line 597
    move-object v8, v2

    const-string v9, "\u0420\u0435\u0436\u0438\u043c data: "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    move-object v9, v0

    iget-boolean v9, v9, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->handleMode:Z

    if-eqz v9, :cond_0

    const-string v9, "\u0443\u043a\u0430\u0437\u0430\u0442\u0435\u043b\u0438 (\u0431\u0430\u0437\u0430 typeDefinitions 0x%X)"

    const/4 v10, 0x1

    new-array v10, v10, [Ljava/lang/Object;

    move-object/from16 v18, v10

    move-object/from16 v10, v18

    move-object/from16 v11, v18

    const/4 v12, 0x0

    move-object v13, v0

    iget-wide v13, v13, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->typeDefBase:J

    new-instance v15, Ljava/lang/Long;

    move-wide/from16 v18, v13

    move-object/from16 v20, v15

    move-object/from16 v13, v20

    move-wide/from16 v14, v18

    move-object/from16 v16, v20

    move-wide/from16 v18, v14

    move-object/from16 v20, v16

    move-object/from16 v14, v20

    move-wide/from16 v15, v18

    move-object/from16 v17, v20

    invoke-direct/range {v14 .. v16}, Ljava/lang/Long;-><init>(J)V

    aput-object v13, v11, v12

    invoke-static {v9, v10}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v9

    :goto_0
    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const/16 v9, 0xa

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v8

    .line 600
    move-object v8, v2

    const-string v9, "  System.Enum: "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    move-object v9, v0

    iget v9, v9, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->enumTypeDef:I

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v9, ", System.ValueType: "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    move-object v9, v0

    iget v9, v9, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->valueTypeTypeDef:I

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v8

    const/16 v9, 0xa

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v8

    .line 604
    move-object v8, v0

    iget-object v8, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    invoke-virtual {v8}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->types()[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;

    move-result-object v8

    move-object v3, v8

    .line 605
    const/4 v8, 0x0

    move v4, v8

    :goto_1
    move v8, v4

    move-object v9, v3

    array-length v9, v9

    if-lt v8, v9, :cond_1

    .line 618
    :goto_2
    move-object v8, v2

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    move-object v0, v8

    return-object v0

    .line 597
    :cond_0
    const-string v9, "\u0438\u043d\u0434\u0435\u043a\u0441\u044b"

    goto :goto_0

    .line 606
    :cond_1
    move-object v8, v3

    move v9, v4

    aget-object v8, v8, v9

    iget v8, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->fieldCount:I

    const/4 v9, 0x2

    if-ge v8, v9, :cond_2

    .line 605
    add-int/lit8 v4, v4, 0x1

    goto :goto_1

    .line 609
    :cond_2
    move-object v8, v2

    const-string v9, "  \u043f\u0440\u043e\u0431\u0430 -> "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    move-object v9, v0

    iget-object v9, v9, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    move-object v10, v3

    move v11, v4

    aget-object v10, v10, v11

    invoke-virtual {v9, v10}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->fullName(Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v9, ": "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    .line 610
    const/4 v8, 0x0

    move v5, v8

    :goto_3
    move v8, v5

    const/4 v9, 0x3

    move-object v10, v3

    move v11, v4

    aget-object v10, v10, v11

    iget v10, v10, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->fieldCount:I

    invoke-static {v9, v10}, Ljava/lang/Math;->min(II)I

    move-result v9

    if-lt v8, v9, :cond_3

    .line 615
    move-object v8, v2

    const/16 v9, 0xa

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v8

    .line 616
    goto :goto_2

    .line 611
    :cond_3
    move-object v8, v0

    iget-object v8, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    invoke-virtual {v8}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->fields()[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$FieldDefinition;

    move-result-object v8

    move-object v9, v3

    move v10, v4

    aget-object v9, v9, v10

    iget v9, v9, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->fieldStart:I

    move v10, v5

    add-int/2addr v9, v10

    aget-object v8, v8, v9

    move-object v6, v8

    .line 612
    move-object v8, v2

    move-object v9, v0

    move-object v10, v6

    iget v10, v10, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$FieldDefinition;->typeIndex:I

    invoke-virtual {v9, v10}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->nameOfTypeIndex(I)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const/16 v9, 0x20

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v8

    move-object v9, v0

    iget-object v9, v9, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    move-object v10, v6

    iget v10, v10, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$FieldDefinition;->nameIndex:I

    invoke-virtual {v9, v10}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->getString(I)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v9, "; "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    .line 610
    add-int/lit8 v5, v5, 0x1

    goto :goto_3
.end method

.method public isEnum(Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;)Z
    .locals 5

    .prologue
    .line 386
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    iget v3, v3, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->enumTypeDef:I

    const/4 v4, 0x0

    if-lt v3, v4, :cond_0

    move-object v3, v0

    move-object v4, v1

    invoke-virtual {v3, v4}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->parentTypeDef(Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;)I

    move-result v3

    move-object v4, v0

    iget v4, v4, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->enumTypeDef:I

    if-eq v3, v4, :cond_1

    :cond_0
    const/4 v3, 0x0

    :goto_0
    move v0, v3

    return v0

    :cond_1
    const/4 v3, 0x1

    goto :goto_0
.end method

.method public isStruct(Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;)Z
    .locals 5

    .prologue
    .line 390
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    iget v3, v3, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->valueTypeTypeDef:I

    const/4 v4, 0x0

    if-lt v3, v4, :cond_0

    move-object v3, v0

    move-object v4, v1

    invoke-virtual {v3, v4}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->parentTypeDef(Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;)I

    move-result v3

    move-object v4, v0

    iget v4, v4, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->valueTypeTypeDef:I

    if-eq v3, v4, :cond_1

    :cond_0
    const/4 v3, 0x0

    :goto_0
    move v0, v3

    return v0

    :cond_1
    const/4 v3, 0x1

    goto :goto_0
.end method

.method public isValueType(Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;)Z
    .locals 5

    .prologue
    .line 399
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    move-object v4, v1

    invoke-virtual {v3, v4}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->isStruct(Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;)Z

    move-result v3

    if-nez v3, :cond_0

    move-object v3, v0

    move-object v4, v1

    invoke-virtual {v3, v4}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->isEnum(Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;)Z

    move-result v3

    if-nez v3, :cond_0

    const/4 v3, 0x0

    :goto_0
    move v0, v3

    return v0

    :cond_0
    const/4 v3, 0x1

    goto :goto_0
.end method

.method public kindOf(J)I
    .locals 11

    .prologue
    .line 106
    move-object v1, p0

    move-wide v2, p1

    move-object v7, v1

    move-wide v8, v2

    invoke-direct {v7, v8, v9}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->bitsOf(J)I

    move-result v7

    move v5, v7

    .line 107
    move v7, v5

    const/4 v8, 0x0

    if-ge v7, v8, :cond_0

    const/4 v7, -0x1

    :goto_0
    move v1, v7

    return v1

    :cond_0
    move v7, v5

    const/16 v8, 0x10

    ushr-int/lit8 v7, v7, 0x10

    const/16 v8, 0xff

    and-int/lit16 v7, v7, 0xff

    goto :goto_0
.end method

.method public nameOf(JI)Ljava/lang/String;
    .locals 15

    .prologue
    .line 413
    move-object v1, p0

    move-wide/from16 v2, p1

    move/from16 v4, p3

    move-wide v9, v2

    const/4 v11, 0x0

    int-to-long v11, v11

    cmp-long v9, v9, v11

    if-lez v9, :cond_0

    move v9, v4

    const/4 v10, 0x6

    if-le v9, v10, :cond_1

    .line 414
    :cond_0
    const-string v9, "object"

    move-object v1, v9

    .line 418
    :goto_0
    return-object v1

    .line 416
    :cond_1
    move-object v9, v1

    move-wide v10, v2

    invoke-virtual {v9, v10, v11}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->kindOf(J)I

    move-result v9

    move v6, v9

    .line 417
    move-object v9, v1

    move-wide v10, v2

    move v12, v6

    move v13, v4

    invoke-direct {v9, v10, v11, v12, v13}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->baseName(JII)Ljava/lang/String;

    move-result-object v9

    move-object v7, v9

    .line 418
    move-object v9, v1

    move-wide v10, v2

    invoke-direct {v9, v10, v11}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->isByref(J)Z

    move-result v9

    if-eqz v9, :cond_2

    new-instance v9, Ljava/lang/StringBuffer;

    move-object v14, v9

    move-object v9, v14

    move-object v10, v14

    invoke-direct {v10}, Ljava/lang/StringBuffer;-><init>()V

    const-string v10, "ref "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    move-object v10, v7

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v9

    :goto_1
    move-object v1, v9

    goto :goto_0

    :cond_2
    move-object v9, v7

    goto :goto_1
.end method

.method public nameOfTypeIndex(I)Ljava/lang/String;
    .locals 10

    .prologue
    .line 405
    move-object v0, p0

    move v1, p1

    move-object v6, v0

    move v7, v1

    invoke-virtual {v6, v7}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->typeVA(I)J

    move-result-wide v6

    move-wide v3, v6

    .line 406
    move-wide v6, v3

    const/4 v8, 0x0

    int-to-long v8, v8

    cmp-long v6, v6, v8

    if-gtz v6, :cond_0

    .line 407
    const-string v6, "object"

    move-object v0, v6

    .line 409
    :goto_0
    return-object v0

    :cond_0
    move-object v6, v0

    move-wide v7, v3

    const/4 v9, 0x0

    invoke-virtual {v6, v7, v8, v9}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->nameOf(JI)Ljava/lang/String;

    move-result-object v6

    move-object v0, v6

    goto :goto_0
.end method

.method public parentTypeDef(Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;)I
    .locals 10

    .prologue
    .line 378
    move-object v0, p0

    move-object v1, p1

    move-object v6, v0

    move-object v7, v1

    iget v7, v7, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->parentIndex:I

    invoke-virtual {v6, v7}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->typeVA(I)J

    move-result-wide v6

    move-wide v3, v6

    .line 379
    move-wide v6, v3

    const/4 v8, 0x0

    int-to-long v8, v8

    cmp-long v6, v6, v8

    if-gtz v6, :cond_0

    .line 380
    const/4 v6, -0x1

    move v0, v6

    .line 382
    :goto_0
    return v0

    :cond_0
    move-object v6, v0

    move-wide v7, v3

    invoke-virtual {v6, v7, v8}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->typeDefIndexOf(J)I

    move-result v6

    move v0, v6

    goto :goto_0
.end method

.method public typeDefIndexOf(J)I
    .locals 17

    .prologue
    .line 338
    move-object/from16 v0, p0

    move-wide/from16 v1, p1

    move-object v12, v0

    move-wide v13, v1

    invoke-direct {v12, v13, v14}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->dataOf(J)J

    move-result-wide v12

    move-wide v4, v12

    .line 339
    move-wide v12, v4

    const/4 v14, 0x0

    int-to-long v14, v14

    cmp-long v12, v12, v14

    if-gez v12, :cond_0

    .line 340
    const/4 v12, -0x1

    move v0, v12

    .line 354
    :goto_0
    return v0

    .line 342
    :cond_0
    move-object v12, v0

    iget-boolean v12, v12, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->handleMode:Z

    if-nez v12, :cond_2

    .line 343
    move-wide v12, v4

    move-object v14, v0

    iget-object v14, v14, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    invoke-virtual {v14}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->types()[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;

    move-result-object v14

    array-length v14, v14

    int-to-long v14, v14

    cmp-long v12, v12, v14

    if-gez v12, :cond_1

    move-wide v12, v4

    long-to-int v12, v12

    :goto_1
    move v0, v12

    goto :goto_0

    :cond_1
    const/4 v12, -0x1

    goto :goto_1

    .line 345
    :cond_2
    move-object v12, v0

    iget-wide v12, v12, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->typeDefBase:J

    const/4 v14, 0x0

    int-to-long v14, v14

    cmp-long v12, v12, v14

    if-gez v12, :cond_3

    .line 346
    const/4 v12, -0x1

    move v0, v12

    goto :goto_0

    .line 348
    :cond_3
    move-wide v12, v4

    move-object v14, v0

    iget-wide v14, v14, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->typeDefBase:J

    sub-long/2addr v12, v14

    move-wide v6, v12

    .line 349
    move-object v12, v0

    iget-object v12, v12, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    invoke-virtual {v12}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->typeStructSize()I

    move-result v12

    move v8, v12

    .line 350
    move-wide v12, v6

    const/4 v14, 0x0

    int-to-long v14, v14

    cmp-long v12, v12, v14

    if-ltz v12, :cond_4

    move-wide v12, v6

    move v14, v8

    int-to-long v14, v14

    rem-long/2addr v12, v14

    const/4 v14, 0x0

    int-to-long v14, v14

    cmp-long v12, v12, v14

    if-eqz v12, :cond_5

    .line 351
    :cond_4
    const/4 v12, -0x1

    move v0, v12

    goto :goto_0

    .line 353
    :cond_5
    move-wide v12, v6

    move v14, v8

    int-to-long v14, v14

    div-long/2addr v12, v14

    move-wide v9, v12

    .line 354
    move-wide v12, v9

    const/4 v14, 0x0

    int-to-long v14, v14

    cmp-long v12, v12, v14

    if-ltz v12, :cond_6

    move-wide v12, v9

    move-object v14, v0

    iget-object v14, v14, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    invoke-virtual {v14}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->types()[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;

    move-result-object v14

    array-length v14, v14

    int-to-long v14, v14

    cmp-long v12, v12, v14

    if-gez v12, :cond_6

    move-wide v12, v9

    long-to-int v12, v12

    :goto_2
    move v0, v12

    goto :goto_0

    :cond_6
    const/4 v12, -0x1

    goto :goto_2
.end method

.method public typeVA(I)J
    .locals 13

    .prologue
    .line 79
    move-object v0, p0

    move v1, p1

    move v6, v1

    const/4 v7, 0x0

    if-lt v6, v7, :cond_0

    move v6, v1

    move-object v7, v0

    iget v7, v7, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->typesCount:I

    if-lt v6, v7, :cond_1

    .line 80
    :cond_0
    const/4 v6, -0x1

    int-to-long v6, v6

    move-wide v0, v6

    .line 86
    :goto_0
    return-wide v0

    .line 82
    :cond_1
    move-object v6, v0

    iget-object v6, v6, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->elf:Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

    move-object v7, v0

    iget-wide v7, v7, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->typesVA:J

    invoke-virtual {v6, v7, v8}, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;->mapVirtualAddress(J)J

    move-result-wide v6

    move-wide v3, v6

    .line 83
    move-wide v6, v3

    const/4 v8, 0x0

    int-to-long v8, v8

    cmp-long v6, v6, v8

    if-gez v6, :cond_2

    .line 84
    const/4 v6, -0x1

    int-to-long v6, v6

    move-wide v0, v6

    goto :goto_0

    .line 86
    :cond_2
    move-object v6, v0

    iget-object v6, v6, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    move-wide v7, v3

    move v9, v1

    int-to-long v9, v9

    move-object v11, v0

    iget v11, v11, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->pointerSize:I

    int-to-long v11, v11

    mul-long/2addr v9, v11

    add-long/2addr v7, v9

    long-to-int v7, v7

    invoke-virtual {v6, v7}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readPointerAt(I)J

    move-result-wide v6

    move-wide v0, v6

    goto :goto_0
.end method
