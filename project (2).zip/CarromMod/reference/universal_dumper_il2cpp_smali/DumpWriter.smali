.class public Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;
.super Ljava/lang/Object;
.source "DumpWriter.java"


# static fields
.field private static final FIELD_ACCESS_MASK:I = 0x7

.field private static final FIELD_ASSEMBLY:I = 0x3

.field private static final FIELD_FAMILY:I = 0x4

.field private static final FIELD_FAM_AND_ASSEM:I = 0x2

.field private static final FIELD_FAM_OR_ASSEM:I = 0x5

.field private static final FIELD_INIT_ONLY:I = 0x20

.field private static final FIELD_LITERAL:I = 0x40

.field private static final FIELD_PRIVATE:I = 0x1

.field private static final FIELD_PUBLIC:I = 0x6

.field private static final FIELD_STATIC:I = 0x10

.field private static final METHOD_ABSTRACT:I = 0x400

.field private static final METHOD_ACCESS_MASK:I = 0x7

.field private static final METHOD_FINAL:I = 0x20

.field private static final METHOD_NEW_SLOT:I = 0x100

.field private static final METHOD_STATIC:I = 0x10

.field private static final METHOD_VIRTUAL:I = 0x40


# instance fields
.field private final binary:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;

.field private final metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

.field private final types:Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;


# direct methods
.method public constructor <init>(Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;)V
    .locals 7

    .prologue
    .line 39
    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v5, v0

    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    .line 40
    move-object v5, v0

    move-object v6, v1

    iput-object v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    .line 41
    move-object v5, v0

    move-object v6, v2

    iput-object v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->binary:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;

    .line 42
    move-object v5, v0

    move-object v6, v3

    iput-object v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->types:Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;

    return-void
.end method

.method private fieldModifiers(I)Ljava/lang/String;
    .locals 8

    .prologue
    .line 228
    move-object v0, p0

    move v1, p1

    new-instance v5, Ljava/lang/StringBuilder;

    move-object v7, v5

    move-object v5, v7

    move-object v6, v7

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    move-object v3, v5

    .line 229
    move v5, v1

    const/4 v6, 0x7

    and-int/lit8 v5, v5, 0x7

    packed-switch v5, :pswitch_data_0

    .line 251
    :goto_0
    move v5, v1

    const/16 v6, 0x40

    and-int/lit8 v5, v5, 0x40

    const/4 v6, 0x0

    if-eq v5, v6, :cond_1

    .line 252
    move-object v5, v3

    const-string v6, "const "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    .line 261
    :cond_0
    :goto_1
    move-object v5, v3

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    move-object v0, v5

    return-object v0

    .line 231
    :pswitch_0
    move-object v5, v3

    const-string v6, "private "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    .line 232
    goto :goto_0

    .line 234
    :pswitch_1
    move-object v5, v3

    const-string v6, "private protected "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    .line 235
    goto :goto_0

    .line 237
    :pswitch_2
    move-object v5, v3

    const-string v6, "internal "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    .line 238
    goto :goto_0

    .line 240
    :pswitch_3
    move-object v5, v3

    const-string v6, "protected "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    .line 241
    goto :goto_0

    .line 243
    :pswitch_4
    move-object v5, v3

    const-string v6, "protected internal "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    .line 244
    goto :goto_0

    .line 246
    :pswitch_5
    move-object v5, v3

    const-string v6, "public "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    .line 247
    goto :goto_0

    .line 254
    :cond_1
    move v5, v1

    const/16 v6, 0x10

    and-int/lit8 v5, v5, 0x10

    const/4 v6, 0x0

    if-eq v5, v6, :cond_2

    .line 255
    move-object v5, v3

    const-string v6, "static "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    .line 257
    :cond_2
    move v5, v1

    const/16 v6, 0x20

    and-int/lit8 v5, v5, 0x20

    const/4 v6, 0x0

    if-eq v5, v6, :cond_0

    .line 258
    move-object v5, v3

    const-string v6, "readonly "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    goto :goto_1

    .line 229
    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_4
        :pswitch_5
    .end packed-switch
.end method

.method private methodModifiers(Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;)Ljava/lang/String;
    .locals 9

    .prologue
    .line 265
    move-object v0, p0

    move-object v1, p1

    new-instance v5, Ljava/lang/StringBuilder;

    move-object v8, v5

    move-object v5, v8

    move-object v6, v8

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    move-object v3, v5

    .line 266
    move-object v5, v1

    iget v5, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;->flags:I

    const/4 v6, 0x7

    and-int/lit8 v5, v5, 0x7

    packed-switch v5, :pswitch_data_0

    .line 288
    :goto_0
    move-object v5, v1

    iget v5, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;->flags:I

    const/16 v6, 0x10

    and-int/lit8 v5, v5, 0x10

    const/4 v6, 0x0

    if-eq v5, v6, :cond_0

    .line 289
    move-object v5, v3

    const-string v6, "static "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    .line 291
    :cond_0
    move-object v5, v1

    iget v5, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;->flags:I

    const/16 v6, 0x400

    and-int/lit16 v5, v5, 0x400

    const/4 v6, 0x0

    if-eq v5, v6, :cond_2

    .line 292
    move-object v5, v3

    const-string v6, "abstract "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    .line 293
    move-object v5, v1

    iget v5, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;->flags:I

    const/16 v6, 0x100

    and-int/lit16 v5, v5, 0x100

    const/4 v6, 0x0

    if-ne v5, v6, :cond_1

    .line 294
    move-object v5, v3

    const-string v6, "override "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    .line 303
    :cond_1
    :goto_1
    move-object v5, v3

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    move-object v0, v5

    return-object v0

    .line 268
    :pswitch_0
    move-object v5, v3

    const-string v6, "private "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    .line 269
    goto :goto_0

    .line 271
    :pswitch_1
    move-object v5, v3

    const-string v6, "private protected "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    .line 272
    goto :goto_0

    .line 274
    :pswitch_2
    move-object v5, v3

    const-string v6, "internal "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    .line 275
    goto :goto_0

    .line 277
    :pswitch_3
    move-object v5, v3

    const-string v6, "protected "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    .line 278
    goto :goto_0

    .line 280
    :pswitch_4
    move-object v5, v3

    const-string v6, "protected internal "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    .line 281
    goto :goto_0

    .line 283
    :pswitch_5
    move-object v5, v3

    const-string v6, "public "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    .line 284
    goto :goto_0

    .line 296
    :cond_2
    move-object v5, v1

    iget v5, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;->flags:I

    const/16 v6, 0x40

    and-int/lit8 v5, v5, 0x40

    const/4 v6, 0x0

    if-eq v5, v6, :cond_1

    .line 297
    move-object v5, v1

    iget v5, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;->flags:I

    const/16 v6, 0x100

    and-int/lit16 v5, v5, 0x100

    const/4 v6, 0x0

    if-eq v5, v6, :cond_4

    .line 298
    move-object v5, v3

    move-object v6, v1

    iget v6, v6, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;->flags:I

    const/16 v7, 0x20

    and-int/lit8 v6, v6, 0x20

    const/4 v7, 0x0

    if-eq v6, v7, :cond_3

    const-string v6, "sealed "

    :goto_2
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    goto :goto_1

    :cond_3
    const-string v6, "virtual "

    goto :goto_2

    .line 300
    :cond_4
    move-object v5, v3

    const-string v6, "override "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    goto :goto_1

    .line 266
    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_4
        :pswitch_5
    .end packed-switch
.end method

.method private parameterList(Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;)Ljava/lang/String;
    .locals 15

    .prologue
    .line 208
    move-object v0, p0

    move-object/from16 v1, p1

    move-object v9, v1

    iget v9, v9, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;->parameterCount:I

    const/4 v10, 0x0

    if-le v9, v10, :cond_0

    move-object v9, v1

    iget v9, v9, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;->parameterStart:I

    const/4 v10, 0x0

    if-ge v9, v10, :cond_1

    .line 209
    :cond_0
    const-string v9, ""

    move-object v0, v9

    .line 224
    :goto_0
    return-object v0

    .line 211
    :cond_1
    new-instance v9, Ljava/lang/StringBuilder;

    move-object v14, v9

    move-object v9, v14

    move-object v10, v14

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    move-object v3, v9

    .line 212
    move-object v9, v0

    iget-object v9, v9, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    invoke-virtual {v9}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->parameters()[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ParameterDefinition;

    move-result-object v9

    move-object v4, v9

    .line 213
    const/4 v9, 0x0

    move v5, v9

    :goto_1
    move v9, v5

    move-object v10, v1

    iget v10, v10, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;->parameterCount:I

    if-lt v9, v10, :cond_2

    .line 224
    :goto_2
    move-object v9, v3

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    move-object v0, v9

    goto :goto_0

    .line 214
    :cond_2
    move-object v9, v1

    iget v9, v9, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;->parameterStart:I

    move v10, v5

    add-int/2addr v9, v10

    move v6, v9

    .line 215
    move v9, v6

    move-object v10, v4

    array-length v10, v10

    if-lt v9, v10, :cond_3

    .line 216
    goto :goto_2

    .line 218
    :cond_3
    move v9, v5

    const/4 v10, 0x0

    if-le v9, v10, :cond_4

    .line 219
    move-object v9, v3

    const-string v10, ", "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    .line 221
    :cond_4
    move-object v9, v0

    iget-object v9, v9, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->types:Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;

    if-nez v9, :cond_5

    const-string v9, "object"

    :goto_3
    move-object v7, v9

    .line 222
    move-object v9, v3

    move-object v10, v7

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    const/16 v10, 0x20

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v9

    move-object v10, v0

    iget-object v10, v10, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    move-object v11, v4

    move v12, v6

    aget-object v11, v11, v12

    iget v11, v11, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ParameterDefinition;->nameIndex:I

    invoke-virtual {v10, v11}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->getString(I)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    .line 213
    add-int/lit8 v5, v5, 0x1

    goto :goto_1

    .line 221
    :cond_5
    move-object v9, v0

    iget-object v9, v9, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->types:Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;

    move-object v10, v4

    move v11, v6

    aget-object v10, v10, v11

    iget v10, v10, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ParameterDefinition;->typeIndex:I

    invoke-virtual {v9, v10}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->nameOfTypeIndex(I)Ljava/lang/String;

    move-result-object v9

    goto :goto_3
.end method

.method private writeFields(Ljava/io/Writer;Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;I)V
    .locals 30
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/io/Writer;",
            "Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;",
            "I)V^",
            "Ljava/lang/Exception;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .prologue
    .line 139
    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move/from16 v4, p3

    move-object v15, v3

    iget v15, v15, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->fieldCount:I

    const/16 v16, 0x0

    move/from16 v0, v16

    if-le v15, v0, :cond_0

    move-object v15, v3

    iget v15, v15, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->fieldStart:I

    const/16 v16, 0x0

    move/from16 v0, v16

    if-ge v15, v0, :cond_1

    .line 168
    :cond_0
    :goto_0
    return-void

    .line 142
    :cond_1
    move-object v15, v1

    iget-object v15, v15, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->types:Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;

    if-eqz v15, :cond_2

    move-object v15, v1

    iget-object v15, v15, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->types:Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;

    move-object/from16 v16, v3

    invoke-virtual/range {v15 .. v16}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->isValueType(Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;)Z

    move-result v15

    if-nez v15, :cond_4

    :cond_2
    const/4 v15, 0x0

    :goto_1
    move v6, v15

    .line 143
    move-object v15, v1

    iget-object v15, v15, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->binary:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;

    if-nez v15, :cond_5

    const/4 v15, 0x0

    :goto_2
    move v7, v15

    .line 144
    move-object v15, v2

    const-string v16, "\t// Fields\n"

    invoke-virtual/range {v15 .. v16}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    .line 145
    move-object v15, v3

    iget v15, v15, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->fieldStart:I

    move-object/from16 v16, v3

    move-object/from16 v0, v16

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->fieldCount:I

    move/from16 v16, v0

    add-int v15, v15, v16

    move v8, v15

    .line 146
    move-object v15, v3

    iget v15, v15, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->fieldStart:I

    move v9, v15

    :goto_3
    move v15, v9

    move/from16 v16, v8

    move/from16 v0, v16

    if-ge v15, v0, :cond_3

    move v15, v9

    move-object/from16 v16, v1

    move-object/from16 v0, v16

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    move-object/from16 v16, v0

    invoke-virtual/range {v16 .. v16}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->fields()[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$FieldDefinition;

    move-result-object v16

    move-object/from16 v0, v16

    array-length v0, v0

    move/from16 v16, v0

    move/from16 v0, v16

    if-lt v15, v0, :cond_6

    .line 168
    :cond_3
    move-object v15, v2

    const-string v16, "\n"

    invoke-virtual/range {v15 .. v16}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    goto :goto_0

    .line 142
    :cond_4
    const/4 v15, 0x1

    goto :goto_1

    .line 143
    :cond_5
    const/4 v15, 0x2

    move-object/from16 v16, v1

    move-object/from16 v0, v16

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->binary:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;

    move-object/from16 v16, v0

    invoke-virtual/range {v16 .. v16}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->pointerSize()I

    move-result v16

    mul-int v15, v15, v16

    goto :goto_2

    .line 147
    :cond_6
    move-object v15, v1

    iget-object v15, v15, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    invoke-virtual {v15}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->fields()[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$FieldDefinition;

    move-result-object v15

    move/from16 v16, v9

    aget-object v15, v15, v16

    move-object v10, v15

    .line 148
    move-object v15, v1

    iget-object v15, v15, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->types:Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;

    if-nez v15, :cond_9

    const/4 v15, 0x0

    :goto_4
    move v11, v15

    .line 149
    move-object v15, v1

    iget-object v15, v15, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->types:Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;

    if-nez v15, :cond_a

    new-instance v15, Ljava/lang/StringBuffer;

    move-object/from16 v28, v15

    move-object/from16 v15, v28

    move-object/from16 v16, v28

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v16, Ljava/lang/StringBuffer;

    move-object/from16 v28, v16

    move-object/from16 v16, v28

    move-object/from16 v17, v28

    invoke-direct/range {v17 .. v17}, Ljava/lang/StringBuffer;-><init>()V

    const-string v17, "/* typeIndex "

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v16

    move-object/from16 v17, v10

    move-object/from16 v0, v17

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$FieldDefinition;->typeIndex:I

    move/from16 v17, v0

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v16

    invoke-virtual/range {v15 .. v16}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v15

    const-string v16, " */"

    invoke-virtual/range {v15 .. v16}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v15

    :goto_5
    move-object v12, v15

    .line 152
    move-object v15, v2

    new-instance v16, Ljava/lang/StringBuffer;

    move-object/from16 v28, v16

    move-object/from16 v16, v28

    move-object/from16 v17, v28

    invoke-direct/range {v17 .. v17}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v17, Ljava/lang/StringBuffer;

    move-object/from16 v28, v17

    move-object/from16 v17, v28

    move-object/from16 v18, v28

    invoke-direct/range {v18 .. v18}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v18, Ljava/lang/StringBuffer;

    move-object/from16 v28, v18

    move-object/from16 v18, v28

    move-object/from16 v19, v28

    invoke-direct/range {v19 .. v19}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v19, Ljava/lang/StringBuffer;

    move-object/from16 v28, v19

    move-object/from16 v19, v28

    move-object/from16 v20, v28

    invoke-direct/range {v20 .. v20}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v20, Ljava/lang/StringBuffer;

    move-object/from16 v28, v20

    move-object/from16 v20, v28

    move-object/from16 v21, v28

    invoke-direct/range {v21 .. v21}, Ljava/lang/StringBuffer;-><init>()V

    const-string v21, "\t"

    invoke-virtual/range {v20 .. v21}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v20

    move-object/from16 v21, v1

    move/from16 v22, v11

    invoke-direct/range {v21 .. v22}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->fieldModifiers(I)Ljava/lang/String;

    move-result-object v21

    invoke-virtual/range {v20 .. v21}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v20

    invoke-virtual/range {v20 .. v20}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v19

    move-object/from16 v20, v12

    invoke-virtual/range {v19 .. v20}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v19

    invoke-virtual/range {v19 .. v19}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v19

    invoke-virtual/range {v18 .. v19}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v18

    const-string v19, " "

    invoke-virtual/range {v18 .. v19}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v18

    invoke-virtual/range {v18 .. v18}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v18

    invoke-virtual/range {v17 .. v18}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v17

    move-object/from16 v18, v1

    move-object/from16 v0, v18

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    move-object/from16 v18, v0

    move-object/from16 v19, v10

    move-object/from16 v0, v19

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$FieldDefinition;->nameIndex:I

    move/from16 v19, v0

    invoke-virtual/range {v18 .. v19}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->getString(I)Ljava/lang/String;

    move-result-object v18

    invoke-virtual/range {v17 .. v18}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v17

    invoke-virtual/range {v17 .. v17}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v17

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v16

    const-string v17, ";"

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v16

    invoke-virtual/range {v15 .. v16}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    .line 155
    move v15, v11

    const/16 v16, 0x40

    and-int/lit8 v15, v15, 0x40

    const/16 v16, 0x0

    move/from16 v0, v16

    if-ne v15, v0, :cond_8

    .line 156
    move-object v15, v1

    iget-object v15, v15, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->binary:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;

    if-nez v15, :cond_b

    const/4 v15, -0x1

    :goto_6
    move v13, v15

    .line 158
    move v15, v13

    const/16 v16, 0x0

    move/from16 v0, v16

    if-lt v15, v0, :cond_7

    move v15, v6

    if-eqz v15, :cond_7

    move v15, v11

    const/16 v16, 0x10

    and-int/lit8 v15, v15, 0x10

    const/16 v16, 0x0

    move/from16 v0, v16

    if-ne v15, v0, :cond_7

    move v15, v13

    move/from16 v16, v7

    move/from16 v0, v16

    if-lt v15, v0, :cond_7

    .line 160
    move v15, v13

    move/from16 v16, v7

    sub-int v15, v15, v16

    move v13, v15

    .line 162
    :cond_7
    move v15, v13

    const/16 v16, 0x0

    move/from16 v0, v16

    if-lt v15, v0, :cond_8

    .line 163
    move-object v15, v2

    const-string v16, " // 0x%X"

    const/16 v17, 0x1

    move/from16 v0, v17

    new-array v0, v0, [Ljava/lang/Object;

    move-object/from16 v17, v0

    move-object/from16 v28, v17

    move-object/from16 v17, v28

    move-object/from16 v18, v28

    const/16 v19, 0x0

    move/from16 v20, v13

    new-instance v21, Ljava/lang/Integer;

    move/from16 v28, v20

    move-object/from16 v29, v21

    move-object/from16 v20, v29

    move/from16 v21, v28

    move-object/from16 v22, v29

    move/from16 v28, v21

    move-object/from16 v29, v22

    move-object/from16 v21, v29

    move/from16 v22, v28

    invoke-direct/range {v21 .. v22}, Ljava/lang/Integer;-><init>(I)V

    aput-object v20, v18, v19

    invoke-static/range {v16 .. v17}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v16

    invoke-virtual/range {v15 .. v16}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    .line 166
    :cond_8
    move-object v15, v2

    const-string v16, "\n"

    invoke-virtual/range {v15 .. v16}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    .line 146
    add-int/lit8 v9, v9, 0x1

    goto/16 :goto_3

    .line 148
    :cond_9
    move-object v15, v1

    iget-object v15, v15, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->types:Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;

    move-object/from16 v16, v10

    move-object/from16 v0, v16

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$FieldDefinition;->typeIndex:I

    move/from16 v16, v0

    invoke-virtual/range {v15 .. v16}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->attrsOfTypeIndex(I)I

    move-result v15

    goto/16 :goto_4

    .line 149
    :cond_a
    move-object v15, v1

    iget-object v15, v15, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->types:Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;

    move-object/from16 v16, v10

    move-object/from16 v0, v16

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$FieldDefinition;->typeIndex:I

    move/from16 v16, v0

    invoke-virtual/range {v15 .. v16}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->nameOfTypeIndex(I)Ljava/lang/String;

    move-result-object v15

    goto/16 :goto_5

    .line 156
    :cond_b
    move-object v15, v1

    iget-object v15, v15, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->binary:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;

    move/from16 v16, v4

    move/from16 v17, v9

    move-object/from16 v18, v3

    move-object/from16 v0, v18

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->fieldStart:I

    move/from16 v18, v0

    sub-int v17, v17, v18

    invoke-virtual/range {v15 .. v17}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->fieldOffset(II)I

    move-result v15

    goto/16 :goto_6
.end method

.method private writeInheritance(Ljava/io/Writer;Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;Z)V
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/io/Writer;",
            "Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;",
            "Z)V^",
            "Ljava/lang/Exception;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .prologue
    .line 107
    move-object v0, p0

    move-object v1, p1

    move-object/from16 v2, p2

    move/from16 v3, p3

    move-object v10, v0

    iget-object v10, v10, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->types:Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;

    if-nez v10, :cond_0

    .line 133
    :goto_0
    return-void

    .line 110
    :cond_0
    new-instance v10, Ljava/lang/StringBuilder;

    move-object v13, v10

    move-object v10, v13

    move-object v11, v13

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    move-object v5, v10

    .line 112
    move-object v10, v0

    iget-object v10, v10, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->types:Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;

    move-object v11, v2

    invoke-virtual {v10, v11}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->parentTypeDef(Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;)I

    move-result v10

    move v6, v10

    .line 113
    move v10, v3

    if-nez v10, :cond_1

    move-object v10, v2

    invoke-virtual {v10}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->isInterface()Z

    move-result v10

    if-nez v10, :cond_1

    move v10, v6

    const/4 v11, 0x0

    if-lt v10, v11, :cond_1

    .line 114
    move-object v10, v0

    iget-object v10, v10, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    move-object v11, v0

    iget-object v11, v11, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    invoke-virtual {v11}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->types()[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;

    move-result-object v11

    move v12, v6

    aget-object v11, v11, v12

    invoke-virtual {v10, v11}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->fullName(Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;)Ljava/lang/String;

    move-result-object v10

    move-object v7, v10

    .line 116
    const-string v10, "System.Object"

    move-object v11, v7

    invoke-virtual {v10, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_1

    const-string v10, "System.ValueType"

    move-object v11, v7

    invoke-virtual {v10, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_1

    .line 117
    move-object v10, v5

    move-object v11, v7

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    .line 121
    :cond_1
    const/4 v10, 0x0

    move v7, v10

    :goto_1
    move v10, v7

    move-object v11, v2

    iget v11, v11, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->interfacesCount:I

    if-lt v10, v11, :cond_3

    .line 132
    move-object v10, v5

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->length()I

    move-result v10

    const/4 v11, 0x0

    if-le v10, v11, :cond_2

    .line 133
    move-object v10, v1

    new-instance v11, Ljava/lang/StringBuffer;

    move-object v13, v11

    move-object v11, v13

    move-object v12, v13

    invoke-direct {v12}, Ljava/lang/StringBuffer;-><init>()V

    const-string v12, " : "

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    move-object v12, v5

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/Object;)Ljava/lang/StringBuffer;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    :cond_2
    goto :goto_0

    .line 122
    :cond_3
    move-object v10, v0

    iget-object v10, v10, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    move-object v11, v2

    iget v11, v11, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->interfacesStart:I

    move v12, v7

    add-int/2addr v11, v12

    invoke-virtual {v10, v11}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->interfaceTypeIndex(I)I

    move-result v10

    move v8, v10

    .line 123
    move v10, v8

    const/4 v11, 0x0

    if-ge v10, v11, :cond_4

    .line 121
    :goto_2
    add-int/lit8 v7, v7, 0x1

    goto :goto_1

    .line 126
    :cond_4
    move-object v10, v5

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->length()I

    move-result v10

    const/4 v11, 0x0

    if-le v10, v11, :cond_5

    .line 127
    move-object v10, v5

    const-string v11, ", "

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    .line 129
    :cond_5
    move-object v10, v5

    move-object v11, v0

    iget-object v11, v11, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->types:Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;

    move v12, v8

    invoke-virtual {v11, v12}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->nameOfTypeIndex(I)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    goto :goto_2
.end method

.method private writeMethods(Ljava/io/Writer;Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;I)V
    .locals 31
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/io/Writer;",
            "Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;",
            "I)V^",
            "Ljava/lang/Exception;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .prologue
    .line 173
    move-object/from16 v2, p0

    move-object/from16 v3, p1

    move-object/from16 v4, p2

    move/from16 v5, p3

    move-object v15, v4

    iget v15, v15, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->methodCount:I

    const/16 v16, 0x0

    move/from16 v0, v16

    if-le v15, v0, :cond_0

    move-object v15, v4

    iget v15, v15, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->methodStart:I

    const/16 v16, 0x0

    move/from16 v0, v16

    if-ge v15, v0, :cond_1

    .line 178
    :cond_0
    :goto_0
    return-void

    .line 176
    :cond_1
    move-object v15, v3

    const-string v16, "\t// Methods\n\n"

    invoke-virtual/range {v15 .. v16}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    .line 177
    move-object v15, v4

    iget v15, v15, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->methodStart:I

    move-object/from16 v16, v4

    move-object/from16 v0, v16

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->methodCount:I

    move/from16 v16, v0

    add-int v15, v15, v16

    move v7, v15

    .line 178
    move-object v15, v4

    iget v15, v15, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->methodStart:I

    move v8, v15

    :goto_1
    move v15, v8

    move/from16 v16, v7

    move/from16 v0, v16

    if-ge v15, v0, :cond_2

    move v15, v8

    move-object/from16 v16, v2

    move-object/from16 v0, v16

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    move-object/from16 v16, v0

    invoke-virtual/range {v16 .. v16}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->methods()[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;

    move-result-object v16

    move-object/from16 v0, v16

    array-length v0, v0

    move/from16 v16, v0

    move/from16 v0, v16

    if-lt v15, v0, :cond_3

    :cond_2
    goto :goto_0

    .line 179
    :cond_3
    move-object v15, v2

    iget-object v15, v15, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    invoke-virtual {v15}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->methods()[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;

    move-result-object v15

    move/from16 v16, v8

    aget-object v15, v15, v16

    move-object v9, v15

    .line 181
    move-object v15, v2

    iget-object v15, v15, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->binary:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;

    if-eqz v15, :cond_4

    move v15, v5

    const/16 v16, 0x0

    move/from16 v0, v16

    if-ge v15, v0, :cond_6

    :cond_4
    const/4 v15, -0x1

    int-to-long v15, v15

    :goto_2
    move-wide v10, v15

    .line 183
    move-wide v15, v10

    const/16 v17, 0x0

    move/from16 v0, v17

    int-to-long v0, v0

    move-wide/from16 v17, v0

    cmp-long v15, v15, v17

    if-lez v15, :cond_8

    .line 184
    move-object v15, v2

    iget-object v15, v15, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->binary:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;

    invoke-virtual {v15}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->elf()Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

    move-result-object v15

    move-wide/from16 v16, v10

    invoke-virtual/range {v15 .. v17}, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;->mapVirtualAddress(J)J

    move-result-wide v15

    move-wide v12, v15

    .line 185
    move-wide v15, v12

    const/16 v17, 0x0

    move/from16 v0, v17

    int-to-long v0, v0

    move-wide/from16 v17, v0

    cmp-long v15, v15, v17

    if-ltz v15, :cond_7

    .line 186
    move-object v15, v3

    const-string v16, "\t// RVA: 0x%X Offset: 0x%X VA: 0x%X"

    const/16 v17, 0x3

    move/from16 v0, v17

    new-array v0, v0, [Ljava/lang/Object;

    move-object/from16 v17, v0

    move-object/from16 v28, v17

    move-object/from16 v17, v28

    move-object/from16 v18, v28

    const/16 v19, 0x0

    move-wide/from16 v20, v10

    new-instance v22, Ljava/lang/Long;

    move-wide/from16 v28, v20

    move-object/from16 v30, v22

    move-object/from16 v20, v30

    move-wide/from16 v21, v28

    move-object/from16 v23, v30

    move-wide/from16 v28, v21

    move-object/from16 v30, v23

    move-object/from16 v21, v30

    move-wide/from16 v22, v28

    move-object/from16 v24, v30

    invoke-direct/range {v21 .. v23}, Ljava/lang/Long;-><init>(J)V

    aput-object v20, v18, v19

    move-object/from16 v28, v17

    move-object/from16 v17, v28

    move-object/from16 v18, v28

    const/16 v19, 0x1

    move-wide/from16 v20, v12

    new-instance v22, Ljava/lang/Long;

    move-wide/from16 v28, v20

    move-object/from16 v30, v22

    move-object/from16 v20, v30

    move-wide/from16 v21, v28

    move-object/from16 v23, v30

    move-wide/from16 v28, v21

    move-object/from16 v30, v23

    move-object/from16 v21, v30

    move-wide/from16 v22, v28

    move-object/from16 v24, v30

    invoke-direct/range {v21 .. v23}, Ljava/lang/Long;-><init>(J)V

    aput-object v20, v18, v19

    move-object/from16 v28, v17

    move-object/from16 v17, v28

    move-object/from16 v18, v28

    const/16 v19, 0x2

    move-wide/from16 v20, v10

    new-instance v22, Ljava/lang/Long;

    move-wide/from16 v28, v20

    move-object/from16 v30, v22

    move-object/from16 v20, v30

    move-wide/from16 v21, v28

    move-object/from16 v23, v30

    move-wide/from16 v28, v21

    move-object/from16 v30, v23

    move-object/from16 v21, v30

    move-wide/from16 v22, v28

    move-object/from16 v24, v30

    invoke-direct/range {v21 .. v23}, Ljava/lang/Long;-><init>(J)V

    aput-object v20, v18, v19

    invoke-static/range {v16 .. v17}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v16

    invoke-virtual/range {v15 .. v16}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    .line 194
    :goto_3
    move-object v15, v9

    iget v15, v15, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;->flags:I

    const/16 v16, 0x40

    and-int/lit8 v15, v15, 0x40

    const/16 v16, 0x0

    move/from16 v0, v16

    if-eq v15, v0, :cond_5

    move-object v15, v9

    iget v15, v15, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;->slot:I

    const v16, 0xffff

    move/from16 v0, v16

    if-eq v15, v0, :cond_5

    .line 195
    move-object v15, v3

    new-instance v16, Ljava/lang/StringBuffer;

    move-object/from16 v28, v16

    move-object/from16 v16, v28

    move-object/from16 v17, v28

    invoke-direct/range {v17 .. v17}, Ljava/lang/StringBuffer;-><init>()V

    const-string v17, " Slot: "

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v16

    move-object/from16 v17, v9

    move-object/from16 v0, v17

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;->slot:I

    move/from16 v17, v0

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v16

    invoke-virtual/range {v15 .. v16}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    .line 197
    :cond_5
    move-object v15, v3

    const-string v16, "\n"

    invoke-virtual/range {v15 .. v16}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    .line 199
    move-object v15, v2

    iget-object v15, v15, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->types:Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;

    if-nez v15, :cond_9

    const-string v15, "void"

    :goto_4
    move-object v12, v15

    .line 201
    move-object v15, v3

    new-instance v16, Ljava/lang/StringBuffer;

    move-object/from16 v28, v16

    move-object/from16 v16, v28

    move-object/from16 v17, v28

    invoke-direct/range {v17 .. v17}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v17, Ljava/lang/StringBuffer;

    move-object/from16 v28, v17

    move-object/from16 v17, v28

    move-object/from16 v18, v28

    invoke-direct/range {v18 .. v18}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v18, Ljava/lang/StringBuffer;

    move-object/from16 v28, v18

    move-object/from16 v18, v28

    move-object/from16 v19, v28

    invoke-direct/range {v19 .. v19}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v19, Ljava/lang/StringBuffer;

    move-object/from16 v28, v19

    move-object/from16 v19, v28

    move-object/from16 v20, v28

    invoke-direct/range {v20 .. v20}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v20, Ljava/lang/StringBuffer;

    move-object/from16 v28, v20

    move-object/from16 v20, v28

    move-object/from16 v21, v28

    invoke-direct/range {v21 .. v21}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v21, Ljava/lang/StringBuffer;

    move-object/from16 v28, v21

    move-object/from16 v21, v28

    move-object/from16 v22, v28

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v22, Ljava/lang/StringBuffer;

    move-object/from16 v28, v22

    move-object/from16 v22, v28

    move-object/from16 v23, v28

    invoke-direct/range {v23 .. v23}, Ljava/lang/StringBuffer;-><init>()V

    const-string v23, "\t"

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v22

    move-object/from16 v23, v2

    move-object/from16 v24, v9

    invoke-direct/range {v23 .. v24}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->methodModifiers(Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;)Ljava/lang/String;

    move-result-object v23

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v21

    move-object/from16 v22, v12

    invoke-virtual/range {v21 .. v22}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v21

    invoke-virtual/range {v21 .. v21}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v21

    invoke-virtual/range {v20 .. v21}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v20

    const-string v21, " "

    invoke-virtual/range {v20 .. v21}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v20

    invoke-virtual/range {v20 .. v20}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v19

    move-object/from16 v20, v2

    move-object/from16 v0, v20

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    move-object/from16 v20, v0

    move-object/from16 v21, v9

    move-object/from16 v0, v21

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;->nameIndex:I

    move/from16 v21, v0

    invoke-virtual/range {v20 .. v21}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->getString(I)Ljava/lang/String;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v19

    invoke-virtual/range {v19 .. v19}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v19

    invoke-virtual/range {v18 .. v19}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v18

    const-string v19, "("

    invoke-virtual/range {v18 .. v19}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v18

    invoke-virtual/range {v18 .. v18}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v18

    invoke-virtual/range {v17 .. v18}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v17

    move-object/from16 v18, v2

    move-object/from16 v19, v9

    invoke-direct/range {v18 .. v19}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->parameterList(Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;)Ljava/lang/String;

    move-result-object v18

    invoke-virtual/range {v17 .. v18}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v17

    invoke-virtual/range {v17 .. v17}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v17

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v16

    const-string v17, ") { }\n\n"

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v16

    invoke-virtual/range {v15 .. v16}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    .line 178
    add-int/lit8 v8, v8, 0x1

    goto/16 :goto_1

    .line 181
    :cond_6
    move-object v15, v2

    iget-object v15, v15, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->binary:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;

    move/from16 v16, v5

    move-object/from16 v17, v9

    move-object/from16 v0, v17

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;->token:I

    move/from16 v17, v0

    invoke-virtual/range {v15 .. v17}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->methodAddress(II)J

    move-result-wide v15

    goto/16 :goto_2

    .line 189
    :cond_7
    move-object v15, v3

    const-string v16, "\t// RVA: 0x%X Offset: -1 VA: 0x%X"

    const/16 v17, 0x2

    move/from16 v0, v17

    new-array v0, v0, [Ljava/lang/Object;

    move-object/from16 v17, v0

    move-object/from16 v28, v17

    move-object/from16 v17, v28

    move-object/from16 v18, v28

    const/16 v19, 0x0

    move-wide/from16 v20, v10

    new-instance v22, Ljava/lang/Long;

    move-wide/from16 v28, v20

    move-object/from16 v30, v22

    move-object/from16 v20, v30

    move-wide/from16 v21, v28

    move-object/from16 v23, v30

    move-wide/from16 v28, v21

    move-object/from16 v30, v23

    move-object/from16 v21, v30

    move-wide/from16 v22, v28

    move-object/from16 v24, v30

    invoke-direct/range {v21 .. v23}, Ljava/lang/Long;-><init>(J)V

    aput-object v20, v18, v19

    move-object/from16 v28, v17

    move-object/from16 v17, v28

    move-object/from16 v18, v28

    const/16 v19, 0x1

    move-wide/from16 v20, v10

    new-instance v22, Ljava/lang/Long;

    move-wide/from16 v28, v20

    move-object/from16 v30, v22

    move-object/from16 v20, v30

    move-wide/from16 v21, v28

    move-object/from16 v23, v30

    move-wide/from16 v28, v21

    move-object/from16 v30, v23

    move-object/from16 v21, v30

    move-wide/from16 v22, v28

    move-object/from16 v24, v30

    invoke-direct/range {v21 .. v23}, Ljava/lang/Long;-><init>(J)V

    aput-object v20, v18, v19

    invoke-static/range {v16 .. v17}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v16

    invoke-virtual/range {v15 .. v16}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    goto/16 :goto_3

    .line 192
    :cond_8
    move-object v15, v3

    const-string v16, "\t// RVA: -1 Offset: -1"

    invoke-virtual/range {v15 .. v16}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    goto/16 :goto_3

    .line 199
    :cond_9
    move-object v15, v2

    iget-object v15, v15, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->types:Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;

    move-object/from16 v16, v9

    move-object/from16 v0, v16

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;->returnType:I

    move/from16 v16, v0

    invoke-virtual/range {v15 .. v16}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->nameOfTypeIndex(I)Ljava/lang/String;

    move-result-object v15

    goto/16 :goto_4
.end method

.method private writeType(Ljava/io/Writer;II)V
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/io/Writer;",
            "II)V^",
            "Ljava/lang/Exception;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .prologue
    .line 79
    move-object v0, p0

    move-object v1, p1

    move/from16 v2, p2

    move/from16 v3, p3

    move-object v8, v0

    iget-object v8, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    invoke-virtual {v8}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->types()[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;

    move-result-object v8

    move v9, v2

    aget-object v8, v8, v9

    move-object v5, v8

    .line 81
    move-object v8, v1

    new-instance v9, Ljava/lang/StringBuffer;

    move-object v13, v9

    move-object v9, v13

    move-object v10, v13

    invoke-direct {v10}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v10, Ljava/lang/StringBuffer;

    move-object v13, v10

    move-object v10, v13

    move-object v11, v13

    invoke-direct {v11}, Ljava/lang/StringBuffer;-><init>()V

    const-string v11, "// Namespace: "

    invoke-virtual {v10, v11}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v10

    move-object v11, v0

    iget-object v11, v11, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    move-object v12, v5

    iget v12, v12, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->namespaceIndex:I

    invoke-virtual {v11, v12}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->getString(I)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    const-string v10, "\n"

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    .line 82
    move-object v8, v1

    move-object v9, v5

    invoke-virtual {v9}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->modifiers()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    .line 84
    move-object v8, v0

    iget-object v8, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->types:Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;

    if-eqz v8, :cond_0

    move-object v8, v0

    iget-object v8, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->types:Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;

    move-object v9, v5

    invoke-virtual {v8, v9}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->isEnum(Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;)Z

    move-result v8

    if-nez v8, :cond_1

    :cond_0
    const/4 v8, 0x0

    :goto_0
    move v6, v8

    .line 85
    move-object v8, v5

    invoke-virtual {v8}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->isInterface()Z

    move-result v8

    if-eqz v8, :cond_2

    .line 86
    move-object v8, v1

    const-string v9, "interface "

    invoke-virtual {v8, v9}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    .line 94
    :goto_1
    move-object v8, v1

    move-object v9, v0

    iget-object v9, v9, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    move-object v10, v5

    iget v10, v10, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->nameIndex:I

    invoke-virtual {v9, v10}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->getString(I)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    .line 96
    move-object v8, v0

    move-object v9, v1

    move-object v10, v5

    move v11, v6

    invoke-direct {v8, v9, v10, v11}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->writeInheritance(Ljava/io/Writer;Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;Z)V

    .line 97
    move-object v8, v1

    new-instance v9, Ljava/lang/StringBuffer;

    move-object v13, v9

    move-object v9, v13

    move-object v10, v13

    invoke-direct {v10}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v10, Ljava/lang/StringBuffer;

    move-object v13, v10

    move-object v10, v13

    move-object v11, v13

    invoke-direct {v11}, Ljava/lang/StringBuffer;-><init>()V

    const-string v11, " // TypeDefIndex: "

    invoke-virtual {v10, v11}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v10

    move v11, v2

    invoke-virtual {v10, v11}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    const-string v10, "\n{\n"

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    .line 99
    move-object v8, v0

    move-object v9, v1

    move-object v10, v5

    move v11, v2

    invoke-direct {v8, v9, v10, v11}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->writeFields(Ljava/io/Writer;Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;I)V

    .line 100
    move-object v8, v0

    move-object v9, v1

    move-object v10, v5

    move v11, v3

    invoke-direct {v8, v9, v10, v11}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->writeMethods(Ljava/io/Writer;Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;I)V

    .line 102
    move-object v8, v1

    const-string v9, "}\n\n"

    invoke-virtual {v8, v9}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    return-void

    .line 84
    :cond_1
    const/4 v8, 0x1

    goto :goto_0

    .line 87
    :cond_2
    move v8, v6

    if-eqz v8, :cond_3

    .line 88
    move-object v8, v1

    const-string v9, "enum "

    invoke-virtual {v8, v9}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    goto :goto_1

    .line 89
    :cond_3
    move-object v8, v0

    iget-object v8, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->types:Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;

    if-eqz v8, :cond_4

    move-object v8, v0

    iget-object v8, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->types:Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;

    move-object v9, v5

    invoke-virtual {v8, v9}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/TypeResolver;->isStruct(Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;)Z

    move-result v8

    if-eqz v8, :cond_4

    .line 90
    move-object v8, v1

    const-string v9, "struct "

    invoke-virtual {v8, v9}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    goto :goto_1

    .line 92
    :cond_4
    move-object v8, v1

    const-string v9, "class "

    invoke-virtual {v8, v9}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    goto/16 :goto_1
.end method


# virtual methods
.method public writeTo(Ljava/io/File;)V
    .locals 23
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/io/File;",
            ")V^",
            "Ljava/lang/Exception;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .prologue
    .line 46
    move-object/from16 v1, p0

    move-object/from16 v2, p1

    new-instance v14, Ljava/io/BufferedWriter;

    move-object/from16 v22, v14

    move-object/from16 v14, v22

    move-object/from16 v15, v22

    new-instance v16, Ljava/io/OutputStreamWriter;

    move-object/from16 v22, v16

    move-object/from16 v16, v22

    move-object/from16 v17, v22

    new-instance v18, Ljava/io/FileOutputStream;

    move-object/from16 v22, v18

    move-object/from16 v18, v22

    move-object/from16 v19, v22

    move-object/from16 v20, v2

    invoke-direct/range {v19 .. v20}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    const-string v19, "UTF-8"

    invoke-direct/range {v17 .. v19}, Ljava/io/OutputStreamWriter;-><init>(Ljava/io/OutputStream;Ljava/lang/String;)V

    const/high16 v17, 0x10000

    invoke-direct/range {v15 .. v17}, Ljava/io/BufferedWriter;-><init>(Ljava/io/Writer;I)V

    move-object v4, v14

    .line 49
    move-object v14, v1

    :try_start_0
    iget-object v14, v14, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    invoke-virtual {v14}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->images()[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ImageDefinition;

    move-result-object v14

    move-object v9, v14

    .line 50
    const/4 v14, 0x0

    move v10, v14

    :goto_0
    move v14, v10

    move-object v15, v9

    array-length v15, v15

    if-lt v14, v15, :cond_1

    .line 54
    move-object v14, v4

    const-string v15, "\n"

    invoke-virtual {v14, v15}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    .line 56
    move-object v14, v9

    array-length v14, v14

    const/4 v15, 0x0

    if-le v14, v15, :cond_6

    .line 57
    const/4 v14, 0x0

    move v10, v14

    :goto_1
    move v14, v10

    move-object v15, v9

    array-length v15, v15
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-lt v14, v15, :cond_2

    .line 72
    :cond_0
    move-object v14, v4

    invoke-virtual {v14}, Ljava/io/Writer;->close()V

    return-void

    .line 51
    :cond_1
    move-object v14, v4

    :try_start_1
    new-instance v15, Ljava/lang/StringBuffer;

    move-object/from16 v22, v15

    move-object/from16 v15, v22

    move-object/from16 v16, v22

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v16, Ljava/lang/StringBuffer;

    move-object/from16 v22, v16

    move-object/from16 v16, v22

    move-object/from16 v17, v22

    invoke-direct/range {v17 .. v17}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v17, Ljava/lang/StringBuffer;

    move-object/from16 v22, v17

    move-object/from16 v17, v22

    move-object/from16 v18, v22

    invoke-direct/range {v18 .. v18}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v18, Ljava/lang/StringBuffer;

    move-object/from16 v22, v18

    move-object/from16 v18, v22

    move-object/from16 v19, v22

    invoke-direct/range {v19 .. v19}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v19, Ljava/lang/StringBuffer;

    move-object/from16 v22, v19

    move-object/from16 v19, v22

    move-object/from16 v20, v22

    invoke-direct/range {v20 .. v20}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v20, Ljava/lang/StringBuffer;

    move-object/from16 v22, v20

    move-object/from16 v20, v22

    move-object/from16 v21, v22

    invoke-direct/range {v21 .. v21}, Ljava/lang/StringBuffer;-><init>()V

    const-string v21, "// Image "

    invoke-virtual/range {v20 .. v21}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v20

    move/from16 v21, v10

    invoke-virtual/range {v20 .. v21}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v20

    invoke-virtual/range {v20 .. v20}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v19

    const-string v20, ": "

    invoke-virtual/range {v19 .. v20}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v19

    invoke-virtual/range {v19 .. v19}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v19

    invoke-virtual/range {v18 .. v19}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v18

    move-object/from16 v19, v1

    move-object/from16 v0, v19

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    move-object/from16 v19, v0

    move-object/from16 v20, v9

    move/from16 v21, v10

    aget-object v20, v20, v21

    move-object/from16 v0, v20

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ImageDefinition;->nameIndex:I

    move/from16 v20, v0

    invoke-virtual/range {v19 .. v20}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->getString(I)Ljava/lang/String;

    move-result-object v19

    invoke-virtual/range {v18 .. v19}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v18

    invoke-virtual/range {v18 .. v18}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v18

    invoke-virtual/range {v17 .. v18}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v17

    const-string v18, " - "

    invoke-virtual/range {v17 .. v18}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v17

    invoke-virtual/range {v17 .. v17}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v17

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v16

    move-object/from16 v17, v9

    move/from16 v18, v10

    aget-object v17, v17, v18

    move-object/from16 v0, v17

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ImageDefinition;->typeStart:I

    move/from16 v17, v0

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v16

    invoke-virtual/range {v15 .. v16}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v15

    const-string v16, "\n"

    invoke-virtual/range {v15 .. v16}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v14, v15}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    .line 50
    add-int/lit8 v10, v10, 0x1

    goto/16 :goto_0

    .line 58
    :cond_2
    move-object v14, v9

    move v15, v10

    aget-object v14, v14, v15

    iget v14, v14, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ImageDefinition;->typeStart:I

    move-object v15, v9

    move/from16 v16, v10

    aget-object v15, v15, v16

    iget v15, v15, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ImageDefinition;->typeCount:I

    add-int/2addr v14, v15

    move v11, v14

    .line 59
    move-object v14, v9

    move v15, v10

    aget-object v14, v14, v15

    iget v14, v14, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ImageDefinition;->typeStart:I

    move v12, v14

    .line 60
    :goto_2
    move v14, v12

    move v15, v11

    if-ge v14, v15, :cond_3

    move v14, v12

    move-object v15, v1

    iget-object v15, v15, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    invoke-virtual {v15}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->types()[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;

    move-result-object v15

    array-length v15, v15

    if-lt v14, v15, :cond_4

    .line 57
    :cond_3
    add-int/lit8 v10, v10, 0x1

    goto/16 :goto_1

    .line 61
    :cond_4
    move v14, v12

    const/4 v15, 0x0

    if-lt v14, v15, :cond_5

    .line 62
    move-object v14, v1

    move-object v15, v4

    move/from16 v16, v12

    move/from16 v17, v10

    invoke-direct/range {v14 .. v17}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->writeType(Ljava/io/Writer;II)V

    .line 60
    :cond_5
    add-int/lit8 v12, v12, 0x1

    goto :goto_2

    .line 67
    :cond_6
    const/4 v14, 0x0

    move v10, v14

    :goto_3
    move v14, v10

    move-object v15, v1

    iget-object v15, v15, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    invoke-virtual {v15}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->types()[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;

    move-result-object v15

    array-length v15, v15

    if-ge v14, v15, :cond_0

    .line 68
    move-object v14, v1

    move-object v15, v4

    move/from16 v16, v10

    const/16 v17, -0x1

    invoke-direct/range {v14 .. v17}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/DumpWriter;->writeType(Ljava/io/Writer;II)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 67
    add-int/lit8 v10, v10, 0x1

    goto :goto_3

    :catchall_0
    move-exception v14

    move-object v5, v14

    .line 72
    move-object v14, v4

    invoke-virtual {v14}, Ljava/io/Writer;->close()V

    move-object v14, v5

    throw v14
.end method
