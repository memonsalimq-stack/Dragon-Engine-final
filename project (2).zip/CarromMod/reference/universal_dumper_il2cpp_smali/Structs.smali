.class public final Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs;
.super Ljava/lang/Object;
.source "Structs.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;,
        Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;,
        Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$FieldDefinition;,
        Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ParameterDefinition;,
        Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ImageDefinition;
    }
.end annotation


# direct methods
.method constructor <init>()V
    .locals 3

    .prologue
    .line 15
    move-object v0, p0

    move-object v2, v0

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    return-void
.end method
