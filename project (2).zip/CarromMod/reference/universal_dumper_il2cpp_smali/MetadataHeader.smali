.class public Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;
.super Ljava/lang/Object;
.source "MetadataHeader.java"


# static fields
.field public static final SANITY:I = -0x54ee451


# instance fields
.field private final tables:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map",
            "<",
            "Ljava/lang/String;",
            "[I>;"
        }
    .end annotation
.end field

.field private final version:D


# direct methods
.method constructor <init>(DLjava/util/Map;)V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(D",
            "Ljava/util/Map",
            "<",
            "Ljava/lang/String;",
            "[I>;)V"
        }
    .end annotation

    .prologue
    .line 29
    move-object v0, p0

    move-wide v1, p1

    move-object v3, p3

    move-object v5, v0

    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    .line 30
    move-object v5, v0

    move-wide v6, v1

    iput-wide v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;->version:D

    .line 31
    move-object v5, v0

    move-object v6, v3

    iput-object v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;->tables:Ljava/util/Map;

    return-void
.end method

.method private static candidatesFor(I)Ljava/util/List;
    .locals 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/List",
            "<",
            "Ljava/lang/Double;",
            ">;"
        }
    .end annotation

    .prologue
    .line 153
    move v0, p0

    new-instance v4, Ljava/util/ArrayList;

    move-object v10, v4

    move-object v4, v10

    move-object v5, v10

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    move-object v2, v4

    .line 154
    move v4, v0

    const/16 v5, 0x18

    if-ne v4, v5, :cond_0

    .line 157
    move-object v4, v2

    const-wide/high16 v5, 0x4038000000000000L    # 24.0

    new-instance v7, Ljava/lang/Double;

    move-wide v10, v5

    move-object v12, v7

    move-object v5, v12

    move-wide v6, v10

    move-object v8, v12

    move-wide v10, v6

    move-object v12, v8

    move-object v6, v12

    move-wide v7, v10

    move-object v9, v12

    invoke-direct {v6, v7, v8}, Ljava/lang/Double;-><init>(D)V

    invoke-interface {v4, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v4

    .line 158
    move-object v4, v2

    const-wide v5, 0x403819999999999aL    # 24.1

    new-instance v7, Ljava/lang/Double;

    move-wide v10, v5

    move-object v12, v7

    move-object v5, v12

    move-wide v6, v10

    move-object v8, v12

    move-wide v10, v6

    move-object v12, v8

    move-object v6, v12

    move-wide v7, v10

    move-object v9, v12

    invoke-direct {v6, v7, v8}, Ljava/lang/Double;-><init>(D)V

    invoke-interface {v4, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v4

    .line 159
    move-object v4, v2

    const-wide v5, 0x4038333333333333L    # 24.2

    new-instance v7, Ljava/lang/Double;

    move-wide v10, v5

    move-object v12, v7

    move-object v5, v12

    move-wide v6, v10

    move-object v8, v12

    move-wide v10, v6

    move-object v12, v8

    move-object v6, v12

    move-wide v7, v10

    move-object v9, v12

    invoke-direct {v6, v7, v8}, Ljava/lang/Double;-><init>(D)V

    invoke-interface {v4, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v4

    .line 170
    :goto_0
    move-object v4, v2

    move-object v0, v4

    return-object v0

    .line 160
    :cond_0
    move v4, v0

    const/16 v5, 0x1b

    if-ne v4, v5, :cond_1

    .line 161
    move-object v4, v2

    const-wide/high16 v5, 0x403b000000000000L    # 27.0

    new-instance v7, Ljava/lang/Double;

    move-wide v10, v5

    move-object v12, v7

    move-object v5, v12

    move-wide v6, v10

    move-object v8, v12

    move-wide v10, v6

    move-object v12, v8

    move-object v6, v12

    move-wide v7, v10

    move-object v9, v12

    invoke-direct {v6, v7, v8}, Ljava/lang/Double;-><init>(D)V

    invoke-interface {v4, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v4

    .line 162
    move-object v4, v2

    const-wide v5, 0x403b19999999999aL    # 27.1

    new-instance v7, Ljava/lang/Double;

    move-wide v10, v5

    move-object v12, v7

    move-object v5, v12

    move-wide v6, v10

    move-object v8, v12

    move-wide v10, v6

    move-object v12, v8

    move-object v6, v12

    move-wide v7, v10

    move-object v9, v12

    invoke-direct {v6, v7, v8}, Ljava/lang/Double;-><init>(D)V

    invoke-interface {v4, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v4

    .line 163
    move-object v4, v2

    const-wide v5, 0x403b333333333333L    # 27.2

    new-instance v7, Ljava/lang/Double;

    move-wide v10, v5

    move-object v12, v7

    move-object v5, v12

    move-wide v6, v10

    move-object v8, v12

    move-wide v10, v6

    move-object v12, v8

    move-object v6, v12

    move-wide v7, v10

    move-object v9, v12

    invoke-direct {v6, v7, v8}, Ljava/lang/Double;-><init>(D)V

    invoke-interface {v4, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v4

    goto :goto_0

    .line 164
    :cond_1
    move v4, v0

    const/16 v5, 0x1d

    if-ne v4, v5, :cond_2

    .line 165
    move-object v4, v2

    const-wide/high16 v5, 0x403d000000000000L    # 29.0

    new-instance v7, Ljava/lang/Double;

    move-wide v10, v5

    move-object v12, v7

    move-object v5, v12

    move-wide v6, v10

    move-object v8, v12

    move-wide v10, v6

    move-object v12, v8

    move-object v6, v12

    move-wide v7, v10

    move-object v9, v12

    invoke-direct {v6, v7, v8}, Ljava/lang/Double;-><init>(D)V

    invoke-interface {v4, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v4

    .line 166
    move-object v4, v2

    const-wide v5, 0x403d19999999999aL    # 29.1

    new-instance v7, Ljava/lang/Double;

    move-wide v10, v5

    move-object v12, v7

    move-object v5, v12

    move-wide v6, v10

    move-object v8, v12

    move-wide v10, v6

    move-object v12, v8

    move-object v6, v12

    move-wide v7, v10

    move-object v9, v12

    invoke-direct {v6, v7, v8}, Ljava/lang/Double;-><init>(D)V

    invoke-interface {v4, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v4

    goto/16 :goto_0

    .line 168
    :cond_2
    move-object v4, v2

    move v5, v0

    int-to-double v5, v5

    new-instance v7, Ljava/lang/Double;

    move-wide v10, v5

    move-object v12, v7

    move-object v5, v12

    move-wide v6, v10

    move-object v8, v12

    move-wide v10, v6

    move-object v12, v8

    move-object v6, v12

    move-wide v7, v10

    move-object v9, v12

    invoke-direct {v6, v7, v8}, Ljava/lang/Double;-><init>(D)V

    invoke-interface {v4, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v4

    goto/16 :goto_0
.end method

.method private static layoutFor(D)Ljava/util/List;
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(D)",
            "Ljava/util/List",
            "<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .prologue
    .line 181
    move-wide v1, p0

    new-instance v6, Ljava/util/ArrayList;

    move-object v10, v6

    move-object v6, v10

    move-object v7, v10

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    move-object v4, v6

    .line 183
    move-object v6, v4

    const-string v7, "stringLiteral"

    invoke-interface {v6, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v6

    .line 184
    move-object v6, v4

    const-string v7, "stringLiteralData"

    invoke-interface {v6, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v6

    .line 185
    move-object v6, v4

    const-string v7, "string"

    invoke-interface {v6, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v6

    .line 186
    move-object v6, v4

    const-string v7, "events"

    invoke-interface {v6, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v6

    .line 187
    move-object v6, v4

    const-string v7, "properties"

    invoke-interface {v6, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v6

    .line 188
    move-object v6, v4

    const-string v7, "methods"

    invoke-interface {v6, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v6

    .line 189
    move-object v6, v4

    const-string v7, "parameterDefaultValues"

    invoke-interface {v6, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v6

    .line 190
    move-object v6, v4

    const-string v7, "fieldDefaultValues"

    invoke-interface {v6, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v6

    .line 191
    move-object v6, v4

    const-string v7, "fieldAndParameterDefaultValueData"

    invoke-interface {v6, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v6

    .line 192
    move-object v6, v4

    const-string v7, "fieldMarshaledSizes"

    invoke-interface {v6, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v6

    .line 193
    move-object v6, v4

    const-string v7, "parameters"

    invoke-interface {v6, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v6

    .line 194
    move-object v6, v4

    const-string v7, "fields"

    invoke-interface {v6, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v6

    .line 195
    move-object v6, v4

    const-string v7, "genericParameters"

    invoke-interface {v6, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v6

    .line 196
    move-object v6, v4

    const-string v7, "genericParameterConstraints"

    invoke-interface {v6, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v6

    .line 197
    move-object v6, v4

    const-string v7, "genericContainers"

    invoke-interface {v6, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v6

    .line 198
    move-object v6, v4

    const-string v7, "nestedTypes"

    invoke-interface {v6, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v6

    .line 199
    move-object v6, v4

    const-string v7, "interfaces"

    invoke-interface {v6, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v6

    .line 200
    move-object v6, v4

    const-string v7, "vtableMethods"

    invoke-interface {v6, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v6

    .line 201
    move-object v6, v4

    const-string v7, "interfaceOffsets"

    invoke-interface {v6, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v6

    .line 202
    move-object v6, v4

    const-string v7, "typeDefinitions"

    invoke-interface {v6, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v6

    .line 204
    move-wide v6, v1

    const-wide v8, 0x403819999999999aL    # 24.1

    cmpg-double v6, v6, v8

    if-gtz v6, :cond_0

    .line 205
    move-object v6, v4

    const-string v7, "rgctxEntries"

    invoke-interface {v6, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v6

    .line 208
    :cond_0
    move-object v6, v4

    const-string v7, "images"

    invoke-interface {v6, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v6

    .line 209
    move-object v6, v4

    const-string v7, "assemblies"

    invoke-interface {v6, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v6

    .line 211
    move-wide v6, v1

    const-wide v8, 0x4038800000000000L    # 24.5

    cmpg-double v6, v6, v8

    if-gtz v6, :cond_1

    .line 212
    move-object v6, v4

    const-string v7, "metadataUsageLists"

    invoke-interface {v6, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v6

    .line 213
    move-object v6, v4

    const-string v7, "metadataUsagePairs"

    invoke-interface {v6, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v6

    .line 216
    :cond_1
    move-object v6, v4

    const-string v7, "fieldRefs"

    invoke-interface {v6, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v6

    .line 217
    move-object v6, v4

    const-string v7, "referencedAssemblies"

    invoke-interface {v6, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v6

    .line 219
    move-wide v6, v1

    const/16 v8, 0x1d

    int-to-double v8, v8

    cmpg-double v6, v6, v8

    if-gez v6, :cond_7

    .line 220
    move-object v6, v4

    const-string v7, "attributesInfo"

    invoke-interface {v6, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v6

    .line 221
    move-object v6, v4

    const-string v7, "attributeTypes"

    invoke-interface {v6, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v6

    .line 227
    :goto_0
    move-wide v6, v1

    const/16 v8, 0x13

    int-to-double v8, v8

    cmpl-double v6, v6, v8

    if-ltz v6, :cond_2

    move-wide v6, v1

    const-wide v8, 0x4038800000000000L    # 24.5

    cmpg-double v6, v6, v8

    if-gtz v6, :cond_2

    .line 228
    move-object v6, v4

    const-string v7, "unresolvedVirtualCallParameterTypes"

    invoke-interface {v6, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v6

    .line 229
    move-object v6, v4

    const-string v7, "unresolvedVirtualCallParameterRanges"

    invoke-interface {v6, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v6

    .line 231
    :cond_2
    move-wide v6, v1

    const/16 v8, 0x1d

    int-to-double v8, v8

    cmpl-double v6, v6, v8

    if-ltz v6, :cond_3

    .line 233
    move-object v6, v4

    const-string v7, "unresolvedIndirectCallParameterTypes"

    invoke-interface {v6, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v6

    .line 234
    move-object v6, v4

    const-string v7, "unresolvedIndirectCallParameterRanges"

    invoke-interface {v6, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v6

    .line 236
    :cond_3
    move-wide v6, v1

    const/16 v8, 0x15

    int-to-double v8, v8

    cmpl-double v6, v6, v8

    if-ltz v6, :cond_4

    .line 237
    move-object v6, v4

    const-string v7, "windowsRuntimeTypeNames"

    invoke-interface {v6, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v6

    .line 239
    :cond_4
    move-wide v6, v1

    const/16 v8, 0x1b

    int-to-double v8, v8

    cmpl-double v6, v6, v8

    if-ltz v6, :cond_5

    .line 240
    move-object v6, v4

    const-string v7, "windowsRuntimeStrings"

    invoke-interface {v6, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v6

    .line 242
    :cond_5
    move-wide v6, v1

    const/16 v8, 0x16

    int-to-double v8, v8

    cmpl-double v6, v6, v8

    if-ltz v6, :cond_6

    .line 243
    move-object v6, v4

    const-string v7, "exportedTypeDefinitions"

    invoke-interface {v6, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v6

    .line 246
    :cond_6
    move-object v6, v4

    move-object v1, v6

    return-object v1

    .line 223
    :cond_7
    move-object v6, v4

    const-string v7, "attributeData"

    invoke-interface {v6, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v6

    .line 224
    move-object v6, v4

    const-string v7, "attributeDataRange"

    invoke-interface {v6, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v6

    goto :goto_0
.end method

.method public static rawDump(Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;)Ljava/lang/String;
    .locals 22

    .prologue
    .line 111
    move-object/from16 v0, p0

    new-instance v12, Ljava/lang/StringBuilder;

    move-object/from16 v20, v12

    move-object/from16 v12, v20

    move-object/from16 v13, v20

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    move-object v2, v12

    .line 112
    move-object v12, v0

    const/16 v13, 0x8

    invoke-virtual {v12, v13}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readIntAt(I)I

    move-result v12

    move v3, v12

    .line 113
    move v12, v3

    const/16 v13, 0x8

    div-int/lit8 v12, v12, 0x8

    const/4 v13, 0x1

    add-int/lit8 v12, v12, -0x1

    move v4, v12

    .line 114
    move-object v12, v2

    const-string v13, "\u0421\u044b\u0440\u043e\u0439 \u0437\u0430\u0433\u043e\u043b\u043e\u0432\u043e\u043a: magic=0x"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    move-object v13, v0

    const/4 v14, 0x0

    invoke-virtual {v13, v14}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readIntAt(I)I

    move-result v13

    invoke-static {v13}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v13, ", version="

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    move-object v13, v0

    const/4 v14, 0x4

    invoke-virtual {v13, v14}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readIntAt(I)I

    move-result v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v13, ", \u0440\u0430\u0437\u043c\u0435\u0440="

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    move v13, v3

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v13, ", \u043f\u0430\u0440="

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    move v13, v4

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v13, ", \u0444\u0430\u0439\u043b="

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    move-object v13, v0

    invoke-virtual {v13}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->size()I

    move-result v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v13, "\n\n"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    .line 121
    const/4 v12, -0x1

    move v5, v12

    .line 122
    const/4 v12, 0x0

    move v6, v12

    :goto_0
    move v12, v6

    move v13, v4

    if-lt v12, v13, :cond_0

    .line 138
    :goto_1
    move-object v12, v2

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    move-object v0, v12

    return-object v0

    .line 123
    :cond_0
    const/16 v12, 0x8

    move v13, v6

    const/16 v14, 0x8

    mul-int/lit8 v13, v13, 0x8

    add-int/2addr v12, v13

    move v7, v12

    .line 124
    move v12, v7

    const/16 v13, 0x8

    add-int/lit8 v12, v12, 0x8

    move-object v13, v0

    invoke-virtual {v13}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->size()I

    move-result v13

    if-le v12, v13, :cond_1

    .line 125
    goto :goto_1

    .line 127
    :cond_1
    move-object v12, v0

    move v13, v7

    invoke-virtual {v12, v13}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readIntAt(I)I

    move-result v12

    move v8, v12

    .line 128
    move-object v12, v0

    move v13, v7

    const/4 v14, 0x4

    add-int/lit8 v13, v13, 0x4

    invoke-virtual {v12, v13}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readIntAt(I)I

    move-result v12

    move v9, v12

    .line 129
    const-string v12, ""

    move-object v10, v12

    .line 130
    move v12, v8

    move v13, v5

    if-ge v12, v13, :cond_3

    .line 131
    const-string v12, "  <-- \u0441\u043c\u0435\u0449\u0435\u043d\u0438\u0435 \u0443\u0431\u044b\u0432\u0430\u0435\u0442"

    move-object v10, v12

    .line 135
    :cond_2
    :goto_2
    move v12, v8

    move v5, v12

    .line 136
    move-object v12, v2

    const-string v13, "[%2d] offset=%-10d size=%-10d%s\n"

    const/4 v14, 0x4

    new-array v14, v14, [Ljava/lang/Object;

    move-object/from16 v20, v14

    move-object/from16 v14, v20

    move-object/from16 v15, v20

    const/16 v16, 0x0

    move/from16 v17, v6

    new-instance v18, Ljava/lang/Integer;

    move/from16 v20, v17

    move-object/from16 v21, v18

    move-object/from16 v17, v21

    move/from16 v18, v20

    move-object/from16 v19, v21

    move/from16 v20, v18

    move-object/from16 v21, v19

    move-object/from16 v18, v21

    move/from16 v19, v20

    invoke-direct/range {v18 .. v19}, Ljava/lang/Integer;-><init>(I)V

    aput-object v17, v15, v16

    move-object/from16 v20, v14

    move-object/from16 v14, v20

    move-object/from16 v15, v20

    const/16 v16, 0x1

    move/from16 v17, v8

    new-instance v18, Ljava/lang/Integer;

    move/from16 v20, v17

    move-object/from16 v21, v18

    move-object/from16 v17, v21

    move/from16 v18, v20

    move-object/from16 v19, v21

    move/from16 v20, v18

    move-object/from16 v21, v19

    move-object/from16 v18, v21

    move/from16 v19, v20

    invoke-direct/range {v18 .. v19}, Ljava/lang/Integer;-><init>(I)V

    aput-object v17, v15, v16

    move-object/from16 v20, v14

    move-object/from16 v14, v20

    move-object/from16 v15, v20

    const/16 v16, 0x2

    move/from16 v17, v9

    new-instance v18, Ljava/lang/Integer;

    move/from16 v20, v17

    move-object/from16 v21, v18

    move-object/from16 v17, v21

    move/from16 v18, v20

    move-object/from16 v19, v21

    move/from16 v20, v18

    move-object/from16 v21, v19

    move-object/from16 v18, v21

    move/from16 v19, v20

    invoke-direct/range {v18 .. v19}, Ljava/lang/Integer;-><init>(I)V

    aput-object v17, v15, v16

    move-object/from16 v20, v14

    move-object/from16 v14, v20

    move-object/from16 v15, v20

    const/16 v16, 0x3

    move-object/from16 v17, v10

    aput-object v17, v15, v16

    invoke-static {v13, v14}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    .line 122
    add-int/lit8 v6, v6, 0x1

    goto/16 :goto_0

    .line 132
    :cond_3
    move v12, v8

    int-to-long v12, v12

    move v14, v9

    int-to-long v14, v14

    add-long/2addr v12, v14

    move-object v14, v0

    invoke-virtual {v14}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->size()I

    move-result v14

    int-to-long v14, v14

    cmp-long v12, v12, v14

    if-lez v12, :cond_2

    .line 133
    const-string v12, "  <-- \u0432\u044b\u0445\u043e\u0434\u0438\u0442 \u0437\u0430 \u0444\u0430\u0439\u043b"

    move-object v10, v12

    goto/16 :goto_2
.end method

.method public static read(Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;)Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;
    .locals 26

    .prologue
    .line 65
    move-object/from16 v1, p0

    move-object v14, v1

    const/4 v15, 0x0

    invoke-virtual {v14, v15}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->seek(I)V

    .line 66
    move-object v14, v1

    invoke-virtual {v14}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readInt()I

    move-result v14

    move v3, v14

    .line 67
    move v14, v3

    const v15, -0x54ee451

    if-eq v14, v15, :cond_0

    .line 68
    new-instance v14, Lcom/Leon4ikMods/UniversalDumper/core/DumpException;

    move-object/from16 v24, v14

    move-object/from16 v14, v24

    move-object/from16 v15, v24

    new-instance v16, Ljava/lang/StringBuffer;

    move-object/from16 v24, v16

    move-object/from16 v16, v24

    move-object/from16 v17, v24

    invoke-direct/range {v17 .. v17}, Ljava/lang/StringBuffer;-><init>()V

    const-string v17, "\u043d\u0435 global-metadata.dat: magic 0x%08X, \u043e\u0436\u0438\u0434\u0430\u043b\u0441\u044f 0x%08X."

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v16

    const-string v17, " \u0415\u0441\u043b\u0438 \u0444\u0430\u0439\u043b \u0437\u0430\u0448\u0438\u0444\u0440\u043e\u0432\u0430\u043d \u2014 \u0441\u043d\u0430\u0447\u0430\u043b\u0430 \u043d\u0443\u0436\u043d\u0430 \u0440\u0430\u0441\u0448\u0438\u0444\u0440\u043e\u0432\u043a\u0430."

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v16

    const/16 v17, 0x2

    move/from16 v0, v17

    new-array v0, v0, [Ljava/lang/Object;

    move-object/from16 v17, v0

    move-object/from16 v24, v17

    move-object/from16 v17, v24

    move-object/from16 v18, v24

    const/16 v19, 0x0

    move/from16 v20, v3

    new-instance v21, Ljava/lang/Integer;

    move/from16 v24, v20

    move-object/from16 v25, v21

    move-object/from16 v20, v25

    move/from16 v21, v24

    move-object/from16 v22, v25

    move/from16 v24, v21

    move-object/from16 v25, v22

    move-object/from16 v21, v25

    move/from16 v22, v24

    invoke-direct/range {v21 .. v22}, Ljava/lang/Integer;-><init>(I)V

    aput-object v20, v18, v19

    move-object/from16 v24, v17

    move-object/from16 v17, v24

    move-object/from16 v18, v24

    const/16 v19, 0x1

    const v20, -0x54ee451

    new-instance v21, Ljava/lang/Integer;

    move/from16 v24, v20

    move-object/from16 v25, v21

    move-object/from16 v20, v25

    move/from16 v21, v24

    move-object/from16 v22, v25

    move/from16 v24, v21

    move-object/from16 v25, v22

    move-object/from16 v21, v25

    move/from16 v22, v24

    invoke-direct/range {v21 .. v22}, Ljava/lang/Integer;-><init>(I)V

    aput-object v20, v18, v19

    invoke-static/range {v16 .. v17}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v16

    invoke-direct/range {v15 .. v16}, Lcom/Leon4ikMods/UniversalDumper/core/DumpException;-><init>(Ljava/lang/String;)V

    throw v14

    .line 74
    :cond_0
    move-object v14, v1

    invoke-virtual {v14}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readInt()I

    move-result v14

    move v4, v14

    .line 75
    move v14, v4

    const/16 v15, 0x10

    if-lt v14, v15, :cond_1

    move v14, v4

    const/16 v15, 0x28

    if-le v14, v15, :cond_2

    .line 76
    :cond_1
    new-instance v14, Lcom/Leon4ikMods/UniversalDumper/core/DumpException;

    move-object/from16 v24, v14

    move-object/from16 v14, v24

    move-object/from16 v15, v24

    new-instance v16, Ljava/lang/StringBuffer;

    move-object/from16 v24, v16

    move-object/from16 v16, v24

    move-object/from16 v17, v24

    invoke-direct/range {v17 .. v17}, Ljava/lang/StringBuffer;-><init>()V

    const-string v17, "\u043d\u0435\u043f\u043e\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u043c\u0430\u044f \u0432\u0435\u0440\u0441\u0438\u044f \u043c\u0435\u0442\u0430\u0434\u0430\u043d\u043d\u044b\u0445: "

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v16

    move/from16 v17, v4

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v16

    invoke-direct/range {v15 .. v16}, Lcom/Leon4ikMods/UniversalDumper/core/DumpException;-><init>(Ljava/lang/String;)V

    throw v14

    .line 79
    :cond_2
    move-object v14, v1

    const/16 v15, 0x8

    invoke-virtual {v14, v15}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readIntAt(I)I

    move-result v14

    move v5, v14

    .line 81
    move v14, v4

    invoke-static {v14}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;->candidatesFor(I)Ljava/util/List;

    move-result-object v14

    move-object v6, v14

    .line 82
    new-instance v14, Ljava/lang/StringBuilder;

    move-object/from16 v24, v14

    move-object/from16 v14, v24

    move-object/from16 v15, v24

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    move-object v7, v14

    .line 84
    const/4 v14, 0x0

    move v8, v14

    :goto_0
    move v14, v8

    move-object v15, v6

    invoke-interface {v15}, Ljava/util/List;->size()I

    move-result v15

    if-lt v14, v15, :cond_3

    .line 99
    new-instance v14, Lcom/Leon4ikMods/UniversalDumper/core/DumpException;

    move-object/from16 v24, v14

    move-object/from16 v14, v24

    move-object/from16 v15, v24

    new-instance v16, Ljava/lang/StringBuffer;

    move-object/from16 v24, v16

    move-object/from16 v16, v24

    move-object/from16 v17, v24

    invoke-direct/range {v17 .. v17}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v17, Ljava/lang/StringBuffer;

    move-object/from16 v24, v17

    move-object/from16 v17, v24

    move-object/from16 v18, v24

    invoke-direct/range {v18 .. v18}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v18, Ljava/lang/StringBuffer;

    move-object/from16 v24, v18

    move-object/from16 v18, v24

    move-object/from16 v19, v24

    invoke-direct/range {v19 .. v19}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v19, Ljava/lang/StringBuffer;

    move-object/from16 v24, v19

    move-object/from16 v19, v24

    move-object/from16 v20, v24

    invoke-direct/range {v20 .. v20}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v20, Ljava/lang/StringBuffer;

    move-object/from16 v24, v20

    move-object/from16 v20, v24

    move-object/from16 v21, v24

    invoke-direct/range {v21 .. v21}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v21, Ljava/lang/StringBuffer;

    move-object/from16 v24, v21

    move-object/from16 v21, v24

    move-object/from16 v22, v24

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v22, Ljava/lang/StringBuffer;

    move-object/from16 v24, v22

    move-object/from16 v22, v24

    move-object/from16 v23, v24

    invoke-direct/range {v23 .. v23}, Ljava/lang/StringBuffer;-><init>()V

    const-string v23, "\u043d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043e\u043f\u0440\u0435\u0434\u0435\u043b\u0438\u0442\u044c \u0440\u0435\u0432\u0438\u0437\u0438\u044e \u043c\u0435\u0442\u0430\u0434\u0430\u043d\u043d\u044b\u0445 v"

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v22

    move/from16 v23, v4

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v21

    const-string v22, ": \u0440\u0430\u0437\u043c\u0435\u0440 \u0437\u0430\u0433\u043e\u043b\u043e\u0432\u043a\u0430 \u0432 \u0444\u0430\u0439\u043b\u0435 "

    invoke-virtual/range {v21 .. v22}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v21

    invoke-virtual/range {v21 .. v21}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v21

    invoke-virtual/range {v20 .. v21}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v20

    move/from16 v21, v5

    invoke-virtual/range {v20 .. v21}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v20

    invoke-virtual/range {v20 .. v20}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v19

    const-string v20, ", \u0440\u0430\u0437\u043c\u0435\u0440\u044b \u043a\u0430\u043d\u0434\u0438\u0434\u0430\u0442\u043e\u0432 ["

    invoke-virtual/range {v19 .. v20}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v19

    invoke-virtual/range {v19 .. v19}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v19

    invoke-virtual/range {v18 .. v19}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v18

    move-object/from16 v19, v7

    invoke-virtual/range {v18 .. v19}, Ljava/lang/StringBuffer;->append(Ljava/lang/Object;)Ljava/lang/StringBuffer;

    move-result-object v18

    invoke-virtual/range {v18 .. v18}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v18

    invoke-virtual/range {v17 .. v18}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v17

    const-string v18, "]."

    invoke-virtual/range {v17 .. v18}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v17

    invoke-virtual/range {v17 .. v17}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v17

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v16

    const-string v17, " \u041d\u0443\u0436\u043d\u043e \u043f\u043e\u043f\u0440\u0430\u0432\u0438\u0442\u044c layoutFor() \u0434\u043b\u044f \u044d\u0442\u043e\u0439 \u0432\u0435\u0440\u0441\u0438\u0438."

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v16

    invoke-direct/range {v15 .. v16}, Lcom/Leon4ikMods/UniversalDumper/core/DumpException;-><init>(Ljava/lang/String;)V

    throw v14

    .line 85
    :cond_3
    move-object v14, v6

    move v15, v8

    invoke-interface {v14, v15}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Ljava/lang/Double;

    check-cast v14, Ljava/lang/Double;

    invoke-virtual {v14}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v14

    move-wide v9, v14

    .line 86
    move-wide v14, v9

    invoke-static {v14, v15}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;->layoutFor(D)Ljava/util/List;

    move-result-object v14

    move-object v11, v14

    .line 87
    const/16 v14, 0x8

    move-object v15, v11

    invoke-interface {v15}, Ljava/util/List;->size()I

    move-result v15

    const/16 v16, 0x8

    mul-int/lit8 v15, v15, 0x8

    add-int/2addr v14, v15

    move v12, v14

    .line 89
    move-object v14, v7

    invoke-virtual {v14}, Ljava/lang/StringBuilder;->length()I

    move-result v14

    const/4 v15, 0x0

    if-le v14, v15, :cond_4

    .line 90
    move-object v14, v7

    const-string v15, ", "

    invoke-virtual {v14, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v14

    .line 92
    :cond_4
    move-object v14, v7

    move-wide v15, v9

    invoke-virtual/range {v14 .. v16}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    move-result-object v14

    const-string v15, "=>"

    invoke-virtual {v14, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v14

    move v15, v12

    invoke-virtual {v14, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v14

    .line 94
    move v14, v12

    move v15, v5

    if-ne v14, v15, :cond_5

    .line 95
    new-instance v14, Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;

    move-object/from16 v24, v14

    move-object/from16 v14, v24

    move-object/from16 v15, v24

    move-wide/from16 v16, v9

    move-object/from16 v18, v1

    move-object/from16 v19, v11

    invoke-static/range {v18 .. v19}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;->readTables(Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;Ljava/util/List;)Ljava/util/Map;

    move-result-object v18

    invoke-direct/range {v15 .. v18}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;-><init>(DLjava/util/Map;)V

    move-object v1, v14

    return-object v1

    .line 84
    :cond_5
    add-int/lit8 v8, v8, 0x1

    goto/16 :goto_0
.end method

.method private static readTables(Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;Ljava/util/List;)Ljava/util/Map;
    .locals 15
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;",
            "Ljava/util/List",
            "<",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/util/Map",
            "<",
            "Ljava/lang/String;",
            "[I>;"
        }
    .end annotation

    .prologue
    .line 142
    move-object v0, p0

    move-object/from16 v1, p1

    new-instance v8, Ljava/util/LinkedHashMap;

    move-object v14, v8

    move-object v8, v14

    move-object v9, v14

    invoke-direct {v9}, Ljava/util/LinkedHashMap;-><init>()V

    move-object v3, v8

    .line 143
    move-object v8, v0

    const/16 v9, 0x8

    invoke-virtual {v8, v9}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->seek(I)V

    .line 144
    const/4 v8, 0x0

    move v4, v8

    :goto_0
    move v8, v4

    move-object v9, v1

    invoke-interface {v9}, Ljava/util/List;->size()I

    move-result v9

    if-lt v8, v9, :cond_0

    .line 149
    move-object v8, v3

    move-object v0, v8

    return-object v0

    .line 145
    :cond_0
    move-object v8, v0

    invoke-virtual {v8}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readInt()I

    move-result v8

    move v5, v8

    .line 146
    move-object v8, v0

    invoke-virtual {v8}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readInt()I

    move-result v8

    move v6, v8

    .line 147
    move-object v8, v3

    move-object v9, v1

    move v10, v4

    invoke-interface {v9, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    const/4 v10, 0x2

    new-array v10, v10, [I

    move-object v14, v10

    move-object v10, v14

    move-object v11, v14

    const/4 v12, 0x0

    move v13, v5

    aput v13, v11, v12

    move-object v14, v10

    move-object v10, v14

    move-object v11, v14

    const/4 v12, 0x1

    move v13, v6

    aput v13, v11, v12

    invoke-interface {v8, v9, v10}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    .line 144
    add-int/lit8 v4, v4, 0x1

    goto :goto_0
.end method


# virtual methods
.method public count(Ljava/lang/String;)I
    .locals 12

    .prologue
    .line 51
    move-object v0, p0

    move-object v1, p1

    move-object v5, v0

    iget-object v5, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;->tables:Ljava/util/Map;

    move-object v6, v1

    invoke-interface {v5, v6}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, [I

    move-object v3, v5

    .line 52
    move-object v5, v3

    if-nez v5, :cond_0

    .line 53
    new-instance v5, Lcom/Leon4ikMods/UniversalDumper/core/DumpException;

    move-object v11, v5

    move-object v5, v11

    move-object v6, v11

    new-instance v7, Ljava/lang/StringBuffer;

    move-object v11, v7

    move-object v7, v11

    move-object v8, v11

    invoke-direct {v8}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v8, Ljava/lang/StringBuffer;

    move-object v11, v8

    move-object v8, v11

    move-object v9, v11

    invoke-direct {v9}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v9, Ljava/lang/StringBuffer;

    move-object v11, v9

    move-object v9, v11

    move-object v10, v11

    invoke-direct {v10}, Ljava/lang/StringBuffer;-><init>()V

    const-string v10, "\u0442\u0430\u0431\u043b\u0438\u0446\u044b \'"

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    move-object v10, v1

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    const-string v9, "\' \u043d\u0435\u0442 \u0432 \u0432\u0435\u0440\u0441\u0438\u0438 "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v7

    move-object v8, v0

    iget-wide v8, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;->version:D

    invoke-virtual {v7, v8, v9}, Ljava/lang/StringBuffer;->append(D)Ljava/lang/StringBuffer;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-direct {v6, v7}, Lcom/Leon4ikMods/UniversalDumper/core/DumpException;-><init>(Ljava/lang/String;)V

    throw v5

    .line 55
    :cond_0
    move-object v5, v3

    const/4 v6, 0x1

    aget v5, v5, v6

    move v0, v5

    return v0
.end method

.method public has(Ljava/lang/String;)Z
    .locals 5

    .prologue
    .line 39
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    iget-object v3, v3, Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;->tables:Ljava/util/Map;

    move-object v4, v1

    invoke-interface {v3, v4}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v3

    move v0, v3

    return v0
.end method

.method public offset(Ljava/lang/String;)I
    .locals 12

    .prologue
    .line 43
    move-object v0, p0

    move-object v1, p1

    move-object v5, v0

    iget-object v5, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;->tables:Ljava/util/Map;

    move-object v6, v1

    invoke-interface {v5, v6}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, [I

    move-object v3, v5

    .line 44
    move-object v5, v3

    if-nez v5, :cond_0

    .line 45
    new-instance v5, Lcom/Leon4ikMods/UniversalDumper/core/DumpException;

    move-object v11, v5

    move-object v5, v11

    move-object v6, v11

    new-instance v7, Ljava/lang/StringBuffer;

    move-object v11, v7

    move-object v7, v11

    move-object v8, v11

    invoke-direct {v8}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v8, Ljava/lang/StringBuffer;

    move-object v11, v8

    move-object v8, v11

    move-object v9, v11

    invoke-direct {v9}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v9, Ljava/lang/StringBuffer;

    move-object v11, v9

    move-object v9, v11

    move-object v10, v11

    invoke-direct {v10}, Ljava/lang/StringBuffer;-><init>()V

    const-string v10, "\u0442\u0430\u0431\u043b\u0438\u0446\u044b \'"

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    move-object v10, v1

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    const-string v9, "\' \u043d\u0435\u0442 \u0432 \u0432\u0435\u0440\u0441\u0438\u0438 "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v7

    move-object v8, v0

    iget-wide v8, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;->version:D

    invoke-virtual {v7, v8, v9}, Ljava/lang/StringBuffer;->append(D)Ljava/lang/StringBuffer;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-direct {v6, v7}, Lcom/Leon4ikMods/UniversalDumper/core/DumpException;-><init>(Ljava/lang/String;)V

    throw v5

    .line 47
    :cond_0
    move-object v5, v3

    const/4 v6, 0x0

    aget v5, v5, v6

    move v0, v5

    return v0
.end method

.method public tables()Ljava/util/Map;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map",
            "<",
            "Ljava/lang/String;",
            "[I>;"
        }
    .end annotation

    .prologue
    .line 59
    move-object v0, p0

    move-object v2, v0

    iget-object v2, v2, Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;->tables:Ljava/util/Map;

    move-object v0, v2

    return-object v0
.end method

.method public version()D
    .locals 4

    .prologue
    .line 35
    move-object v0, p0

    move-object v2, v0

    iget-wide v2, v2, Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;->version:D

    move-wide v0, v2

    return-wide v0
.end method
