# HANDOFF: CarromMod

## Request (latest, Hinglish)
One project, shaped like the Easy Victory (EV) loader from the reference APK: Java loader +
native lib + mod menu. Carrom Pool first, 8 Ball Pool after. No offsets filled in — structure
only, so the user can add offsets themselves and build/test on their own modified APK. Add more
menu options/features, and an "offset tester" that can test/dump the game's latest offsets.
Also: save the dump.cs / future offset files the user provides so work can continue from them.

## What exists now (this session)
Single project at `/mnt/user-data/outputs/CarromMod/`. See `README.md` for the full layout.
Everything under `jni/src/` is new code, written against the old DARK_OWNER project's logic
(Prediction.h, AutoPlay.h ported almost line-for-line) and third-party libs (Dobby, ImGui,
stb_image copied in), but restructured so:
- every game offset lives in one place (`config/Offsets.h`), starts unset, and is loaded from a
  device-side config file at runtime — no offset is compiled in, matching "abhi offset mat dalo"
- the menu is the old DARK_OWNER look (gold theme) with four tabs now instead of three: the new
  **TESTER** tab is the offset tester the user asked for (read any RVA / pointer chain as every
  numeric type, read arrays, save/export/persist findings) — see `logic/OffsetTester.h/.cpp`
- the loader is EV-shaped: `loader/java/.../MainActivity.java` mirrors
  `com.easyvictory.mods.MainActivity.Start(Context)` from the reference APK exactly (confirmed by
  decompiling `classes13.dex` and `classes8.dex` of `Easy_Victory_...apk.bak` with androguard:
  `CarromActivity.onCreate` calls `MainActivity.Start(Context)` right after `super.onCreate()`,
  which then does `System.loadLibrary("Crash")`). `loader/README.md` has the exact smali patch
  this session confirmed, generalized to this project's loader class name.
- `main.cpp`'s two JNI exports (`nativeOverlayTouch`, `nativeDumperTouch`) and the touch sink's
  function-pointer signatures are unchanged from the old DARK_OWNER `input.h`, confirmed again
  this session against the CURRENT game library (see below).

## Measured this session
- Extracted `lib/arm64-v8a/libgame-CARROM-GooglePlay-Gold-Release-Module-1492.so` from the
  user's `Easy_Victory_Life_Time_Free_Finel_Update_19_6_1_apk.bak` (48,998,992 bytes, 3 LOAD
  segments, SONAME says `...-Module-1491.so` — a version mismatch between filename and SONAME
  that is worth double-checking before trusting any offset measured on it).
- `CarromActivity.onCreate` (from `classes8.dex` inside that same apk.bak) sets the native
  library name to `"game-CARROM-GooglePlay-Gold-Release-Module-1492"` before calling
  `setNativeLibraryName` — confirms the extracted .so is the one actually loaded.
- Confirmed `Java_com_miniclip_input_MCInput_nativeTouchesBegin` exists in that library
  (disassembled its prologue: takes an index + two floats + two booleans, matches the old
  project's `TouchBeginFn` signature). Its RVA (`0x26da5b4`) is NOT written into Offsets.h or
  anywhere else — the user asked for structure only; this is just confirmation the symbol-based
  approach (`sym.touches_begin` etc. in Offsets.h) is viable.
- `AndroidManifest.xml` of the apk.bak: package `com.easyvictory.mods` is NOT the target; the
  actual game package is read from the manifest's `<manifest package="...">` — not re-derived
  here since the project only needs the module file name, which is already confirmed above.
- `Carrom_Pool_Dump.cs` is an iOS-side dump (classes carry `// RVA: 0x1...` in iOS text-segment
  address space, not Android .so RVAs) and does NOT contain the Android-side class names the old
  DARK_OWNER project's offsets referred to (`VisualStriker`, `CarromGameManager`, `BoardProperties`,
  etc. all return 0 hits). It is saved under `reference/` for whatever it's worth (class/field
  names, general structure) but it cannot supply Android RVAs or field offsets directly.
- `Carrom_Disc_Pool_19_6_1...src.zip` and the various `.rar`/`.7z` 8 Ball Pool archives were
  uploaded but not yet opened this session (time went to the Carrom Pool menu + tester first, as
  asked: "sabse phle carrom pool keliye").

## Built / tested (host, this session)
7 test suites, all passing, via `tests/run_tests.sh`:
`test_logic` (54), `test_config` (35), `test_bridge` (53), `test_offset_tester` (52),
`test_executor` (63), `test_app` (24), `test_ui` (26) = 307 checks, 0 failures.
Plus a syntax-only check (not a real NDK build — see below) of the four Android-only files
(`platform/Jni.cpp`, `platform/JniTouchSink.cpp`, `platform/GlOverlay.cpp`, `main.cpp`) against
hand-written stub headers for `jni.h`/`EGL/egl.h`/`GLES3/gl3.h`, because the real NDK is not
available in this sandbox. That check caught one real bug (`ImGuiIO::ConfigWindowsMoveFromTitleBar`
doesn't exist in the bundled ImGui 1.85) and nothing else; it does NOT prove the real NDK/Dobby
build succeeds, does NOT check Android.mk, and does NOT run on a device or in the game.
Two bugs the host tests themselves caught and fixed this session: `GameBridge::Fail()` not
updating status correctly on repeated failures; a typo'd test-click coordinate (not a code bug).

## Not measured / not done
- No ndk-build was run (no NDK here). `Android.mk`/`Application.mk` are written from the old
  project's working flags but never built.
- No game offset is known for the current build. `Offsets.h` documents every key; none are set.
- 8 Ball Pool: not started. Planned as a second, parallel `Offsets.h`/`GameBridge` set reusing
  the same `logic/`, `ui/`, `platform/` code, once Carrom Pool is confirmed working.
- The smali patch in `loader/README.md` is written from reading the reference APK's bytecode,
  not applied or tested against any APK in this session.
- "Auto-resume when daily tokens reset": not something this chat interface can do by itself —
  answered separately in the reply, not coded as a feature.

## Next verifiable steps
1. Build with a real NDK (`ndk-build` from `jni/`) and fix whatever the real toolchain flags
   that the syntax-only check could not catch (header search paths, Dobby's own build quirks).
2. On a rooted/emulated test device: install the mod via the loader patch, open the TESTER tab,
   and start filling `field.*`/`rva.*` keys in `Offsets.h`'s names using it.
3. Once Carrom Pool's `GmRules`/`GmBoard`/`GmStateManager` chain is confirmed live, start on
   8 Ball Pool using the uploaded `AIMX.rar`, `FluxProEngine8BP*.7z`, `Glass-Engine*.7z`,
   `8BPGlass*.rar`, `MARKXIT*.zip` — not opened yet.


## Session 3 additions (dumper + 8 Ball Pool source located)

### New: TESTER tab is now joined by a DUMPER tab (5 tabs total)
`logic/RuntimeDumper.h/.cpp` + `platform/ModuleEnum.h/.cpp`, built from studying the user's two
uploaded dumper APK sources (`dumper_source__.zip`: "Liya Mod Dumper 4.0" and "Universal Dumper
1.0.1"), both IL2CPP dump tools (Universal Dumper bundles a full port of Il2CppDumper's
ElfFile/Il2CppBinary/Metadata/TypeResolver/DumpWriter in smali, saved under
`reference/universal_dumper_il2cpp_smali/` for the next pass).

What's built and tested (41 checks, against this process' REAL /proc/self/maps and real memory,
not mocks):
- `EnumerateModules()` — lists every distinct file-backed library mapped into the process (this
  answers "koi bhi lib folder hook kr sake, sirf fix naam ki nahi"), by parsing /proc/self/maps.
- `FindModulesContaining(name)` — manual search by substring.
- `AutoDetectCandidates()` — auto mode: filters to executable mappings whose name contains a
  known engine pattern (il2cpp, cocos2dcpp, libUE4/unreal, libunity, libmain, libgame, miniclip,
  carrom). This is a name heuristic, not a hook — nothing is hooked automatically.
- `RuntimeDumper::DumpModule()` — dumps a selected module's full mapped range to a file in 4 KB
  chunks via the existing safe memory reader; an unreadable chunk (hole/guard page) is
  zero-filled and counted, never fatal, never crashes.
- `RuntimeDumper::ReadMetadataHeader[FromFile]()` — checks a global-metadata.dat's magic
  (0xFAB11BAF) and reads its version int, the same first step Universal Dumper's
  `MetadataHeader.read()` does (confirmed by reading that method's smali directly).

What's NOT built: the actual IL2CPP metadata table/type/method walk that turns a
global-metadata.dat + game .so into a full `dump.cs` (Universal Dumper's
`Il2CppBinary`/`Metadata`/`TypeResolver`/`DumpWriter`, ~300 KB of smali together, with its own
per-Unity-version table-layout heuristics in `MetadataHeader.candidatesFor/layoutFor`). This is
a large, separate, mechanical port and is the clearly flagged next step — the DUMPER tab already
says "Full class/method dump (dump.cs) is not built yet" in the UI itself so it's never presented
as more than it is.

### 8 Ball Pool: real source located and saved (previously only unopened archives)
`AIMX.rar` and both `8BPGlass*.rar` could NOT be opened this session — no unrar/unar binary is
installable in this sandbox (apt has no `unrar` package here) and `rarfile`/`py7zr` need one.
`FluxProEngine8BP__1_.7z` and `Glass-Engine__1_.7z` DID open (`@FluxEnginePro`, via `py7zr`) and
`MARKXIT__1_.zip`/`Neymar.zip` are plain zips, not yet inspected.

**FluxProEngine8BP** is from the same author/pattern as the old DARK_OWNER Carrom project (same
file names: `game/inc/AutoAim.h`, `GameConstants.h`, `NumberUtils.h`, `Prediction.h`,
`Prediction.fast.h`, `ScreenTable.h`, `mod/kill.h`, `mod/zygisk.hpp`, plus `mod/ButtonClicker.h`,
`mod/PowerSlider.h`, `mod/RangeSelector.h`). Saved under `reference/8bp_flux_jni/`. Read this
session: `AutoAim.h` (ball classification SOLID/STRIPE/EIGHT_BALL, angle-sweep aim search,
reuses `Prediction::determineShotResult`). `game.h` has `//#include "game/inc/AutoQueue.h"` —
commented out, i.e. never built in, same situation as the old Carrom project's stub AutoQueue.
`game/MenuManager.h` has `isInQueue() { return getMenuStateId() == 12; }` — an unconfirmed,
build-specific state id, noted here as information only, NOT written into any Offsets file as a
real value.

**Glass-Engine** is a different, independent 8BP mod (has its own licensing/auth system — `cpr`
+ `curl` + `openssl` bundled under `LOGIN/` — and `Hacks.h`/`ESP.h`/`struct.h`/`class.h` for the
actual hacks). Saved under `reference/8bp_glass_jni/` (just the 4 relevant headers, not the
bundled curl/openssl/cpr). No auto-queue/lobby code found in `Hacks.h`; `struct.h` mentions
"queue" but wasn't read in detail this session.

Porting 8BP's Prediction/AutoAim into `logic/` (mirroring how Carrom's was ported) is the next
concrete step, together with a parallel `Offsets8BP.h` / `GameBridge` for 8 Ball Pool's own
class layout — not started yet.

### Saved to memory (per explicit request)
- `/preferences.md`: always mine newly uploaded files for the project without being asked;
  always resume from this HANDOFF on return, no re-explaining needed.
- `/areas/carrom-mod-menu.md`: updated with the DUMPER tab, 8BP source locations, archive
  passwords, and "next planned" pointing at 8BP porting.


## Session 4: IL2CPP metadata table parser ported for real (dumper-only focus, per user)

User said: work ONLY on the dumper for now; Carrom/8BP autoplay comes after. So this session
stayed on the dumper and did the piece flagged as "not attempted" at the end of session 3:
parsing a global-metadata.dat's full table-of-contents (not just magic+version).

`logic/Il2CppMetadata.h/.cpp` is a faithful line-by-line port of Universal Dumper's
`MetadataHeader.java` (read from its decompiled smali at
`reference/universal_dumper_il2cpp_smali/MetadataHeader.smali`, read in full and carefully —
not grep-sampled — specifically because register reuse across branches in decompiled dx
bytecode is genuinely ambiguous if you only sample it, and a wrong table layout here would
waste real reverse-engineering hours on a device, exactly the risk this user's own ground rules
warn about). It replicates:
- `candidatesFor(rawVersion)`: raw 24 -> try {24.0, 24.1, 24.2}; raw 27 -> {27.0, 27.1, 27.2};
  raw 29 -> {29.0, 29.1}; anything else -> itself only.
- `layoutFor(version)`: the one evolving ordered table list, each table gated by an exact
  version comparison (`rgctxEntries` only if v<=24.1, `metadataUsageLists/Pairs` only if
  v<=24.5, `attributesInfo/attributeTypes` vs `attributeData/attributeDataRange` split at v=29,
  `unresolvedVirtualCallParameter*` only for 19<=v<=24.5, `unresolvedIndirectCallParameter*`
  only for v>=29, `windowsRuntimeTypeNames` at v>=21, `windowsRuntimeStrings` at v>=27,
  `exportedTypeDefinitions` at v>=22) — every threshold cited against its exact smali line number
  in a comment.
- The candidate-selection loop: tries each candidate version's layout, computes
  `8 + tableCount*8`, and accepts the first candidate whose computed size equals the real
  file's `readIntAt(8)` (the first table's own recorded offset) — same as the original, inherited
  ambiguity and all (e.g. 24.0 and 24.1 produce identical layouts and are NOT distinguishable;
  the first match wins, confirmed intentional and tested, not a bug).

Tested with 118 checks: `CandidatesFor`/`LayoutFor` checked against hand-computed expectations
(not just round-tripped against themselves), plus full `ParseMetadataHeader` round-trips on
synthetic buffers (single-candidate version, ambiguous-sub-version disambiguation via a
layout-size difference, bad magic, out-of-range version, unmatched layout, from a real file).

Wired into `RuntimeDumper::ReadMetadataHeaderFromFile` (replacing the old magic-only check) and
into the DUMPER tab's UI, which now lists every table's name/offset/count instead of just
version.

### Still not done (clearly flagged in the DUMPER tab's own text, not just here)
Resolving those table offsets into actual type/method/field names and signatures — Universal
Dumper's `Il2CppBinary` (the game .so side: method pointer table, generic instances),
`TypeResolver` (Il2CppType -> C# type string), and `DumpWriter` (assembling dump.cs) are not
ported. Those need the game .so loaded too (not just global-metadata.dat) and are a much larger
job (the three files together are ~300 KB of smali). Next step when dumper work continues.

### Build/test status
10 host suites now (`test_il2cpp_metadata` added), 459 checks total, all passing via
`tests/run_tests.sh`. `Android.mk` updated with the new source file. Still no real NDK build.


## Session 5: signature/constant scanner for NON-IL2CPP protected games (Carrom Pool's own kind)

Correction carried over from session 2, restated because it matters for this session's work:
Carrom Pool is NOT IL2CPP (plain C++/Obj-C-style runtime, `libgame-CARROM.so`, no
global-metadata.dat). So session 4's IL2CPP metadata parser does not apply to Carrom Pool
itself — it is for OTHER, Unity-based games someone might point this dumper at. For a game
like Carrom Pool, the standard way to re-find an offset after an update with no symbols is
signature (AOB) scanning and known-constant scanning, so that's what this session added.

`logic/PatternScanner.h/.cpp` (new):
- `ParsePattern("DE AD ?? 22")` — IDA/Cheat-Engine style hex+wildcard pattern parser.
- `ScanModule` / `ScanBuffer` — AOB scan over a live module (reads the whole thing through the
  existing safe-memory-read path, 4 KB at a time, zero-filling unreadable holes, same approach
  `RuntimeDumper::DumpModule` already used) or over any in-memory buffer.
- `FindFloat` / `FindDouble` (+ buffer versions) — scans every naturally-aligned slot for a
  known literal value within a tolerance. Meant for exactly the case this session was asked
  about: re-locating Carrom Pool's own physics constants (e.g. `STRIKER_RADIUS = 2.10`,
  `TIME_PER_TICK = 0.002`, from the old DARK_OWNER source's `GameConstants.h`) inside a current
  build, as a way to anchor further reverse engineering even with no symbols.

Important, user-facing caveat already in both the header comment and the DUMPER tab's own UI
text: a generic constant can coincidentally match elsewhere in a large real binary purely by
chance (confirmed empirically this session — scanning this whole ~tens-of-MB test binary for an
arbitrary made-up float occasionally found one unrelated coincidental hit). The UI tells the
user to treat a single hit as a lead to confirm (cross-reference with a byte pattern around it,
or check more than one known constant), not as a settled offset.

Tested with 30 checks, all against this process' REAL memory (a module found via
`EnumerateModules`, real canary float/double values and a real byte marker placed in it,
including a deliberately misaligned-occurrence check to prove alignment filtering works, and a
narrow custom address range used for the "value not present" checks specifically so a
coincidental hit in unrelated linked-in code can't make that assertion flaky).

Wired into the DUMPER tab: a 3-way toggle (AOB PATTERN / FLOAT / DOUBLE) under the module
scan/select UI, searching whichever library is currently selected, listing hits as
offset-from-base (ready to paste into the TESTER tab's chain field) and absolute address.

### Build/test status
11 host suites now (`test_pattern_scanner` added), 489 checks total, all passing via
`tests/run_tests.sh`. `Android.mk` and the loader are otherwise unchanged. Still no real NDK
build (same limitation as every prior session: no NDK available in this sandbox).

### Next steps for the dumper, in rough priority order
1. A basic xref finder for ARM64 (find `adrp`+`add`/`ldr` instruction pairs that reference a
   given address) would make the constant scanner far more useful — right now it finds the
   constant's address in `.rodata`, not the function that reads it. Needs a disassembler;
   nothing in this project links one yet (this session's analysis scripts used Python's
   `capstone`, which is not usable inside the Android native library).
2. String scanning (find ASCII/UTF-8 strings in a module) is a natural companion to the AOB
   scanner and not yet built.
3. The IL2CPP `Il2CppBinary`/`TypeResolver`/`DumpWriter` port (for pointing this dumper at a
   Unity/IL2CPP game, not Carrom Pool) is still not started; `Il2CppBinary.smali` alone is
   ~5300 lines and does heuristic struct-finding (`findMetadataRegistration`,
   `findCodeGenModules`) that needs the same careful full-read treatment session 4 used for
   `MetadataHeader.smali`, not a quick port.


## Session 6: Android Studio project + protected-metadata runtime dumping

### Project is now a real Android Studio / Gradle project
Open the `CarromMod/` folder in Android Studio. `settings.gradle`, `build.gradle`,
`gradle.properties`, `app/build.gradle` (module `app`, `externalNativeBuild.ndkBuild` ->
`app/src/main/jni/Android.mk`, arm64-v8a only), a minimal `AndroidManifest.xml` (no launcher
activity: this module is a build vehicle, not an app to run) and the loader at
`app/src/main/java/com/carrommod/loader/MainActivity.java`. The old top-level `jni/` and
`loader/java/` were removed; everything native is under `app/src/main/jni/`. `tests/run_tests.sh`
was updated to the new paths. What to take from the build output (the APK): `lib/arm64-v8a/
libCarromMod.so` and the loader class in `classes.dex`, then follow `loader/README.md`.
NOT verified: the Gradle/NDK build itself (no SDK/NDK here; `app/build.gradle` is hand-written
standard `externalNativeBuild.ndkBuild` config).

### New: runtime dumping that works when the metadata is encrypted/protected
- `platform/MemoryRegions` : every mapping incl. anonymous (heap, decrypted blobs).
- `logic/MetadataFinder` : scans readable memory for the metadata magic (0xFAB11BAF), validates
  each candidate with the ported header parser (version + layout size check), computes the total
  size (max table offset+size), and dumps the decrypted copy to a file. Runs on a background
  thread with progress + cancel so the game's render thread is not blocked. Skips device
  mappings and regions > 1 GiB. Stated assumption: the decrypted metadata is one contiguous,
  4-byte-aligned block with an intact header; a game that splits or scrambles it even in RAM is
  NOT handled and needs manual analysis (use LIBS > raw range dump + the TESTER tab).
- `logic/StringScanner` : printable-string search in a module (case-insensitive filter).
- `RuntimeDumper::DumpRange` : dump any typed-in address range (heap/anonymous memory).
- `mem::ReadRange` : chunked safe read used by the above.
- Module dumps are flat virtual-memory images (file offset == RVA). Whether a given offline tool
  accepts such an image as-is was NOT tested here.

DUMPER tab is now 3 pages so nothing overflows the menu: LIBS (list/auto-detect, dump a library,
dump a raw range), METADATA (check a file; FIND METADATA IN MEMORY; save the found copy), SCAN
(AOB / FLOAT / DOUBLE / STRING in the selected library). All state moved from function-local
statics to members. New test checks that every tab/page's content bottom stays above the footer.

### Tests
12 host suites, all passing: `test_metadata_finder` (85 checks: finds a synthetic decrypted
metadata block on this process' heap among decoys, byte-exact dump, async + cancel, strings,
range dump) and `test_ui` grew to 40 (footer-overflow check across 7 tab/pages). Real-device
behaviour of the finder (speed on a multi-GB heap, a real protected game) is unmeasured.

### Still open on the dumper
1. IL2CPP `dump.cs` generation (Il2CppBinary / TypeResolver / DumpWriter port). Not started;
   the metadata copy this session finds can be fed to an offline tool meanwhile.
2. ARM64 xref finder (needs a disassembler linked into the native lib).
3. Carrom Pool itself is not IL2CPP: for it use SCAN (constants/strings/AOB) + TESTER.


## Session 7: one-zip delivery, hook.txt, loader touch forwarding

- `hook.txt` (project root): every hook, exact placement, what offsets each needs, log lines to
  verify, device file locations; every claim is tagged MEASURED / UNVERIFIED / YOU.
- Verified on the REAL Easy Victory `classes8.dex`: `CarromActivity` extends
  `com.miniclip.nucleus.NucleusActivity`; `onCreate` = setNativeLibraryName(...Module-1492),
  invoke-super {p0,p1}, EV's `Start` line, ...; replacing that one line with
  `invoke-static {p0}, Lcom/carrommod/loader/MainActivity;->Start(Landroid/content/Context;)V`,
  reassembling the whole dex (smali 3.0.9) and disassembling again changes exactly that line.
  `CarromActivity` has NO dispatchTouchEvent.
- Gap fixed: the loader did not forward touches before. `MainActivity.Start()` now wraps
  `Window.Callback` with a `Proxy` and calls new native `Java_com_carrommod_loader_MainActivity_nativeTouch`
  (main.cpp); the game needs only the single smali line. Java was syntax-parsed (javalang) but NOT
  compiled or run (no javac/Android SDK here); the Proxy approach is untested on a device.
- Dumps now go to `<filesDir>/dumps` (created at startup); /sdcard is not writable for a game process.
- Gradle: wrapper for Gradle 8.7 added (downloaded from the gradle repo), NDK no longer pinned,
  flags passed via `cppFlags`/`arguments` instead of relying on Application.mk discovery.
  STILL never run (no Android SDK/NDK in the sandbox).
- Tests: 11 host suites, all pass (test_app 26, test_ui 40 ...).
- Deliverable: /mnt/user-data/outputs/CarromMod.zip (whole project incl. reference/).

### Next
1. Build in Android Studio, fix whatever the real toolchain reports.
2. Patch a test APK per hook.txt and read logcat with the checklist in section G.
3. Dumper: IL2CPP dump.cs port, ARM64 xref finder. Then Carrom/8BP autoplay work (user's order).
