// User-facing settings (what the menu edits). Persisted as simple key=value text.
#pragma once
#include <string>

namespace carrom {

struct Settings {
    // FUNCTIONS tab
    bool predictionLine = true;       // "Enable Prediction"
    bool strikerPath = true;          // "Show Striker Path"
    bool puckPaths = true;            // "Show Puck Paths"
    bool predictionAfterShot = true;  // stored only: no behaviour is wired to it yet
    bool autoPlay = false;            // never restored as true: autoplay always starts off
    int autoPlayMode = 0;             // 0 = FAST, 1 = HUMAN (slow scan)
    bool cleanTable = false;          // stored only: no behaviour is wired to it yet

    // AUTO MATCH tab (stored only: needs lobby hooks that are not part of this project)
    bool autoQueue = false;
    int queueMode = 0;                // 0 Carrom, 1 Disc Pool, 2 Freestyle
    int coinIndex = 0;

    // ESP LINE tab
    int lineStyle = 0;                // 0 classic gold/cyan, 1 sea blue glow
    float lineThickness = 6.9f;       // 1..10
    float lineOpacity = 0.9f;         // 0.1..1

    // UI geometry, in design units (see ui/Layout)
    float menuX = 108.f, menuY = 435.f, menuW = 540.f, menuH = 560.f;
    float playBtnX = 54.f, playBtnY = 252.f, playBtnSize = 90.f;
    float logoBtnX = 48.f, logoBtnY = 128.f, logoBtnSize = 100.f;
    float fontPixels = 40.f;

    // Touch: report touches that land on the menu as consumed to the Java side.
    bool consumeTouchOverUi = true;

    void Clamp();
    std::string Serialize() const;
    void Deserialize(const std::string& text);
    bool Load(const std::string& path);
    bool Save(const std::string& path) const;
};

} // namespace carrom
