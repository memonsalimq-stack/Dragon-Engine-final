// Every build-dependent game value lives here and nowhere else.
//
// NOTHING IS FILLED IN. All entries start "unset". Values are loaded at runtime from
//   <app files dir>/carrom_offsets.cfg      (one "key=value" per line, '#' comments)
// so the library never needs a rebuild when the game updates. A template with every
// key is produced by Offsets::TemplateText() and shipped as offsets.cfg.template.
//
// Kinds
//   rva    : offset from the base of the game module (libgame-CARROM*.so), hex or decimal
//   field  : byte offset of a member inside a game object, hex or decimal
//   symbol : exported symbol name inside the game module (text)
//
// "unset" is distinct from a real 0. Code must check `.set` before using `.value`.
#pragma once
#include <cstdint>
#include <string>
#include <vector>

namespace carrom {

struct OffsetValue {
    uintptr_t value = 0;
    bool set = false;
};

struct SymbolValue {
    std::string name;
    bool set = false;
};

// X(member, "config.key", kind, "what it is / where the old project had it")
#define CARROM_NUMERIC_OFFSETS(X)                                                                   \
    X(HookGameUpdate, "rva.hook_game_update", rva,                                                  \
      "void f(self, arg1, double dt): called every frame with self = CarromGameManager (old kill.h)") \
    X(StrikerProps, "rva.striker_properties_ptr", rva,                                              \
      "global pointer to striker properties; optional (old Types.h STRIKER_PROPERTIES_PTR)")        \
    X(TransformFn, "rva.world_transform_fn", rva,                                                    \
      "Vec2d f(gameManager, double x, double y): world->screen sample; optional (old 0x1A991A8 role)") \
    X(TransformScale, "rva.world_transform_scale_float", rva,                                       \
      "global float multiplied onto the sampled transform; optional (old 0x2C3C108 role)")           \
    X(GmRules, "field.gm.rules", field, "CarromGameManager -> rules object ptr (old GameManager.h)") \
    X(GmBoard, "field.gm.board", field, "CarromGameManager -> Board ptr")                           \
    X(GmVisualStriker, "field.gm.visual_striker", field, "CarromGameManager -> VisualStriker ptr")  \
    X(GmVisualEnglish, "field.gm.visual_english", field,                                            \
      "CarromGameManager -> VisualEnglishControl ptr; optional (spin)")                             \
    X(GmStateManager, "field.gm.state_manager", field, "CarromGameManager -> GameStateManager ptr") \
    X(SmStack, "field.sm.stack", field, "StateManager -> state stack array ptr")                    \
    X(ArrCount, "field.array.count", field, "runtime array object: element count (uintptr)")        \
    X(ArrData, "field.array.data", field, "runtime array object: pointer to element storage")       \
    X(StateId, "field.state.id", field, "State -> int32 state id (player turn == 4 in old source)") \
    X(BoardPieces, "field.board.pieces", field, "Board -> pointer to array object of piece ptrs")   \
    X(BoardProps, "field.board.properties", field, "Board -> BoardProperties ptr; optional (pockets)") \
    X(PropsPockets, "field.props.pockets", field,                                                   \
      "BoardProperties -> pointer to 4 x Vec2d pocket centres; optional")                           \
    X(PiecePos, "field.piece.position", field, "CarromPiece -> Vec2d (2 doubles) position")         \
    X(PieceRadius, "field.piece.radius", field, "CarromPiece -> double radius; optional")           \
    X(PieceType, "field.piece.type", field, "CarromPiece -> int32 type (0 white,1 black,2 queen,3 striker)") \
    X(PieceState, "field.piece.state", field, "CarromPiece -> int32 state (1 default,2 in pocket,..)") \
    X(StrikerGuide, "field.striker.guide", field, "VisualStriker -> VisualGuide ptr")               \
    X(StrikerPower, "field.striker.power", field, "VisualStriker -> double power 0..1")             \
    X(GuideAimAngle, "field.guide.aim_angle", field, "VisualGuide -> double aim angle (radians)")   \
    X(EnglishValue, "field.english.value", field, "VisualEnglishControl -> Vec2d english; optional") \
    X(RulesClassifications, "field.rules.classifications", field,                                   \
      "rules -> begin pointer of int32 classification vector ([0]=me,[1]=opponent)")                \
    X(RulesQueenCover, "field.rules.queen_cover_required", field, "rules -> bool")                  \
    X(RulesPottedPocket, "field.rules.potted_pocket_id", field, "rules -> uint32 pocket id (>=4 none)") \
    X(PropsEnglishMul, "field.striker_props.english_multiplier", field,                             \
      "striker properties -> double english multiplier; optional")                                  \
    X(PropsMaxPower, "field.striker_props.max_power", field,                                        \
      "striker properties -> double max power; optional (default 120)")

#define CARROM_SYMBOL_OFFSETS(X)                                                                     \
    X(SymTouchBegin, "sym.touches_begin", "JNI export: void(JNIEnv*,jobject,jint,float,float,jboolean,jboolean); optional") \
    X(SymTouchMove, "sym.touches_move", "JNI export: void(JNIEnv*,jobject,jintArray,jfloatArray,jfloatArray,jboolean,jboolean); optional") \
    X(SymTouchEnd, "sym.touches_end", "JNI export: void(JNIEnv*,jobject,jint,float,float,jboolean,jboolean); optional")

class Offsets {
public:
#define X(member, key, kind, doc) OffsetValue member;
    CARROM_NUMERIC_OFFSETS(X)
#undef X
#define X(member, key, doc) SymbolValue member;
    CARROM_SYMBOL_OFFSETS(X)
#undef X

    // Applies "key=value" lines. Unknown keys and malformed values are appended to `errors`.
    // Returns the number of entries applied.
    int LoadFromText(const std::string& text, std::vector<std::string>* errors = nullptr);
    bool LoadFromFile(const std::string& path, std::vector<std::string>* errors = nullptr);

    // Text with every key, empty values, and the doc string as a comment.
    static std::string TemplateText();

    static int TotalCount();
    int SetCount() const;

    // Keys the GameBridge cannot run without but that are still unset.
    std::vector<std::string> MissingRequired() const;
    // Keys that improve accuracy but may stay unset.
    std::vector<std::string> MissingOptional() const;
};

} // namespace carrom
