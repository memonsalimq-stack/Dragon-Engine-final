#include "platform/Hooks.h"

#include "platform/Log.h"

#if __has_include(<dobby.h>)
#include <dobby.h>
#define CARROM_HAVE_DOBBY 1
#endif

namespace carrom {

bool HookManager::Finish(Record rec, int rc) {
    rec.installed = rc == 0;
    if (!rec.installed) rec.error = "DobbyHook returned " + std::to_string(rc);
    Logf("hook %s @%#lx: %s", rec.name.c_str(), (unsigned long)rec.target,
         rec.installed ? "installed" : rec.error.c_str());
    const bool ok = rec.installed;
    m_records.push_back(std::move(rec));
    return ok;
}

bool HookManager::InstallRva(const std::string& name, uintptr_t rva, void* replacement, void** original) {
    Record rec;
    rec.name = name;
    if (!m_module.found || m_module.size == 0) {
        rec.error = "game module not found";
    } else if (rva == 0 || (rva & 3u) != 0) {
        rec.error = "rva is zero or not 4-byte aligned";
    } else if (rva >= m_module.size) {
        rec.error = "rva is outside the module";
    } else {
        rec.target = m_module.base + rva;
    }
    if (!rec.error.empty()) {
        Logf("hook %s refused: %s", name.c_str(), rec.error.c_str());
        m_records.push_back(std::move(rec));
        return false;
    }
#ifdef CARROM_HAVE_DOBBY
    {
        void* const target = (void*)rec.target;
        const int rc = DobbyHook(target, replacement, original);
        return Finish(std::move(rec), rc);
    }
#else
    (void)replacement; (void)original;
    rec.error = "built without Dobby";
    m_records.push_back(std::move(rec));
    return false;
#endif
}

bool HookManager::InstallAbsolute(const std::string& name, void* target, void* replacement, void** original) {
    Record rec;
    rec.name = name;
    rec.target = (uintptr_t)target;
    if (!target) {
        rec.error = "target is null";
        m_records.push_back(std::move(rec));
        return false;
    }
#ifdef CARROM_HAVE_DOBBY
    {
        const int rc = DobbyHook(target, replacement, original);
        return Finish(std::move(rec), rc);
    }
#else
    (void)replacement; (void)original;
    rec.error = "built without Dobby";
    m_records.push_back(std::move(rec));
    return false;
#endif
}

int HookManager::InstalledCount() const {
    int n = 0;
    for (const auto& r : m_records) n += r.installed ? 1 : 0;
    return n;
}

} // namespace carrom
