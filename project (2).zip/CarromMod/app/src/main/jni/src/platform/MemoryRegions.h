// Every mapping of this process, including anonymous ones (heap, JIT, decrypted blobs). Unlike
// ModuleEnum (file-backed libraries only), this is what you need to find data that never had a
// file name: e.g. a global-metadata.dat the game decrypted into heap memory at startup.
#pragma once
#include <cstdint>
#include <string>
#include <vector>

namespace carrom {

struct MemRegion {
    uintptr_t start = 0;
    uintptr_t end = 0;
    bool r = false, w = false, x = false;
    std::string path; // empty for anonymous mappings
    size_t size() const { return (size_t)(end - start); }
};

// Parses /proc/self/maps. Empty vector if unreadable (never throws).
std::vector<MemRegion> EnumerateRegions();

} // namespace carrom
