#include "platform/GlOverlay.h"

#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <dlfcn.h>

#include <chrono>
#include <deque>

#define STB_IMAGE_IMPLEMENTATION
#define STBI_ONLY_PNG
#include "stb_image.h"

#include "app/App.h"
#include "assets/black_logo.h"
#include "assets/play_off.h"
#include "assets/play_on.h"
#include "backends/imgui_impl_opengl3.h"
#include "imgui.h"
#include "platform/Log.h"
#include "platform/TouchQueue.h"

namespace carrom::gl {

namespace {

using SwapFn = EGLBoolean (*)(EGLDisplay, EGLSurface);
SwapFn g_origSwap = nullptr;

bool g_imguiReady = false;
EGLContext g_ctx = EGL_NO_CONTEXT;
double g_lastFrameTime = 0.0;
bool g_inFrame = false;
GLuint g_texPlayOn = 0, g_texPlayOff = 0, g_texLogo = 0;
std::deque<TouchEvent> g_pending;
bool g_mouseDown = false;
ImVec2 g_mousePos(-1.f, -1.f);

double NowSeconds() {
    using namespace std::chrono;
    return duration_cast<duration<double>>(steady_clock::now().time_since_epoch()).count();
}

GLuint LoadTexture(const unsigned char* png, size_t len) {
    int w = 0, h = 0, n = 0;
    unsigned char* px = stbi_load_from_memory(png, (int)len, &w, &h, &n, 4);
    if (!px) return 0;
    GLuint tex = 0;
    glGenTextures(1, &tex);
    glBindTexture(GL_TEXTURE_2D, tex);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, px);
    stbi_image_free(px);
    return tex;
}

void LoadTextures() {
    g_texPlayOn = LoadTexture(play_on_png, play_on_png_len);
    g_texPlayOff = LoadTexture(play_off_png, play_off_png_len);
    g_texLogo = LoadTexture(black_logo_png, black_logo_png_len);
    ui::Textures t;
    t.playOn = (ImTextureID)(intptr_t)g_texPlayOn;
    t.playOff = (ImTextureID)(intptr_t)g_texPlayOff;
    t.logo = (ImTextureID)(intptr_t)g_texLogo;
    App::Get().SetTextures(t);
}

void InitImGui() {
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;
    ImFontConfig cfg;
    cfg.SizePixels = App::Get().settings.fontPixels;
    io.Fonts->AddFontDefault(&cfg);
    ImGui::StyleColorsDark();
    ImGui_ImplOpenGL3_Init("#version 300 es");
    LoadTextures();
    g_imguiReady = true;
    TouchQueue::Get().overlayReady = true;
    Logf("overlay ready");
}

// The game's EGL context was replaced (surface recreated after the app was backgrounded).
void RebindContext() {
    if (g_imguiReady) {
        ImGui_ImplOpenGL3_Shutdown();
        ImGui_ImplOpenGL3_Init("#version 300 es");
        LoadTextures();
    }
}

// ImGui 1.85 has no input queue: a quick down+up inside one frame would be lost. Feed one
// event per frame, merge consecutive moves.
void ApplyTouches(ImGuiIO& io) {
    for (const TouchEvent& e : TouchQueue::Get().Drain()) {
        if (e.action == 2 && !g_pending.empty() && g_pending.back().action == 2) g_pending.back() = e;
        else g_pending.push_back(e);
    }
    while (g_pending.size() > 12) g_pending.pop_front();   // never fall far behind
    if (!g_pending.empty()) {
        const TouchEvent e = g_pending.front();
        g_pending.pop_front();
        g_mousePos = ImVec2(e.x, e.y);
        g_mouseDown = (e.action == 0 || e.action == 2);
    }
    io.MousePos = g_mousePos;
    io.MouseDown[0] = g_mouseDown;
}

void RenderOverlay(EGLDisplay dpy, EGLSurface surf) {
    const EGLContext ctx = eglGetCurrentContext();
    if (ctx == EGL_NO_CONTEXT) return;
    EGLint w = 0, h = 0;
    eglQuerySurface(dpy, surf, EGL_WIDTH, &w);
    eglQuerySurface(dpy, surf, EGL_HEIGHT, &h);
    if (w < 200 || h < 200) return;   // not the game surface

    const double now = NowSeconds();
    if (ctx != g_ctx) {
        // Follow the first context we see. Other contexts (ads, webviews) are ignored unless the
        // followed one has been silent for 3 s, which means it was destroyed.
        if (g_ctx != EGL_NO_CONTEXT && now - g_lastFrameTime < 3.0) return;
        g_ctx = ctx;
        if (g_imguiReady) RebindContext();
    }
    if (!g_imguiReady) InitImGui();

    float dt = (float)(now - g_lastFrameTime);
    if (g_lastFrameTime == 0.0 || dt <= 0.f || dt > 0.25f) dt = 1.f / 60.f;
    g_lastFrameTime = now;

    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize = ImVec2((float)w, (float)h);
    io.DeltaTime = dt;
    ApplyTouches(io);

    ImGui_ImplOpenGL3_NewFrame();
    ImGui::NewFrame();
    const ui::UiOutput out = App::Get().Frame((float)w, (float)h, dt, now);
    std::vector<TouchRect> rects;
    rects.reserve(out.hitRects.size());
    for (const auto& r : out.hitRects) rects.push_back({r.x0, r.y0, r.x1, r.y1});
    TouchQueue::Get().SetHitRects(std::move(rects));
    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
}

EGLBoolean HookedSwap(EGLDisplay dpy, EGLSurface surf) {
    if (!g_inFrame) {
        g_inFrame = true;
        RenderOverlay(dpy, surf);
        g_inFrame = false;
    }
    return g_origSwap ? g_origSwap(dpy, surf) : EGL_FALSE;
}

} // namespace

bool InstallEglHook(HookManager& hooks) {
    void* egl = dlopen("libEGL.so", RTLD_NOW);
    void* fn = egl ? dlsym(egl, "eglSwapBuffers") : nullptr;
    if (!fn) {
        Logf("eglSwapBuffers not found");
        return false;
    }
    return hooks.InstallAbsolute("eglSwapBuffers", fn, (void*)&HookedSwap, (void**)&g_origSwap);
}

} // namespace carrom::gl
