// Lists every shared library currently mapped into this process (self) by parsing
// /proc/self/maps — the "auto-detect any lib, not just one fixed name" the user asked for.
// Works for any process whose address space we are running inside (the injected mod's own
// process = the game's process), which is exactly the self-dump use case.
#pragma once
#include <cstdint>
#include <string>
#include <vector>

namespace carrom {

struct MappedModule {
    std::string path;         // full path from /proc/self/maps, e.g. /data/app/.../lib/arm64/libil2cpp.so
    std::string name;         // basename only, e.g. "libil2cpp.so"
    uintptr_t base = 0;       // lowest mapped address for this path
    uintptr_t end = 0;        // highest mapped address (exclusive) for this path
    bool everExecutable = false; // any segment had the 'x' permission (i.e. actual code, not just a data map)
};

// Parses /proc/self/maps once and returns one entry per distinct file-backed path, merging
// that path's separate r/w/x/shared segments into a single [base, end) span. Anonymous
// mappings (no path) are skipped. Never throws; returns an empty vector if /proc is
// unreadable (sandboxed environments, SELinux, etc.) instead of crashing.
std::vector<MappedModule> EnumerateModules();

// Convenience filters over EnumerateModules():
std::vector<MappedModule> FindModulesContaining(const std::string& substring);
// Common engine/runtime libraries worth offering as "auto-detected candidates": libil2cpp,
// libcocos2dcpp, libUE4/libUnreal, libmain, libgame*, libunity.
std::vector<MappedModule> AutoDetectCandidates();

} // namespace carrom
