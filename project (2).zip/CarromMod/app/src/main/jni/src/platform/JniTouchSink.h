// Injects touches by calling the game's own JNI touch entry points (Cocos2d-x style
// nativeTouchesBegin/Move/End). The export names come from offsets (sym.touches_*): nothing is
// assumed. Signatures are the ones declared in the old project's input.h. Android only.
#pragma once
#include <jni.h>

#include "config/Offsets.h"
#include "game/TouchSink.h"
#include "platform/Module.h"

namespace carrom {

class JniTouchSink : public TouchSink {
public:
    // True only if all three symbols were found inside the game module.
    bool Resolve(const ModuleInfo& module, const Offsets& offsets);

    bool Available() const override { return m_begin && m_move && m_end; }
    void Begin(int id, float x, float y) override;
    void Move(int id, float x, float y) override;
    void End(int id, float x, float y) override;

private:
    using BeginEndFn = void (*)(JNIEnv*, jobject, jint, float, float, jboolean, jboolean);
    using MoveFn = void (*)(JNIEnv*, jobject, jintArray, jfloatArray, jfloatArray, jboolean, jboolean);
    BeginEndFn m_begin = nullptr;
    BeginEndFn m_end = nullptr;
    MoveFn m_move = nullptr;
};

} // namespace carrom
