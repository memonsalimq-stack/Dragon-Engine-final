#include "platform/ModuleEnum.h"

#include <algorithm>
#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <map>

namespace carrom {

namespace {
std::string ToLower(std::string s) {
    for (char& c : s) c = (char)std::tolower((unsigned char)c);
    return s;
}
std::string Basename(const std::string& path) {
    const size_t slash = path.find_last_of('/');
    return slash == std::string::npos ? path : path.substr(slash + 1);
}
} // namespace

std::vector<MappedModule> EnumerateModules() {
    std::vector<MappedModule> out;
    std::FILE* f = std::fopen("/proc/self/maps", "r");
    if (!f) return out; // unreadable: caller sees an empty list, never a crash

    std::map<std::string, size_t> indexOf; // path -> index in `out`
    char line[1024];
    while (std::fgets(line, sizeof(line), f)) {
        unsigned long long lo = 0, hi = 0;
        char perms[8] = {0};
        char path[768] = {0};
        // "lo-hi perms offset dev inode path" — path may be absent (anonymous mapping)
        const int n = std::sscanf(line, "%llx-%llx %7s %*x %*x:%*x %*u %767[^\n]", &lo, &hi, perms, path);
        if (n < 3) continue;
        std::string p = path;
        // trim leading spaces sscanf's %s already stopped at, and skip pseudo-paths
        while (!p.empty() && p.front() == ' ') p.erase(p.begin());
        if (p.empty() || p[0] == '[' || p == "/dev/zero" || p == "/memfd:jit-cache") continue;

        const bool exec = perms[2] == 'x';
        auto it = indexOf.find(p);
        if (it == indexOf.end()) {
            MappedModule m;
            m.path = p;
            m.name = Basename(p);
            m.base = (uintptr_t)lo;
            m.end = (uintptr_t)hi;
            m.everExecutable = exec;
            indexOf[p] = out.size();
            out.push_back(m);
        } else {
            MappedModule& m = out[it->second];
            m.base = std::min(m.base, (uintptr_t)lo);
            m.end = std::max(m.end, (uintptr_t)hi);
            m.everExecutable = m.everExecutable || exec;
        }
    }
    std::fclose(f);
    return out;
}

std::vector<MappedModule> FindModulesContaining(const std::string& substring) {
    std::vector<MappedModule> out;
    if (substring.empty()) return out;
    const std::string needle = ToLower(substring);
    for (auto& m : EnumerateModules())
        if (ToLower(m.name).find(needle) != std::string::npos) out.push_back(m);
    return out;
}

std::vector<MappedModule> AutoDetectCandidates() {
    static const char* kPatterns[] = {"il2cpp", "cocos2dcpp", "libue4", "libunreal", "libunity",
                                      "libmain", "libgame", "libminiclip", "libcarrom"};
    std::vector<MappedModule> out;
    const auto all = EnumerateModules();
    for (const auto& m : all) {
        if (!m.everExecutable) continue; // a candidate engine library is always code, not a pure data map
        const std::string n = ToLower(m.name);
        for (const char* pat : kPatterns)
            if (n.find(pat) != std::string::npos) { out.push_back(m); break; }
    }
    return out;
}

} // namespace carrom
