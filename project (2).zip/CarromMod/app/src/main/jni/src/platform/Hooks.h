// Inline hook installation with validation and a record of what happened.
// Hooks are never removed while the game runs: the library stays loaded.
#pragma once
#include <cstdint>
#include <string>
#include <vector>

#include "platform/Module.h"

namespace carrom {

class HookManager {
public:
    struct Record {
        std::string name;
        uintptr_t target = 0;
        bool installed = false;
        std::string error;
    };

    void SetModule(const ModuleInfo& m) { m_module = m; }

    // Hooks module.base + rva. Refuses unaligned or out-of-module targets.
    bool InstallRva(const std::string& name, uintptr_t rva, void* replacement, void** original);
    // Hooks an absolute address (used for EGL, whose module is not the game module).
    bool InstallAbsolute(const std::string& name, void* target, void* replacement, void** original);

    const std::vector<Record>& records() const { return m_records; }
    int InstalledCount() const;

private:
    bool Finish(Record rec, int rc);
    ModuleInfo m_module;
    std::vector<Record> m_records;
};

} // namespace carrom
