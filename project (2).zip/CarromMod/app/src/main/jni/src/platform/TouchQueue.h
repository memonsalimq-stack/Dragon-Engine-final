// Hand-off of touch events from the Java/UI thread to the render thread, plus the hit-test that
// decides whether a touch belongs to the menu (and should not reach the game).
#pragma once
#include <atomic>
#include <mutex>
#include <vector>

namespace carrom {

struct TouchEvent {
    int action = 0; // android.view.MotionEvent: 0 down, 1 up, 2 move, 3 cancel
    float x = 0.f, y = 0.f;
};

struct TouchRect { float x0, y0, x1, y1; };

class TouchQueue {
public:
    static TouchQueue& Get() { static TouchQueue q; return q; }

    void Push(int action, float x, float y) {
        std::lock_guard<std::mutex> lk(m_mutex);
        if (m_events.size() < 256) m_events.push_back({action, x, y});
    }
    std::vector<TouchEvent> Drain() {
        std::lock_guard<std::mutex> lk(m_mutex);
        std::vector<TouchEvent> out;
        out.swap(m_events);
        return out;
    }

    // Render thread, every frame: the screen rects the menu currently occupies.
    void SetHitRects(std::vector<TouchRect> rects) {
        std::lock_guard<std::mutex> lk(m_mutex);
        m_rects = std::move(rects);
    }

    // Java thread: true if this touch belongs to the menu. A gesture that starts on the menu stays
    // owned by it until the finger lifts; a gesture that starts elsewhere is never claimed.
    bool ShouldConsume(int action, float x, float y) {
        if (!overlayReady.load()) return false;
        std::lock_guard<std::mutex> lk(m_mutex);
        if (action == 0) {
            m_owned = false;
            for (const auto& r : m_rects)
                if (x >= r.x0 && x <= r.x1 && y >= r.y0 && y <= r.y1) { m_owned = true; break; }
            return m_owned;
        }
        const bool owned = m_owned;
        if (action == 1 || action == 3) m_owned = false;
        return owned;
    }

    std::atomic<bool> overlayReady{false};

private:
    std::mutex m_mutex;
    std::vector<TouchEvent> m_events;
    std::vector<TouchRect> m_rects;
    bool m_owned = false;
};

} // namespace carrom
