#include "platform/Jni.h"

namespace carrom {

static JavaVM* g_vm = nullptr;

void SetJavaVM(JavaVM* vm) { g_vm = vm; }
JavaVM* GetJavaVM() { return g_vm; }

JniThreadScope::JniThreadScope() {
    if (!g_vm) return;
    if (g_vm->GetEnv(reinterpret_cast<void**>(&m_env), JNI_VERSION_1_6) == JNI_OK) return;
    if (g_vm->AttachCurrentThread(&m_env, nullptr) == JNI_OK) m_attached = true;
    else m_env = nullptr;
}

JniThreadScope::~JniThreadScope() {
    if (m_attached && g_vm) g_vm->DetachCurrentThread();
}

} // namespace carrom
