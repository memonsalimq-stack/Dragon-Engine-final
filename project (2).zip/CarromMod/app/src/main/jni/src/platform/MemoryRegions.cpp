#include "platform/MemoryRegions.h"

#include <cstdio>

namespace carrom {

std::vector<MemRegion> EnumerateRegions() {
    std::vector<MemRegion> out;
    std::FILE* f = std::fopen("/proc/self/maps", "r");
    if (!f) return out;
    char line[1024];
    while (std::fgets(line, sizeof(line), f)) {
        unsigned long long lo = 0, hi = 0;
        char perms[8] = {0};
        char path[768] = {0};
        const int n = std::sscanf(line, "%llx-%llx %7s %*x %*x:%*x %*u %767[^\n]", &lo, &hi, perms, path);
        if (n < 3 || hi <= lo) continue;
        MemRegion r;
        r.start = (uintptr_t)lo;
        r.end = (uintptr_t)hi;
        r.r = perms[0] == 'r';
        r.w = perms[1] == 'w';
        r.x = perms[2] == 'x';
        if (n >= 4) {
            std::string p = path;
            while (!p.empty() && p.front() == ' ') p.erase(p.begin());
            r.path = p;
        }
        out.push_back(std::move(r));
    }
    std::fclose(f);
    return out;
}

} // namespace carrom
