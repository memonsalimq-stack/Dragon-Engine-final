// Entry point. The library is loaded by the game process (System.loadLibrary from a patched
// CarromActivity, see loader/README.md). JNI_OnLoad only starts a thread: the loader lock is
// held while it runs, so nothing heavy may happen here.
#include <jni.h>
#include <pthread.h>
#include <sys/stat.h>
#include <unistd.h>

#include <cstdio>
#include <string>

#include "app/App.h"
#include "platform/GlOverlay.h"
#include "platform/Jni.h"
#include "platform/JniTouchSink.h"
#include "platform/Log.h"
#include "platform/TouchQueue.h"

using namespace carrom;

namespace {

JniTouchSink g_touchSink;

std::string PackageName() {
    char buf[256] = {0};
    FILE* f = std::fopen("/proc/self/cmdline", "r");
    if (!f) return "";
    std::fread(buf, 1, sizeof(buf) - 1, f);
    std::fclose(f);
    std::string name(buf);                          // argv[0] of an app process is its package/process name
    const size_t colon = name.find(':');            // "pkg:service" for secondary processes
    if (colon != std::string::npos) name.resize(colon);
    return name;
}

std::string PickFilesDir() {
    const std::string pkg = PackageName();
    if (pkg.empty()) return "/data/local/tmp";
    const std::string cands[] = {"/data/user/0/" + pkg + "/files", "/data/data/" + pkg + "/files"};
    for (const auto& d : cands) {
        mkdir(d.c_str(), 0771);
        if (access(d.c_str(), W_OK) == 0) return d;
    }
    return "/data/local/tmp";
}

void* Bootstrap(void*) {
    App& app = App::Get();
    app.Configure(PickFilesDir());

    // The overlay only needs EGL, so the menu shows up even if the game module or the offsets are
    // not ready. It explains what is missing.
    gl::InstallEglHook(app.hooks);

    // Wait for the game module (it is loaded before us in practice; poll anyway).
    bool found = false;
    for (int i = 0; i < 240 && !found; ++i) {
        found = app.AttachModule();
        if (!found) usleep(500 * 1000);
    }
    if (!found) { Logf("game module never appeared"); return nullptr; }

    if (g_touchSink.Resolve(app.module, app.offsets)) app.SetTouchSink(&g_touchSink);
    const int n = app.InstallGameHooks();
    Logf("bootstrap done, %d game hook(s) installed", n);
    return nullptr;
}

} // namespace

extern "C" JNIEXPORT jint JNI_OnLoad(JavaVM* vm, void*) {
    SetJavaVM(vm);
    pthread_t th;
    if (pthread_create(&th, nullptr, Bootstrap, nullptr) == 0) pthread_detach(th);
    return JNI_VERSION_1_6;
}

// Called by the Java loader's window-callback proxy (loader class com.carrommod.loader.MainActivity,
// `private static native boolean nativeTouch(int, float, float)`). This is the path the shipped
// loader uses; the CarromActivity exports below are kept for an older smali patch.
extern "C" JNIEXPORT jboolean JNICALL Java_com_carrommod_loader_MainActivity_nativeTouch(JNIEnv*, jclass, jint action,
                                                                                         jfloat x, jfloat y) {
    TouchQueue::Get().Push(action, x, y);
    if (!App::Get().settings.consumeTouchOverUi) return JNI_FALSE;
    return TouchQueue::Get().ShouldConsume(action, x, y) ? JNI_TRUE : JNI_FALSE;
}

// Same names and signatures as the old project, so an existing smali patch keeps working.
// The Java side forwards raw MotionEvent actions/coordinates. Returning true tells it the touch
// belongs to the menu (see Settings::consumeTouchOverUi).
extern "C" JNIEXPORT jboolean JNICALL Java_com_miniclip_carrom_CarromActivity_nativeOverlayTouch(
    JNIEnv*, jclass, jint action, jfloat x, jfloat y) {
    TouchQueue::Get().Push(action, x, y);
    if (!App::Get().settings.consumeTouchOverUi) return JNI_FALSE;
    return TouchQueue::Get().ShouldConsume(action, x, y) ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jboolean JNICALL Java_com_miniclip_carrom_CarromActivity_nativeDumperTouch(
    JNIEnv* env, jclass cls, jint action, jfloat x, jfloat y) {
    return Java_com_miniclip_carrom_CarromActivity_nativeOverlayTouch(env, cls, action, x, y);
}
