// Ties everything together: configuration, game bridge, planner, executor, drawing, menu.
// Host-testable: it never touches GL or JNI. Platform code feeds it frames and touches.
#pragma once
#include <functional>
#include <mutex>
#include <string>

#include "config/Offsets.h"
#include "config/Settings.h"
#include "game/GameBridge.h"
#include "game/ShotExecutor.h"
#include "logic/AutoPlayer.h"
#include "logic/MetadataFinder.h"
#include "logic/OffsetTester.h"
#include "logic/PatternScanner.h"
#include "logic/RuntimeDumper.h"
#include "logic/Prediction.h"
#include "logic/ScreenMap.h"
#include "platform/Hooks.h"
#include "platform/Module.h"
#include "ui/Ui.h"

namespace carrom {

class App {
public:
    static App& Get();

    // Loads settings and offsets from `filesDir`, writes an offsets template if none exists,
    // finds the game module. Safe to call more than once.
    void Configure(const std::string& filesDir, const std::string& moduleNameFragment = "libgame-CARROM");

    // Bootstrap thread: (re)look up the game module and reconfigure the bridge. True if found.
    bool AttachModule(const std::string& moduleNameFragment = "libgame-CARROM");

    // Installs the per-frame game hook if (and only if) its offset is set. Returns hooks installed.
    int InstallGameHooks();

    // Game thread, from the GameUpdate hook.
    void OnGameUpdate(uintptr_t gameManager) { bridge.OnGameUpdate(gameManager); }

    void SetTouchSink(TouchSink* sink) { std::lock_guard<std::mutex> lk(m_mutex); executor.SetSink(sink); }

    // Render thread, between ImGui::NewFrame() and ImGui::Render().
    ui::UiOutput Frame(float screenW, float screenH, float dt, double now);

    void SaveSettingsNow();
    void SaveTesterNow();
    void SetTextures(const ui::Textures& t) { ui.SetTextures(t); }

    // For tests: replace where snapshots / transforms come from.
    void SetSnapshotSource(std::function<bool(FrameSnapshot&)> f) { m_snapshotSource = std::move(f); }
    void SetTransformSource(std::function<WorldAffine()> f) { m_transformSource = std::move(f); }

    Settings settings;
    Offsets offsets;
    ModuleInfo module;
    HookManager hooks;
    GameBridge bridge;
    ShotExecutor executor;
    AutoPlayer autoplay;
    Prediction predLive;     // what is drawn
    Prediction predPlan;     // scratch space of the planner
    ScreenMap screen;
    OffsetTester tester;
    RuntimeDumper dumper;
    PatternScanner scanner;
    MetadataFinder metadataFinder;
    ui::Ui ui{settings, tester, dumper, scanner, metadataFinder};

    const std::string& filesDir() const { return m_filesDir; }
    const std::vector<std::string>& offsetErrors() const { return m_offsetErrors; }
    const std::string& autoPlayNote() const { return m_note; }

private:
    ui::UiStatus BuildStatus(bool calculating) const;
    std::mutex m_mutex;     // bootstrap thread vs render thread
    std::string m_filesDir;
    std::vector<std::string> m_offsetErrors;
    std::string m_note;
    FrameSnapshot m_snap;
    double m_lastSnapTime = -1e9;
    double m_saveAt = 0.0;
    bool m_saveQueued = false;
    bool m_armed = false;
    std::function<bool(FrameSnapshot&)> m_snapshotSource;
    std::function<WorldAffine()> m_transformSource;
};

} // namespace carrom
