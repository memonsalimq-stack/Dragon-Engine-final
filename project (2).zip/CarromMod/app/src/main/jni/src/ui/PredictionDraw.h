// Draws the predicted paths with the old project's look (dotted striker line, arrow head,
// ring markers on pucks, yellow/white start/end dots).
#pragma once
#include "config/Settings.h"
#include "imgui.h"
#include "logic/Prediction.h"
#include "logic/ScreenMap.h"

namespace carrom::ui {

// `suggested`: draw in the "suggested shot" tint (autoplay candidate) instead of the live aim.
void DrawPrediction(ImDrawList* dl, const Prediction& pred, const ScreenMap& map, const Settings& st,
                    float screenW, float screenH, bool suggested);

} // namespace carrom::ui
