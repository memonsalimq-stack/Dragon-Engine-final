#include "ui/PredictionDraw.h"

#include <algorithm>
#include <cmath>

namespace carrom::ui {

namespace {
ImVec2 ClampScreen(ImVec2 p, float W, float H) {
    p.x = std::min(std::max(p.x, 0.f), W);
    p.y = std::min(std::max(p.y, 0.f), H);
    return p;
}
} // namespace

void DrawPrediction(ImDrawList* dl, const Prediction& pred, const ScreenMap& map, const Settings& st, float W,
                    float H, bool suggested) {
    if (!dl || !map.Usable() || pred.scene.piecesCount <= 0) return;

    const float alpha = std::min(std::max(st.lineOpacity, 0.1f), 1.0f);
    const float baseThick = std::max(st.lineThickness, 1.0f);
    const float dpi = std::max(0.5f, H / 1080.f);

    auto toScreen = [&](const Vec2d& w, ImVec2* out) {
        const ScreenPoint p = map.WorldToScreen(w);
        if (!p.valid) return false;
        *out = ClampScreen(ImVec2(p.x, p.y), W, H);
        return true;
    };

    for (int i = 0; i < pred.scene.piecesCount; i++) {
        const auto& piece = pred.scene.pieces[i];
        if (piece.initialPosition == piece.predictedPosition || piece.positions.size() <= 1) continue;
        if (i == 0 && !st.strikerPath) continue;
        if (i != 0 && !st.puckPaths) continue;

        float thick = baseThick;
        ImColor color;
        if (suggested) color = ImColor(0.35f, 1.0f, 0.45f, alpha);
        else if (st.lineStyle == 0) color = i == 0 ? ImColor(1.0f, 0.84f, 0.0f, alpha) : ImColor(0.30f, 0.95f, 1.0f, alpha);
        else color = ImColor(0.18f, 0.72f, 1.0f, alpha);
        if (i == 0) thick += 1.0f;

        ImVec2 first;
        if (!toScreen(piece.positions[0], &first)) continue;

        if (i == 0) {
            auto dotted = [&](ImVec2 a, ImVec2 b) {
                ImVec2 d(b.x - a.x, b.y - a.y);
                const float len = std::sqrt(d.x * d.x + d.y * d.y);
                if (len < 2.f) return;
                d.x /= len; d.y /= len;
                float t = 0.f; bool on = true;
                while (t < len) {
                    float step = on ? 8.f : 7.f;
                    if (t + step > len) step = len - t;
                    if (on) dl->AddLine(ImVec2(a.x + d.x * t, a.y + d.y * t),
                                        ImVec2(a.x + d.x * (t + step), a.y + d.y * (t + step)), color, thick * 0.8f);
                    t += step; on = !on;
                }
            };
            ImVec2 last = first;
            for (size_t j = 1; j < piece.positions.size(); j++) {
                ImVec2 pt;
                if (!toScreen(piece.positions[j], &pt)) continue;
                if (j == 1) dl->AddLine(last, pt, color, thick);
                else dotted(last, pt);
                last = pt;
            }
            const size_t pn = piece.positions.size();
            if (pn >= 2) {
                const Vec2d a = piece.positions[pn - 2], b = piece.positions[pn - 1];
                Vec2d dir(b.x - a.x, b.y - a.y);
                const double dlen = std::sqrt(dir.x * dir.x + dir.y * dir.y);
                if (dlen > 1e-6) {
                    dir.x /= dlen; dir.y /= dlen;
                    ImVec2 ext;
                    if (toScreen(Vec2d(b.x + dir.x * 80.0, b.y + dir.y * 80.0), &ext)) dotted(last, ext);
                }
                ImVec2 p1;
                if (toScreen(piece.positions[1], &p1)) {
                    ImVec2 d(p1.x - first.x, p1.y - first.y);
                    const float dl2 = std::sqrt(d.x * d.x + d.y * d.y);
                    if (dl2 > 4.f) {
                        d.x /= dl2; d.y /= dl2;
                        const ImVec2 tip(first.x + d.x * 44.f, first.y + d.y * 44.f);
                        const ImVec2 n(-d.y, d.x);
                        dl->AddTriangleFilled(tip, ImVec2(tip.x - d.x * 14.f + n.x * 6.f, tip.y - d.y * 14.f + n.y * 6.f),
                                              ImVec2(tip.x - d.x * 14.f - n.x * 6.f, tip.y - d.y * 14.f - n.y * 6.f), color);
                    }
                }
            }
        } else {
            ImVec2 last = first;
            for (size_t j = 1; j < piece.positions.size(); j++) {
                ImVec2 pt;
                if (!toScreen(piece.positions[j], &pt)) continue;
                dl->AddLine(last, pt, color, thick);
                dl->AddCircle(pt, thick + 2.0f, color, 10, 1.6f);
                last = pt;
            }
            ImVec2 endPt;
            dl->AddCircle(first, thick + 2.0f, color, 12, 2.0f);
            if (toScreen(piece.positions.back(), &endPt)) dl->AddCircle(endPt, thick + 2.0f, color, 12, 2.0f);
        }
    }

    // start / end markers
    const float dotR = std::max(2.f, baseThick + 1.f);
    for (int i = 0; i < pred.scene.piecesCount; i++) {
        const auto& piece = pred.scene.pieces[i];
        if (piece.initialPosition == piece.predictedPosition) continue;
        ImVec2 a, b;
        if (toScreen(piece.initialPosition, &a)) dl->AddCircleFilled(a, dotR, ImColor(1.0f, 0.84f, 0.0f, 1.0f));
        if (toScreen(piece.predictedPosition, &b)) dl->AddCircleFilled(b, 16.f * dpi, ImColor(1.0f, 1.0f, 1.0f, 0.7f));
    }
}

} // namespace carrom::ui
