// Where synthetic touches (autoplay drag, pocket taps) go.
#pragma once

namespace carrom {

class TouchSink {
public:
    virtual ~TouchSink() = default;
    virtual bool Available() const = 0;
    virtual void Begin(int id, float x, float y) = 0;
    virtual void Move(int id, float x, float y) = 0;
    virtual void End(int id, float x, float y) = 0;
};

} // namespace carrom
