#include "game/ShotExecutor.h"

#include <cmath>

namespace carrom {

bool ShotExecutor::FireDrag(ScreenXY striker, double angle, double power, float screenHeight) {
    if (Busy() || !CanFire()) return false;
    if (!std::isfinite(angle) || !std::isfinite(power) || !(screenHeight > 0.f)) return false;
    if (!std::isfinite(striker.x) || !std::isfinite(striker.y)) return false;
    if (power < 0.0) power = 0.0;
    if (power > 1.0) power = 1.0;

    const float dirX = (float)std::cos(angle);
    const float dirY = -(float)std::sin(angle);
    const float pullPx = (float)power * 0.30f * screenHeight;
    m_start = striker;
    m_release = {striker.x - dirX * pullPx, striker.y - dirY * pullPx};
    m_cur = m_start;
    m_t = 0.f;
    m_mode = Mode::Press;
    return true;
}

bool ShotExecutor::Tap(ScreenXY at) {
    if (Busy() || !CanFire()) return false;
    if (!std::isfinite(at.x) || !std::isfinite(at.y)) return false;
    m_start = at;
    m_release = at;
    m_cur = at;
    m_t = 0.f;
    m_mode = Mode::Press;
    m_tapOnly = true;
    return true;
}

void ShotExecutor::Update(float dt) {
    if (m_mode == Mode::Idle || !m_sink) return;
    m_t += dt;

    switch (m_mode) {
    case Mode::Press:
        if (m_t >= 0.12f) {
            m_sink->Begin(kTouchId, m_start.x, m_start.y);
            m_t = 0.f;
            m_mode = m_tapOnly ? Mode::TapDown : Mode::Pull;
        }
        break;
    case Mode::Pull: {
        float t = m_t / 0.45f;
        if (t > 1.f) t = 1.f;
        m_cur = {m_start.x + (m_release.x - m_start.x) * t, m_start.y + (m_release.y - m_start.y) * t};
        m_sink->Move(kTouchId, m_cur.x, m_cur.y);
        if (t >= 1.f) { m_mode = Mode::Hold; m_t = 0.f; }
        break;
    }
    case Mode::Hold:
        if (m_t >= 0.20f) {
            m_sink->End(kTouchId, m_release.x, m_release.y);
            m_mode = Mode::Idle;
        }
        break;
    case Mode::TapDown:
        if (m_t >= 0.08f) {
            m_sink->End(kTouchId, m_start.x, m_start.y);
            m_mode = Mode::Idle;
            m_tapOnly = false;
        }
        break;
    case Mode::Idle:
        break;
    }
}

void ShotExecutor::Abort() {
    if (m_sink && (m_mode == Mode::Pull || m_mode == Mode::Hold || m_mode == Mode::TapDown))
        m_sink->End(kTouchId, m_cur.x, m_cur.y);
    m_mode = Mode::Idle;
    m_tapOnly = false;
}

} // namespace carrom
