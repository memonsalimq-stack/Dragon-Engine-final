#include "game/GameBridge.h"

#include <chrono>
#include <cmath>
#include <cstring>

#include "platform/Log.h"
#include "platform/Memory.h"

namespace carrom {

namespace {

long long NowMs() {
    return std::chrono::duration_cast<std::chrono::milliseconds>(
               std::chrono::steady_clock::now().time_since_epoch()).count();
}

template <class T>
bool Rd(uintptr_t base, const OffsetValue& off, T* out) {
    return off.set && mem::ReadAt(base, off.value, out);
}

PieceType ToPieceType(int v) {
    switch (v) {
    case -1: return PieceType::Any;
    case 0: return PieceType::White;
    case 1: return PieceType::Black;
    case 2: return PieceType::Queen;
    case 3: return PieceType::Striker;
    default: return PieceType::Err;
    }
}

PieceState ToPieceState(int v) {
    switch (v) {
    case 1: return PieceState::Default;
    case 2: return PieceState::InPocket;
    case 3: return PieceState::Unknown;
    case 4: return PieceState::Potted;
    default: return PieceState::Err;
    }
}

bool PlausibleCoord(double v) { return std::isfinite(v) && std::fabs(v) < 100.0; }

uint64_t Fnv(uint64_t h, uint64_t v) {
    for (int i = 0; i < 8; ++i) { h ^= (v >> (8 * i)) & 0xff; h *= 0x100000001b3ULL; }
    return h;
}

uint64_t Bits(double d) { uint64_t u; std::memcpy(&u, &d, 8); return u; }

} // namespace

void GameBridge::Configure(const ModuleInfo& module, const Offsets& offsets) {
    m_module = module;
    m_off = offsets;
    m_missing = offsets.MissingRequired();
    if (!module.found) m_status = Status::NoModule;
    else if (!m_missing.empty()) m_status = Status::MissingOffsets;
    else if (!mem::Available()) m_status = Status::NoMemoryAccess;
    else m_status = Status::WaitingForGame;
}

bool GameBridge::HasFreshUpdate() const {
    const long long last = m_lastUpdateMs.load();
    return last != 0 && NowMs() - last < 1500;
}

void GameBridge::OnGameUpdate(uintptr_t gm) {
    if (!gm) return;
    m_gm.store(gm);
    m_lastUpdateMs.store(NowMs());

    // Optional exact world->screen transform, same sampling as the old project.
    if (!m_off.TransformFn.set || !m_off.TransformScale.set || !m_module.found) return;
    if (m_off.TransformFn.value >= m_module.size || m_off.TransformScale.value >= m_module.size) return;

    float scl = 0.f;
    if (!mem::Read(m_module.base + m_off.TransformScale.value, &scl)) return;
    if (!(scl == scl && scl >= 0.25f && scl <= 8.0f)) return;

    struct Dbl2 { double x, y; };
    auto fn = (Dbl2(*)(uintptr_t, double, double))(m_module.base + m_off.TransformFn.value);
    const Dbl2 c1 = fn(gm, 0.0, 0.0), c2 = fn(gm, 1.0, 0.0), c3 = fn(gm, 0.0, 1.0);
    const double sc = scl;
    WorldAffine a;
    a.ox = c1.x * sc; a.oy = c1.y * sc;
    a.vxx = (c2.x - c1.x) * sc; a.vxy = (c2.y - c1.y) * sc;
    a.vyx = (c3.x - c1.x) * sc; a.vyy = (c3.y - c1.y) * sc;
    a.valid = std::isfinite(a.ox) && std::isfinite(a.oy) && std::isfinite(a.vxx) &&
              std::isfinite(a.vxy) && std::isfinite(a.vyx) && std::isfinite(a.vyy) &&
              (a.vxx * a.vyy - a.vxy * a.vyx) != 0.0;
    if (a.valid) {
        std::lock_guard<std::mutex> lk(m_mutex);
        m_affine = a;
    }
}

WorldAffine GameBridge::Transform() const {
    std::lock_guard<std::mutex> lk(m_mutex);
    return m_affine;
}

bool GameBridge::Fail(const std::string& why) {
    std::lock_guard<std::mutex> lk(m_mutex);
    m_lastError = why;
    m_status = Status::ReadFailed;
    return false;
}

std::string GameBridge::StatusText() const {
    switch (m_status.load()) {
    case Status::NoModule: return "game module not found";
    case Status::MissingOffsets: return "offsets missing: " + std::to_string(m_missing.size()) + " required keys unset";
    case Status::NoMemoryAccess: return "safe memory reads unavailable on this device";
    case Status::WaitingForGame:
        return m_gm.load() ? "waiting: no frame from the game yet" : "waiting for the game (hook has not fired)";
    case Status::Ready: return "ready";
    case Status::ReadFailed: {
        std::lock_guard<std::mutex> lk(m_mutex);
        return "read failed: " + m_lastError;
    }
    }
    return "unknown";
}

bool GameBridge::BuildSnapshot(FrameSnapshot& out) {
    out = FrameSnapshot{};
    const Status s = m_status.load();
    if (s == Status::NoModule || s == Status::MissingOffsets || s == Status::NoMemoryAccess) return false;

    const uintptr_t gm = m_gm.load();
    if (!gm || !HasFreshUpdate()) {
        m_status = Status::WaitingForGame;
        return false;
    }
    const Offsets& o = m_off;

    // --- state manager: player turn --------------------------------------------------
    uintptr_t sm = 0, stackObj = 0, stackData = 0, lastState = 0;
    uintptr_t stackCount = 0;
    int32_t stateId = -1;
    if (!Rd(gm, o.GmStateManager, &sm) || !mem::PlausiblePointer(sm)) return Fail("state manager pointer");
    if (!Rd(sm, o.SmStack, &stackObj) || !mem::PlausiblePointer(stackObj)) return Fail("state stack pointer");
    if (!Rd(stackObj, o.ArrCount, &stackCount) || stackCount == 0 || stackCount > 256) return Fail("state stack count");
    if (!Rd(stackObj, o.ArrData, &stackData) || !mem::PlausiblePointer(stackData)) return Fail("state stack data");
    if (!mem::Read(stackData + (stackCount - 1) * 8, &lastState) || !mem::PlausiblePointer(lastState))
        return Fail("last state pointer");
    if (!Rd(lastState, o.StateId, &stateId)) return Fail("state id");
    const bool playerTurn = stateId == 4; // GameStateManager::isPlayerTurn in the old source

    // --- board pieces ----------------------------------------------------------------
    uintptr_t board = 0, arr = 0, arrData = 0, count = 0;
    if (!Rd(gm, o.GmBoard, &board) || !mem::PlausiblePointer(board)) return Fail("board pointer");
    if (!Rd(board, o.BoardPieces, &arr) || !mem::PlausiblePointer(arr)) return Fail("pieces array pointer");
    if (!Rd(arr, o.ArrCount, &count) || count == 0 || count > 40) return Fail("pieces count " + std::to_string(count));
    if (!Rd(arr, o.ArrData, &arrData) || !mem::PlausiblePointer(arrData)) return Fail("pieces data pointer");

    FrameSnapshot snap;
    uint64_t hash = 0xcbf29ce484222325ULL;
    int strikers = 0;
    for (uintptr_t i = 0; i < count; ++i) {
        uintptr_t piece = 0;
        if (!mem::Read(arrData + i * 8, &piece) || !mem::PlausiblePointer(piece)) continue;
        double pos[2] = {0, 0};
        int32_t type = 0, state = 0;
        if (!Rd(piece, o.PiecePos, &pos)) return Fail("piece position read");
        if (!Rd(piece, o.PieceType, &type) || !Rd(piece, o.PieceState, &state)) return Fail("piece type/state read");
        if (!PlausibleCoord(pos[0]) || !PlausibleCoord(pos[1])) continue;

        SnapshotPiece sp;
        sp.id = -1; // the game-side id is unknown in this project; drag firing does not need it
        sp.type = ToPieceType(type);
        sp.state = ToPieceState(state);
        sp.pos = {pos[0], pos[1]};
        double radius = 0.0;
        if (Rd(piece, o.PieceRadius, &radius) && std::isfinite(radius) && radius > 0.01 && radius < 10.0)
            sp.radius = radius;
        if (sp.type == PieceType::Striker) ++strikers;
        hash = Fnv(Fnv(Fnv(Fnv(hash, Bits(pos[0])), Bits(pos[1])), (uint64_t)type), (uint64_t)state);
        snap.pieces.push_back(sp);
    }
    if (strikers != 1) return Fail("expected exactly one striker, found " + std::to_string(strikers));
    snap.generation = hash;
    snap.playerTurn = playerTurn;

    // --- aim ---------------------------------------------------------------------------
    uintptr_t vs = 0, guide = 0;
    double aimAngle = 0.0, aimPower = 0.0;
    if (!Rd(gm, o.GmVisualStriker, &vs) || !mem::PlausiblePointer(vs)) return Fail("visual striker pointer");
    if (!Rd(vs, o.StrikerGuide, &guide) || !mem::PlausiblePointer(guide)) return Fail("visual guide pointer");
    if (!Rd(guide, o.GuideAimAngle, &aimAngle) || !std::isfinite(aimAngle)) return Fail("aim angle");
    if (!Rd(vs, o.StrikerPower, &aimPower) || !std::isfinite(aimPower)) return Fail("aim power");
    snap.aimAngle = aimAngle;
    snap.aimPower = aimPower;

    // --- rules -------------------------------------------------------------------------
    uintptr_t rules = 0, classVec = 0;
    if (!Rd(gm, o.GmRules, &rules) || !mem::PlausiblePointer(rules)) return Fail("rules pointer");
    if (!Rd(rules, o.RulesClassifications, &classVec) || !mem::PlausiblePointer(classVec)) return Fail("classification vector");
    int32_t myClass = -8;
    if (!mem::Read(classVec + (playerTurn ? 0 : 4), &myClass)) return Fail("classification value");
    snap.targetPiece = ToPieceType(myClass);
    uint8_t queenCover = 0;
    uint32_t potted = 0xFFFFFFFFu;
    if (!Rd(rules, o.RulesQueenCover, &queenCover)) return Fail("queen cover flag");
    if (!Rd(rules, o.RulesPottedPocket, &potted)) return Fail("potted pocket id");
    snap.queenCoverRequired = queenCover != 0;
    snap.pottedPocketId = potted;

    // --- optional: pockets, spin, max power --------------------------------------------
    uintptr_t props = 0, pocketsPtr = 0;
    if (Rd(board, o.BoardProps, &props) && mem::PlausiblePointer(props) &&
        Rd(props, o.PropsPockets, &pocketsPtr) && mem::PlausiblePointer(pocketsPtr)) {
        double p[8];
        if (mem::Read(pocketsPtr, p, sizeof(p))) {
            bool ok = true;
            for (double v : p) ok = ok && PlausibleCoord(v);
            if (ok) for (int i = 0; i < 4; ++i) snap.pockets[i] = {p[i * 2], p[i * 2 + 1]};
        }
    }

    uintptr_t strikerProps = 0;
    if (o.StrikerProps.set && m_module.found &&
        mem::Read(m_module.base + o.StrikerProps.value, &strikerProps) && mem::PlausiblePointer(strikerProps)) {
        double mp = 0.0;
        if (Rd(strikerProps, o.PropsMaxPower, &mp) && std::isfinite(mp) && mp > 1.0 && mp < 10000.0) snap.maxPower = mp;

        uintptr_t ve = 0;
        double mul = 0.0, eng[2] = {0, 0};
        if (Rd(gm, o.GmVisualEnglish, &ve) && mem::PlausiblePointer(ve) && Rd(ve, o.EnglishValue, &eng) &&
            Rd(strikerProps, o.PropsEnglishMul, &mul) && std::isfinite(mul) && std::isfinite(eng[0]) &&
            std::isfinite(eng[1]))
            snap.spin = {eng[0] * mul, eng[1] * mul};
    }

    snap.valid = true;
    out = std::move(snap);
    m_status = Status::Ready;
    return true;
}

} // namespace carrom
