#include "logic/StringScanner.h"

#include <cctype>

#include "platform/Memory.h"

namespace carrom {

namespace {
bool Printable(uint8_t c) { return (c >= 0x20 && c < 0x7f) || c == '\t'; }
std::string Lower(std::string s) {
    for (char& c : s) c = (char)std::tolower((unsigned char)c);
    return s;
}
} // namespace

std::vector<StringHit> FindStringsInBuffer(const uint8_t* data, size_t len, size_t minLen,
                                           const std::string& contains, size_t maxResults) {
    std::vector<StringHit> out;
    if (!data || len == 0 || minLen == 0) return out;
    const std::string needle = Lower(contains);
    size_t i = 0;
    while (i < len && out.size() < maxResults) {
        if (!Printable(data[i])) { ++i; continue; }
        size_t j = i;
        while (j < len && Printable(data[j])) ++j;
        if (j - i >= minLen) {
            std::string text((const char*)data + i, j - i);
            if (needle.empty() || Lower(text).find(needle) != std::string::npos) {
                StringHit h;
                h.offset = i;
                h.text = text.size() > 96 ? text.substr(0, 96) : text;
                out.push_back(std::move(h));
            }
        }
        i = j;
    }
    return out;
}

std::vector<StringHit> FindStrings(const MappedModule& module, size_t minLen, const std::string& contains,
                                   size_t maxResults) {
    if (module.base == 0 || module.end <= module.base) return {};
    const auto buf = mem::ReadRange(module.base, module.end - module.base);
    return FindStringsInBuffer(buf.data(), buf.size(), minLen, contains, maxResults);
}

} // namespace carrom
