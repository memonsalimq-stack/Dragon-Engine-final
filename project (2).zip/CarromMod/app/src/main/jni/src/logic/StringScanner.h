// Printable-string search in a module (or buffer): the usual first step when reverse engineering
// a native game without symbols (find a known log/UI/asset string, then follow what uses it).
#pragma once
#include <cstdint>
#include <string>
#include <vector>

#include "platform/ModuleEnum.h"

namespace carrom {

struct StringHit {
    uintptr_t offset = 0;   // offset from the start of the scanned range (RVA for a module)
    std::string text;       // truncated to 96 characters
};

// ASCII strings (0x20..0x7E and tab) of at least minLen characters. `contains` (case-insensitive)
// keeps only strings holding that substring; empty keeps all.
std::vector<StringHit> FindStringsInBuffer(const uint8_t* data, size_t len, size_t minLen,
                                           const std::string& contains, size_t maxResults);
std::vector<StringHit> FindStrings(const MappedModule& module, size_t minLen, const std::string& contains,
                                   size_t maxResults = 64);

} // namespace carrom
