// Finds a Unity IL2CPP global-metadata in this process' MEMORY, wherever it is.
//
// Why: protected games encrypt global-metadata.dat on disk and decrypt it into memory at
// startup, so parsing the file (RuntimeDumper::ReadMetadataHeaderFromFile) fails or is useless.
// The decrypted copy, however, begins with the same magic (0xFAB11BAF) and the same header
// layout as an unprotected file, so it can be found by scanning readable memory and validated
// with the exact same ported parser (logic/Il2CppMetadata.h). The found copy can then be written
// to a file and fed to any offline dumper.
//
// Assumption (stated, not verified on a real protected game): the decrypted metadata is a single
// contiguous block that begins 4-byte aligned. Allocators and mmap guarantee that alignment for
// a block's start, so a standard layout is found; a game that hides the metadata by splitting it
// or scrambling the header even in memory would not be found by this and needs manual analysis.
#pragma once
#include <atomic>
#include <cstdint>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

#include "logic/Il2CppMetadata.h"
#include "platform/MemoryRegions.h"

namespace carrom {

struct FoundMetadata {
    uintptr_t address = 0;
    int32_t rawVersion = 0;
    double version = 0.0;
    size_t size = 0;          // max(table offset + table size) over the header's tables
    std::string region;       // mapping path, "" if anonymous
};

class MetadataFinder {
public:
    MetadataFinder() = default;
    MetadataFinder(const MetadataFinder&) = delete;
    MetadataFinder& operator=(const MetadataFinder&) = delete;
    ~MetadataFinder();

    // Size implied by a parsed header: the furthest end among its tables. 0 if implausible
    // (no tables, negative values, or > 1 GiB).
    static size_t ComputeSize(const il2cpp::MetadataResult& header);

    // Synchronous scan of the given regions. `progress` (optional) receives bytes scanned so far;
    // `cancel` (optional) is polled between blocks. Regions larger than maxRegionBytes, device
    // mappings and unreadable regions are skipped.
    static std::vector<FoundMetadata> Scan(const std::vector<MemRegion>& regions, size_t maxResults,
                                           size_t maxRegionBytes, std::atomic<size_t>* progress,
                                           const std::atomic<bool>* cancel);

    // Background scan of every region of this process (so the game's render thread is not blocked
    // for seconds on a big heap). Poll Running()/BytesScanned()/Results().
    void StartAsync(size_t maxResults = 8);
    void Cancel();
    bool Running() const { return m_running.load(); }
    size_t BytesScanned() const { return m_progress.load(); }
    std::vector<FoundMetadata> Results() const;

    // Copies the found block to a file. Unreadable chunks are zero-filled and reported in *note.
    static bool Dump(const FoundMetadata& found, const std::string& path, std::string* error,
                     std::string* note = nullptr);

private:
    void Join();
    std::thread m_thread;
    std::atomic<bool> m_running{false};
    std::atomic<bool> m_cancel{false};
    std::atomic<size_t> m_progress{0};
    mutable std::mutex m_mutex;
    std::vector<FoundMetadata> m_results;
};

} // namespace carrom
