// Physics/board constants carried over from the old project (game/inc/GameConstants.h).
// Units are board units, board centre at (0,0). Not re-measured against a live game.
#pragma once

namespace carrom {

inline constexpr int MAX_PIECES_COUNT = 20;

inline constexpr double STRIKER_RADIUS = 2.10;
inline constexpr double PIECE_RADIUS = 1.55;

inline constexpr double BOARD_WIDTH = 74.0;
inline constexpr double BOARD_HEIGHT = 74.0;
inline constexpr double BOARD_HALF_WIDTH = BOARD_WIDTH / 2.0;
inline constexpr double BOARD_HALF_HEIGHT = BOARD_HEIGHT / 2.0;

inline constexpr int BOARD_POCKETS_COUNT = 4;
inline constexpr int BOARD_SHAPE_SIZE = 32;

inline constexpr double POCKET_RADIUS = 3.3;
inline constexpr double POCKET_RADIUS_SQUARE = POCKET_RADIUS * POCKET_RADIUS;

inline constexpr double TIME_PER_TICK = 0.002;
inline constexpr double MIN_TIME = 1E-11;

inline constexpr double PI = 3.14159265358979;
inline constexpr double MAX_ANGLE_RADIANS = 2.0 * PI;

} // namespace carrom
