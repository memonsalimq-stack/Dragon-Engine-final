// AOB (array-of-bytes) signature scanning and known-constant scanning: the standard way to
// re-find a function or a struct field in a native binary that has no symbols or metadata —
// exactly the situation for a protected game like Carrom Pool (plain C++/Obj-C runtime, no
// global-metadata.dat, offsets shift on every update). Works equally over:
//   - this process' own live memory (via platform/Memory.h), for a module found by ModuleEnum
//   - a plain in-memory buffer (e.g. a file already dumped by RuntimeDumper, or a buffer the
//     caller mmap'd/read in some other way)
// so the same pattern found live can be re-verified against an offline dump, or vice versa.
#pragma once
#include <cstdint>
#include <string>
#include <vector>

#include "platform/ModuleEnum.h"

namespace carrom {

struct PatternByte {
    uint8_t value = 0;
    bool wildcard = false;
};

// Parses an IDA/CE-style pattern: hex byte pairs separated by spaces, "?" or "??" as a wildcard
// byte. Case-insensitive. Returns an empty vector (and fills `error` if non-null) on anything
// that isn't a valid hex byte or a wildcard token.
std::vector<PatternByte> ParsePattern(const std::string& text, std::string* error = nullptr);

class PatternScanner {
public:
    // Scans a live module (addresses are module.base + the returned offsets would be
    // result - module.base, but results here are returned as absolute runtime addresses, same
    // convention OffsetTester uses so a hit can be pasted straight into its "chain" field as
    // "<hit - module.base, in hex>").
    std::vector<uintptr_t> ScanModule(const MappedModule& module, const std::vector<PatternByte>& pattern,
                                      size_t maxResults = 16) const;

    // Scans a plain buffer (e.g. bytes already read from a dumped file). Returned values are
    // byte offsets into `data`, not addresses.
    static std::vector<size_t> ScanBuffer(const uint8_t* data, size_t len, const std::vector<PatternByte>& pattern,
                                          size_t maxResults = 16);

    // Finds every 4-byte-aligned occurrence of a float, or 8-byte-aligned occurrence of a
    // double, within `tolerance` — the "I know this constant from the old source, where is it
    // in the new build" search (e.g. STRIKER_RADIUS, TIME_PER_TICK). Unaligned scanning is
    // intentionally not offered: compilers always naturally-align floating constants in
    // .rodata, so scanning only aligned offsets is both faster and has far fewer false
    // positives from unrelated byte sequences.
    std::vector<uintptr_t> FindFloat(const MappedModule& module, float value, float tolerance = 1e-5f,
                                     size_t maxResults = 32) const;
    std::vector<uintptr_t> FindDouble(const MappedModule& module, double value, double tolerance = 1e-9,
                                      size_t maxResults = 32) const;

    static std::vector<size_t> FindFloatInBuffer(const uint8_t* data, size_t len, float value,
                                                 float tolerance = 1e-5f, size_t maxResults = 32);
    static std::vector<size_t> FindDoubleInBuffer(const uint8_t* data, size_t len, double value,
                                                  double tolerance = 1e-9, size_t maxResults = 32);
};

} // namespace carrom
