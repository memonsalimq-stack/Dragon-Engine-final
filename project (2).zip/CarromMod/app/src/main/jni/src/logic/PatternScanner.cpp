#include "logic/PatternScanner.h"

#include <cmath>
#include <cstring>

#include "platform/Memory.h"

namespace carrom {

namespace {
int HexNibble(char c, bool* ok) {
    *ok = true;
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    *ok = false;
    return 0;
}

// Reads an entire module into a host buffer, 4 KB at a time, zero-filling any chunk that
// cannot be read (same strategy logic/RuntimeDumper.cpp uses when dumping to a file) — so a
// module with holes or guard pages still gets scanned everywhere it legitimately can be.
std::vector<uint8_t> ReadWholeModule(const MappedModule& module) {
    std::vector<uint8_t> buf;
    if (module.base == 0 || module.end <= module.base) return buf;
    const size_t total = module.end - module.base;
    buf.resize(total, 0);
    constexpr size_t kChunk = 4096;
    for (size_t off = 0; off < total; off += kChunk) {
        const size_t want = std::min(kChunk, total - off);
        mem::Read(module.base + off, buf.data() + off, want); // ignore failure: stays zero-filled
    }
    return buf;
}
} // namespace

std::vector<PatternByte> ParsePattern(const std::string& text, std::string* error) {
    std::vector<PatternByte> out;
    std::string tok;
    auto flush = [&](bool* bad) -> bool {
        if (tok.empty()) return true;
        if (tok == "?" || tok == "??") {
            out.push_back({0, true});
        } else if (tok.size() == 2) {
            bool ok1 = false, ok2 = false;
            const int hi = HexNibble(tok[0], &ok1);
            const int lo = HexNibble(tok[1], &ok2);
            if (!ok1 || !ok2) { *bad = true; return false; }
            out.push_back({(uint8_t)((hi << 4) | lo), false});
        } else {
            *bad = true;
            return false;
        }
        tok.clear();
        return true;
    };

    bool bad = false;
    for (char c : text) {
        if (c == ' ' || c == '\t' || c == ',') { if (!flush(&bad)) break; }
        else tok += c;
    }
    if (!bad) flush(&bad);

    if (bad) {
        if (error) *error = "invalid pattern: use hex byte pairs separated by spaces, '\?' or '\?\?' for a wildcard byte";
        return {};
    }
    if (out.empty() && error) *error = "empty pattern";
    return out;
}

std::vector<size_t> PatternScanner::ScanBuffer(const uint8_t* data, size_t len, const std::vector<PatternByte>& pattern,
                                               size_t maxResults) {
    std::vector<size_t> hits;
    if (!data || pattern.empty() || len < pattern.size()) return hits;
    const size_t last = len - pattern.size();
    for (size_t i = 0; i <= last && hits.size() < maxResults; ++i) {
        bool match = true;
        for (size_t j = 0; j < pattern.size(); ++j) {
            if (pattern[j].wildcard) continue;
            if (data[i + j] != pattern[j].value) { match = false; break; }
        }
        if (match) hits.push_back(i);
    }
    return hits;
}

std::vector<uintptr_t> PatternScanner::ScanModule(const MappedModule& module, const std::vector<PatternByte>& pattern,
                                                  size_t maxResults) const {
    std::vector<uintptr_t> out;
    if (pattern.empty()) return out;
    const auto buf = ReadWholeModule(module);
    if (buf.empty()) return out;
    for (size_t off : ScanBuffer(buf.data(), buf.size(), pattern, maxResults)) out.push_back(module.base + off);
    return out;
}

std::vector<size_t> PatternScanner::FindFloatInBuffer(const uint8_t* data, size_t len, float value, float tolerance,
                                                      size_t maxResults) {
    std::vector<size_t> hits;
    if (!data || len < 4 || !std::isfinite(value)) return hits;
    for (size_t i = 0; i + 4 <= len && hits.size() < maxResults; i += 4) {
        float v;
        std::memcpy(&v, data + i, 4);
        if (std::isfinite(v) && std::fabs(v - value) <= tolerance) hits.push_back(i);
    }
    return hits;
}

std::vector<size_t> PatternScanner::FindDoubleInBuffer(const uint8_t* data, size_t len, double value, double tolerance,
                                                       size_t maxResults) {
    std::vector<size_t> hits;
    if (!data || len < 8 || !std::isfinite(value)) return hits;
    for (size_t i = 0; i + 8 <= len && hits.size() < maxResults; i += 8) {
        double v;
        std::memcpy(&v, data + i, 8);
        if (std::isfinite(v) && std::fabs(v - value) <= tolerance) hits.push_back(i);
    }
    return hits;
}

std::vector<uintptr_t> PatternScanner::FindFloat(const MappedModule& module, float value, float tolerance,
                                                 size_t maxResults) const {
    std::vector<uintptr_t> out;
    const auto buf = ReadWholeModule(module);
    if (buf.empty()) return out;
    for (size_t off : FindFloatInBuffer(buf.data(), buf.size(), value, tolerance, maxResults))
        out.push_back(module.base + off);
    return out;
}

std::vector<uintptr_t> PatternScanner::FindDouble(const MappedModule& module, double value, double tolerance,
                                                  size_t maxResults) const {
    std::vector<uintptr_t> out;
    const auto buf = ReadWholeModule(module);
    if (buf.empty()) return out;
    for (size_t off : FindDoubleInBuffer(buf.data(), buf.size(), value, tolerance, maxResults))
        out.push_back(module.base + off);
    return out;
}

} // namespace carrom
