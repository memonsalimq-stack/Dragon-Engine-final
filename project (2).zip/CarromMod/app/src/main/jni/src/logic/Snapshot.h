// The only data the prediction / autoplay logic needs from the game.
// A GameBridge fills this from process memory; tests fill it by hand.
#pragma once
#include <array>
#include <cstdint>
#include <vector>

#include "math/Vec.h"

namespace carrom {

enum class PieceType : int { Any = -1, White = 0, Black = 1, Queen = 2, Striker = 3, Err = -8 };
enum class PieceState : int { Default = 1, InPocket = 2, Unknown = 3, Potted = 4, Err = -8 };

struct SnapshotPiece {
    int id = -1;                       // game-side id, used when firing at a specific piece
    PieceType type = PieceType::Err;
    PieceState state = PieceState::Err;
    Vec2d pos;                         // world units
    double radius = 0.0;               // 0 = unknown, logic falls back to constants
};

struct FrameSnapshot {
    bool valid = false;                // false: nothing below may be used
    uint64_t generation = 0;           // bump whenever the table changed (invalidates prediction cache)
    bool playerTurn = false;
    std::vector<SnapshotPiece> pieces; // includes exactly one striker when valid
    double aimAngle = 0.0;             // radians, current visual aim
    double aimPower = 0.0;             // 0..1, current visual power
    Vec2d spin;                        // english, already multiplied by the game's multiplier
    double maxPower = 120.0;           // game's striker max power (units/s)
    PieceType targetPiece = PieceType::Any;
    bool queenCoverRequired = false;
    uint32_t pottedPocketId = 0xFFFFFFFFu; // >=4 means "no restriction"
    std::array<Vec2d, 4> pockets = {Vec2d{-34.5, -34.5}, Vec2d{34.5, -34.5},
                                    Vec2d{34.5, 34.5}, Vec2d{-34.5, 34.5}};
};

} // namespace carrom
