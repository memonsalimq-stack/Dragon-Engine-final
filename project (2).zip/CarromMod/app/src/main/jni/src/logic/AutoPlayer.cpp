#include "logic/AutoPlayer.h"

#include <algorithm>
#include <cmath>
#include <vector>

namespace carrom {

namespace {
constexpr double kMaxAngle = 360.0 / (180.0 / PI);

bool QueenOnTable(Prediction& pred) { return pred.FindQueen() != nullptr; }

bool IsTargetClass(PieceType myclass, PieceType c) {
    if (myclass == PieceType::Any) return c != PieceType::Striker && c != PieceType::Queen;
    return c == myclass;
}
} // namespace

double NormalizeAngle(double angle) {
    double a = angle;
    if (a >= kMaxAngle) a = std::fmod(a, kMaxAngle);
    else if (a < 0) a = kMaxAngle - std::fmod(-a, kMaxAngle);
    return a;
}

void AutoPlayer::Reset() {
    m_cand = Candidate{};
    m_lastFailedStrikerPos = {-1000.0, -1000.0};
    m_state = State::Idle;
    m_nominationFrames = 0;
    m_nominationClicked = false;
}

ShotAction AutoPlayer::Shoot(Prediction& pred, const FrameSnapshot& snap, double angle, double power) {
    pred.Run(snap, false, angle, power);

    bool nominating = false;
    if (snap.queenCoverRequired && snap.targetPiece != PieceType::Any) {
        if (m_cand.idx != -1 && snap.pottedPocketId != (uint32_t)m_cand.pocketIndex) nominating = true;
    }

    if (nominating) {
        m_pendingAngle = angle;
        m_pendingPower = power;
        m_state = State::Nominating;
        m_nominationFrames = 0;
        m_nominationClicked = false;
        return {};
    }

    ShotAction a;
    a.kind = ShotAction::Kind::Fire;
    a.angle = angle;
    a.power = power;
    a.pocketIndex = m_cand.pocketIndex;
    a.pieceIdx = m_cand.idx;
    if (m_cand.idx >= 0 && m_cand.idx < pred.scene.piecesCount)
        a.gamePieceId = pred.scene.pieces[m_cand.idx].gameId;
    Reset();
    return a;
}

bool AutoPlayer::ScanSlow(Prediction& pred, const FrameSnapshot& snap, double angleStep) {
    if (m_cand.idx != -1) return false;
    if (pred.scene.piecesCount <= 0) return false;

    if (!m_slowScanning || pred.scene.pieces[0].initialPosition != m_slowStrikerPos) {
        m_slowAngle = 0.0;
        m_slowScanning = true;
        m_slowStrikerPos = pred.scene.pieces[0].initialPosition;
    }

    const PieceType myclass = snap.targetPiece;
    const uint32_t pottedPocket = snap.pottedPocketId;
    static const double kPowers[3] = {0.52, 0.76, 1.0};

    int steps = 0;
    while (steps < 10 && m_slowAngle < kMaxAngle) {
        const double angle = m_slowAngle;
        m_slowAngle += angleStep;
        ++steps;

        for (double power : kPowers) {
            pred.Run(snap, true, angle, power, snap.spin);

            int targetIdx = -1;
            for (int i = 1; i < pred.scene.piecesCount; i++) {
                auto& piece = pred.scene.pieces[i];
                if (piece.originalOnTable && !piece.onTable) {
                    bool valid = IsTargetClass(myclass, piece.classification);
                    if (pottedPocket < 4 && (uint32_t)piece.pocketIndex != pottedPocket) valid = false;
                    if (valid) { targetIdx = i; break; }
                }
            }
            if (targetIdx == -1) continue;

            if (!pred.scene.pieces[0].onTable) continue;
            // Kept exactly as in the old project: slow mode only works while the queen is on the table.
            if (!QueenOnTable(pred) && myclass != PieceType::Queen) continue;
            auto* firstHit = pred.scene.collision.firstHitPiece;
            if (!firstHit) continue;
            if (myclass == PieceType::Any) {
                if (firstHit->classification == PieceType::Queen) continue;
            } else if (firstHit->classification != myclass) continue;

            m_cand.idx = targetIdx;
            m_cand.angle = angle;
            m_cand.power = power;
            m_cand.pocketIndex = pred.scene.pieces[targetIdx].pocketIndex;
            return true;
        }
    }

    if (m_slowAngle >= kMaxAngle) {
        m_slowScanning = false;
        m_slowAngle = 0.0;
        m_state = State::Idle;
    }
    return false;
}

bool AutoPlayer::ScanFast(Prediction& pred, const FrameSnapshot& snap) {
    if (m_cand.idx != -1) return false;
    if (pred.scene.piecesCount < 2) return false;
    auto& striker = pred.scene.pieces[0];
    if (striker.initialPosition == m_lastFailedStrikerPos) return false;

    const PieceType myclass = snap.targetPiece;
    const uint32_t pottedPocket = snap.pottedPocketId;
    std::vector<Candidate> candidates;
    const auto& pockets = pred.pockets;

    for (int i = 1; i < pred.scene.piecesCount; i++) {
        auto& piece = pred.scene.pieces[i];
        if (!piece.originalOnTable) continue;
        const bool isCandidate = (myclass == PieceType::Any) ? piece.classification != PieceType::Queen
                                                             : piece.classification == myclass;
        if (!isCandidate) continue;

        for (int pk = 0; pk < (int)pockets.size(); pk++) {
            if (pottedPocket < 4 && (uint32_t)pk != pottedPocket) continue;
            Point2D toPocket = pockets[pk] - piece.initialPosition;
            const double distTargetToPocket = std::sqrt(toPocket.square());
            if (distTargetToPocket < 0.1) continue;

            Point2D direction = toPocket * (1.0 / distTargetToPocket);
            Point2D ghost = piece.initialPosition - direction * (PIECE_RADIUS + STRIKER_RADIUS);
            Point2D shotLine = ghost - striker.initialPosition;
            const double distStrikerToTarget = std::sqrt(shotLine.square());
            double angle = std::atan2(shotLine.y, shotLine.x);
            if (angle < 0) angle += 2 * PI;

            Candidate c;
            c.idx = i; c.angle = angle; c.score = distStrikerToTarget + distTargetToPocket;
            c.pocketIndex = pk; c.power = 1.0;
            candidates.push_back(c);
        }
    }

    std::sort(candidates.begin(), candidates.end());

    bool found = false;
    int tried = 0;
    for (const auto& cand : candidates) {
        if (++tried > 24) break;
        const double angle = NormalizeAngle(cand.angle);

        auto shotIsValid = [&]() -> bool {
            if (!pred.firstHitIsTarget) return false;
            if (!pred.scene.pieces[0].onTable) return false;
            if (pred.scene.pieces[cand.idx].onTable) return false;
            if (pred.scene.pieces[cand.idx].pocketIndex != cand.pocketIndex) return false;

            bool good = false;
            for (int i = 1; i < pred.scene.piecesCount; i++) {
                auto& p = pred.scene.pieces[i];
                if (IsTargetClass(myclass, p.classification) && p.originalOnTable && !p.onTable) good = true;
            }
            if (good && pred.scene.collision.firstHitPiece) {
                auto* fh = pred.scene.collision.firstHitPiece;
                if (myclass != PieceType::Any && fh->classification != myclass) good = false;
                else if (myclass == PieceType::Any && fh->classification == PieceType::Queen) good = false;
            }
            auto* q = pred.FindQueen();
            if (good && q && q->originalOnTable && !q->onTable && myclass != PieceType::Queen) good = false;
            return good;
        };
        auto eval = [&](double a, double p) -> bool {
            pred.Run(snap, true, a, p, snap.spin, cand);
            return shotIsValid();
        };

        static const double tiers[3] = {0.52, 0.76, 1.0};
        for (double tier : tiers) {
            if (!eval(angle, tier)) continue;

            double bestAngle = angle, bestPower = tier;
            static const double angleDeltas[4] = {-0.008, 0.008, -0.022, 0.022};
            static const double powerDeltas[2] = {-0.07, 0.07};
            for (double da : angleDeltas) {
                const double a2 = NormalizeAngle(angle + da);
                if (eval(a2, bestPower)) bestAngle = a2;
            }
            for (double dp : powerDeltas) {
                double p2 = std::clamp(tier + dp, 0.24, 1.0);
                if (eval(bestAngle, p2)) bestPower = p2;
            }

            m_cand = cand;
            m_cand.angle = bestAngle;
            m_cand.power = bestPower;
            found = true;
            break;
        }
        if (found) break;
    }

    if (!found) {
        m_lastFailedStrikerPos = striker.initialPosition;
        m_scan = Scan::Slow;
    }
    return found;
}

ShotAction AutoPlayer::Update(Prediction& pred, const FrameSnapshot& snap, double now) {
    if (m_cooldown > 0) { --m_cooldown; return {}; }
    if (!m_enabled || !snap.valid || !snap.playerTurn) { m_state = State::Idle; return {}; }

    if (m_state == State::Idle) {
        m_state = State::Scanning;
        m_scan = m_preferred;
        return {};
    }

    if (m_state == State::Scanning) {
        // The scanners need an initialised scene for the current table.
        pred.Run(snap, true, snap.aimAngle, snap.aimPower, snap.spin);
        if (pred.scene.piecesCount < 2) return {};

        if (m_cand.idx == -1) {
            if (m_scan == Scan::Fast) {
                if (now - m_lastFastScanTime > 3.0) {
                    m_lastFastScanTime = now;
                    ScanFast(pred, snap);
                }
            } else {
                ScanSlow(pred, snap, 0.003);
            }
        }
        if (m_cand.idx != -1) return Shoot(pred, snap, m_cand.angle, m_cand.power);
        return {};
    }

    // Nominating: click the pocket first, then fire.
    ++m_nominationFrames;
    if (m_nominationFrames == 10 && !m_nominationClicked) {
        m_nominationClicked = true;
        ShotAction a;
        a.kind = ShotAction::Kind::Nominate;
        a.pocketIndex = m_cand.pocketIndex;
        return a;
    }
    if (m_nominationFrames > 20 && !m_busy) {
        ShotAction a;
        a.kind = ShotAction::Kind::Fire;
        a.angle = m_pendingAngle;
        a.power = m_pendingPower;
        a.pocketIndex = m_cand.pocketIndex;
        a.pieceIdx = m_cand.idx;
        if (m_cand.idx >= 0 && m_cand.idx < pred.scene.piecesCount)
            a.gamePieceId = pred.scene.pieces[m_cand.idx].gameId;
        Reset();
        return a;
    }
    return {};
}

} // namespace carrom
