#include "logic/MetadataFinder.h"

#include <cstdio>
#include <cstring>

#include "platform/Memory.h"

namespace carrom {

namespace {
constexpr size_t kBlock = 256 * 1024;
constexpr size_t kHeaderRead = 512;      // 8 + ~40 tables * 8 = ~330 bytes at most
constexpr size_t kMinSize = 1024;
constexpr size_t kMaxSize = size_t(1) << 30;

bool SkipRegion(const MemRegion& r, size_t maxBytes) {
    if (!r.r) return true;
    if (r.size() > maxBytes) return true;
    const std::string& p = r.path;
    if (p.rfind("/dev/", 0) == 0 || p.rfind("/dmabuf", 0) == 0 || p.rfind("[vvar", 0) == 0 ||
        p.rfind("[vsyscall", 0) == 0)
        return true;
    return false;
}
} // namespace

size_t MetadataFinder::ComputeSize(const il2cpp::MetadataResult& h) {
    if (!h.ok || h.tables.empty()) return 0;
    uint64_t best = 0;
    for (const auto& t : h.tables) {
        if (t.offset < 0 || t.count < 0) return 0; // a real header never has negative values
        const uint64_t end = (uint64_t)t.offset + (uint64_t)t.count;
        if (end > best) best = end;
    }
    if (best < kMinSize || best > kMaxSize) return 0;
    return (size_t)best;
}

std::vector<FoundMetadata> MetadataFinder::Scan(const std::vector<MemRegion>& regions, size_t maxResults,
                                                size_t maxRegionBytes, std::atomic<size_t>* progress,
                                                const std::atomic<bool>* cancel) {
    std::vector<FoundMetadata> found;
    std::vector<uint8_t> block(kBlock);
    uint8_t head[kHeaderRead];

    for (const MemRegion& reg : regions) {
        if (SkipRegion(reg, maxRegionBytes)) continue;
        for (uintptr_t off = 0; off < reg.size(); off += kBlock) {
            if (cancel && cancel->load()) return found;
            if (found.size() >= maxResults) return found;
            const size_t want = std::min(kBlock, reg.size() - (size_t)off);
            const uintptr_t base = reg.start + off;

            // A block with a hole fails as a whole; retry page by page so one bad page does not
            // hide the rest of the block.
            size_t valid = 0;
            if (mem::Read(base, block.data(), want)) {
                valid = want;
            } else {
                for (size_t p = 0; p < want; p += 4096) {
                    const size_t n = std::min<size_t>(4096, want - p);
                    if (mem::Read(base + p, block.data() + p, n)) {
                        valid = p + n;
                    } else {
                        std::memset(block.data() + p, 0, n);
                    }
                }
                if (valid == 0) { if (progress) progress->fetch_add(want); continue; }
            }
            if (progress) progress->fetch_add(want);

            for (size_t i = 0; i + 4 <= want; i += 4) {
                uint32_t v;
                std::memcpy(&v, block.data() + i, 4);
                if (v != il2cpp::kMetadataMagic) continue;

                const uintptr_t addr = base + i;
                size_t hn = kHeaderRead;
                if (!mem::Read(addr, head, hn)) {
                    hn = 64;
                    if (!mem::Read(addr, head, hn)) continue;
                }
                il2cpp::MetadataResult h = il2cpp::ParseMetadataHeader(head, hn);
                if (!h.ok) continue;
                const size_t size = ComputeSize(h);
                if (size == 0) continue;

                bool dup = false;
                for (const auto& f : found) if (f.address == addr) dup = true;
                if (dup) continue;
                FoundMetadata fm;
                fm.address = addr;
                fm.rawVersion = h.rawVersion;
                fm.version = h.resolvedVersion;
                fm.size = size;
                fm.region = reg.path;
                found.push_back(fm);
                if (found.size() >= maxResults) return found;
            }
        }
    }
    return found;
}

void MetadataFinder::Join() {
    if (m_thread.joinable()) m_thread.join();
}

MetadataFinder::~MetadataFinder() {
    m_cancel = true;
    Join();
}

void MetadataFinder::StartAsync(size_t maxResults) {
    if (m_running.load()) return;
    Join();
    m_cancel = false;
    m_progress = 0;
    { std::lock_guard<std::mutex> lk(m_mutex); m_results.clear(); }
    m_running = true;
    m_thread = std::thread([this, maxResults] {
        auto res = Scan(EnumerateRegions(), maxResults, size_t(1) << 30, &m_progress, &m_cancel);
        { std::lock_guard<std::mutex> lk(m_mutex); m_results = std::move(res); }
        m_running = false;
    });
}

void MetadataFinder::Cancel() { m_cancel = true; }

std::vector<FoundMetadata> MetadataFinder::Results() const {
    std::lock_guard<std::mutex> lk(m_mutex);
    return m_results;
}

bool MetadataFinder::Dump(const FoundMetadata& f, const std::string& path, std::string* error, std::string* note) {
    if (f.address == 0 || f.size == 0) { if (error) *error = "empty result"; return false; }
    size_t bad = 0;
    std::vector<uint8_t> data = mem::ReadRange(f.address, f.size, &bad);
    if (data.empty()) { if (error) *error = "range too large or empty"; return false; }
    std::FILE* out = std::fopen(path.c_str(), "wb");
    if (!out) { if (error) *error = "could not open output file: " + path; return false; }
    const size_t n = std::fwrite(data.data(), 1, data.size(), out);
    std::fclose(out);
    if (n != data.size()) { if (error) *error = "disk write failed (disk full?)"; return false; }
    if (note && bad) *note = std::to_string(bad) + " chunk(s) unreadable, zero-filled";
    return true;
}

} // namespace carrom
