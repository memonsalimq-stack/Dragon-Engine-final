// Shot prediction: rigid-body carrom simulation (pieces, cushions, pockets).
// Ported from the old project's game/inc/Prediction.h with the game-memory
// coupling removed: input is a FrameSnapshot, state lives in the instance.
#pragma once
#include <array>
#include <vector>

#include "logic/GameConstants.h"
#include "logic/Snapshot.h"
#include "math/Vec.h"

namespace carrom {

struct Candidate {
    int idx = -1;
    double angle = 0.0;
    double score = 0.0;
    int pocketIndex = -1;
    double power = 0.0;
    bool operator<(const Candidate& other) const { return score < other.score; }
};

const std::array<Point2D, BOARD_POCKETS_COUNT>& DefaultPockets();
const std::array<Point2D, BOARD_SHAPE_SIZE>& TableShape();

class Prediction {
public:
    struct SimPiece {
        int index = 0;
        int gameId = -1;                 // id of the piece on the game side (from the snapshot)
        PieceType classification = PieceType::Err;
        PieceState state = PieceState::Err;
        bool originalOnTable = false;
        bool onTable = false;
        int pocketIndex = -1;

        Point2D velocity;
        Vec3d spin;
        Point2D initialPosition;
        Point2D predictedPosition;
        std::vector<Point2D> positions;
        double radius = 0.0;

        double getRadius() const {
            return radius > 0.01 && radius < 10.0 ? radius : (index == 0 ? STRIKER_RADIUS : PIECE_RADIUS);
        }
        void move(double time) {
            predictedPosition.x += velocity.x * time;
            predictedPosition.y += velocity.y * time;
        }
        bool isMovingOrSpinning() const {
            return velocity.square() > 1e-8 || spin.square() > 1e-8;
        }

        void calcVelocity();
        void calcVelocityPostCollision(double angle);
        bool isPiecePieceCollision(double* smallestTime, SimPiece& other) const;
        bool isPiecePointCollision(double* smallestTime, const Point2D& point) const;
        bool isPieceLineCollision(double* smallestTime, const Point2D& a, const Point2D& b) const;
        bool willCollideWithBoard(const double* smallestTime) const;
        void determinePieceBoardCollision(Prediction& p, double* smallestTime);
        void findNextCollision(Prediction& p, double* time);
    };

    struct Collision {
        enum class Type { PIECE, LINE, POINT };
        bool valid = false;
        Type type = Type::POINT;
        double angle = 0.0;
        Point2D point{};
        SimPiece* pieceA = nullptr;
        SimPiece* pieceB = nullptr;
        SimPiece* firstHitPiece = nullptr;
    };

    struct Scene {
        int piecesCount = 0;
        SimPiece pieces[MAX_PIECES_COUNT];
        Collision collision{};
        bool shotState = false;
    } scene;

    std::array<bool, BOARD_POCKETS_COUNT> pocketStatus{};
    std::array<Point2D, BOARD_POCKETS_COUNT> pockets = DefaultPockets();
    Candidate candidate{};
    bool firstHitIsTarget = false;
    bool fastCalc = true;

    static constexpr double USE_CACHED_AIM = -999.0;

    // Simulates one shot. Returns false when nothing was (re)computed: either the
    // inputs equal the previous call, or the snapshot is unusable (piecesCount == 0).
    bool Run(const FrameSnapshot& snap, bool isAuto, double shotAngle = USE_CACHED_AIM,
             double shotPower = USE_CACHED_AIM, Vec2d shotSpin = {}, Candidate cand = {});

    void Invalidate() { m_hasPrev = false; scene.piecesCount = 0; }
    SimPiece* FindQueen();

    // internal, public for the SimPiece helpers
    void handleCollision();
    void handlePiecePieceCollision() const;

private:
    void initPieces(const FrameSnapshot& snap);
    void initStriker(const FrameSnapshot& snap, double shotAngle, double shotPower, const Vec2d& shotSpin);
    void determinePiecesPositions();
    void determineShotState();

    struct Key {
        uint64_t generation; double angle, power; Vec2d spin; bool isAuto; int candIdx;
    } m_prev{};
    bool m_hasPrev = false;
};

} // namespace carrom
