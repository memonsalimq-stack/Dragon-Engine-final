#include "logic/Prediction.h"

#include <algorithm>
#include <cmath>
#include <limits>

namespace carrom {

namespace {
// Matches the old NumberUtils::calcAngle / calcVectorAngle quirks exactly, including
// the double "+ PI" for x < 0 (so a negative-x vector lands in [2PI-ish) range).
double CalcVectorAngle(const Vec2d& v) {
    constexpr double PI_HALF = 1.57079632679;
    constexpr double PI_THREE_HALF = 4.71238898038;
    constexpr double PI_C = 3.14159265359;
    if (v.x == 0.0) return (v.y < 0.0) == (std::isnan(v.y)) ? PI_HALF : PI_THREE_HALF;
    double a = std::atan(v.y / v.x);
    if (v.x < 0.0) a += PI_C;
    if (v.x < 0.0) a += PI_C;
    return a;
}
} // namespace

const std::array<Point2D, BOARD_POCKETS_COUNT>& DefaultPockets() {
    static const std::array<Point2D, BOARD_POCKETS_COUNT> p = {
        Point2D(-34.5, -34.5), Point2D(34.5, -34.5), Point2D(34.5, 34.5), Point2D(-34.5, 34.5)};
    return p;
}

const std::array<Point2D, BOARD_SHAPE_SIZE>& TableShape() {
    static const std::array<Point2D, BOARD_SHAPE_SIZE> f = {
        Point2D(-34.0, -32.0), Point2D(-34.0, 32.0), Point2D(-32.0, 34.0), Point2D(32.0, 34.0),
        Point2D(34.0, 32.0),   Point2D(34.0, -32.0), Point2D(32.0, -34.0), Point2D(-32.0, -34.0),
        Point2D(-34.5, -34.0), Point2D(-34.0, -34.5), Point2D(34.0, -34.5), Point2D(34.5, -34.0),
        Point2D(34.5, 34.0),   Point2D(34.0, 34.5),   Point2D(-34.0, 34.5), Point2D(-34.5, 34.0),
        Point2D(-35.0, -33.5), Point2D(-33.5, -35.0), Point2D(33.5, -35.0), Point2D(35.0, -33.5),
        Point2D(35.0, 33.5),   Point2D(33.5, 35.0),   Point2D(-33.5, 35.0), Point2D(-35.0, 33.5),
        Point2D(-36.0, -36.0), Point2D(36.0, -36.0),  Point2D(36.0, 36.0),  Point2D(-36.0, 36.0),
        Point2D(-37.0, -37.0), Point2D(37.0, -37.0),  Point2D(37.0, 37.0),  Point2D(-37.0, 37.0)};
    return f;
}

Prediction::SimPiece* Prediction::FindQueen() {
    for (int i = 0; i < scene.piecesCount; ++i)
        if (scene.pieces[i].classification == PieceType::Queen) return &scene.pieces[i];
    return nullptr;
}

bool Prediction::Run(const FrameSnapshot& snap, bool isAuto, double shotAngle, double shotPower,
                     Vec2d shotSpin, Candidate cand) {
    if (!snap.valid) { scene.piecesCount = 0; return false; }
    if (shotAngle == USE_CACHED_AIM) shotAngle = snap.aimAngle;
    if (shotPower == USE_CACHED_AIM) shotPower = snap.aimPower;
    if (!std::isfinite(shotAngle) || !std::isfinite(shotPower)) return false;

    const Key key{snap.generation, shotAngle, shotPower, shotSpin, isAuto, cand.idx};
    if (m_hasPrev && key.generation == m_prev.generation && key.angle == m_prev.angle &&
        key.power == m_prev.power && key.spin == m_prev.spin && key.isAuto == m_prev.isAuto &&
        key.candIdx == m_prev.candIdx && scene.piecesCount > 0)
        return false;

    fastCalc = isAuto;
    candidate = cand;
    firstHitIsTarget = false;
    pockets = snap.pockets;

    initPieces(snap);
    if (scene.piecesCount <= 0) { m_hasPrev = false; return false; }
    m_prev = key;
    m_hasPrev = true;

    initStriker(snap, shotAngle, shotPower, shotSpin);
    scene.collision = Collision{};
    pocketStatus.fill(false);

    determinePiecesPositions();

    for (int i = 0; i < scene.piecesCount; ++i) {
        auto& p = scene.pieces[i];
        if (p.positions.empty() || p.positions.back() != p.predictedPosition)
            p.positions.push_back(p.predictedPosition);
    }
    determineShotState();
    return true;
}

void Prediction::initPieces(const FrameSnapshot& snap) {
    scene.piecesCount = 0;
    int strikerSrc = -1;
    for (size_t i = 0; i < snap.pieces.size(); ++i)
        if (snap.pieces[i].type == PieceType::Striker) { strikerSrc = (int)i; break; }
    if (strikerSrc < 0) return;

    int out = 0;
    auto add = [&](const SnapshotPiece& src) {
        if (out >= MAX_PIECES_COUNT || !IsFinite(src.pos)) return;
        SimPiece& p = scene.pieces[out];
        p = SimPiece{};
        p.index = out;
        p.gameId = src.id;
        p.state = PieceState::Default;
        p.classification = src.type;
        p.originalOnTable = true;
        p.onTable = true;
        p.radius = src.radius;
        p.initialPosition = src.pos;
        p.predictedPosition = src.pos;
        p.positions.reserve(32);
        p.positions.push_back(src.pos);
        ++out;
    };

    add(snap.pieces[strikerSrc]);
    if (out != 1) return;
    for (size_t i = 0; i < snap.pieces.size(); ++i) {
        if ((int)i == strikerSrc) continue;
        const auto& s = snap.pieces[i];
        if (s.state != PieceState::Default && s.state != PieceState::InPocket) continue;
        add(s);
    }
    scene.piecesCount = out < 2 ? 0 : out;
}

void Prediction::initStriker(const FrameSnapshot& snap, double shotAngle, double shotPower,
                             const Vec2d& shotSpin) {
    if (scene.piecesCount <= 0) return;
    if (shotPower < 0.24) shotPower = 0.24;
    if (shotPower > 1.0) shotPower = 1.0;

    const double c = std::cos(shotAngle);
    const double s = std::sin(shotAngle);
    SimPiece& striker = scene.pieces[0];

    const double maxPower = (std::isfinite(snap.maxPower) && snap.maxPower > 1.0 && snap.maxPower < 10000.0)
                                ? snap.maxPower : 120.0;
    const double speed = shotPower * maxPower;
    striker.velocity.x = speed * c;
    striker.velocity.y = speed * s;

    const double spinFactor = speed / STRIKER_RADIUS;
    const double v = -shotSpin.y * spinFactor;
    striker.spin.x = -(s * v);
    striker.spin.y = c * v;
    striker.spin.z = shotSpin.x * spinFactor;
}

void Prediction::determinePiecesPositions() {
    constexpr int MAX_PHYSICS_STEPS = 200000;
    int physicsSteps = 0;
    bool anyMoving = false;

    do {
        if (++physicsSteps > MAX_PHYSICS_STEPS) {
            for (int i = 0; i < scene.piecesCount; ++i) {
                scene.pieces[i].velocity.nullify();
                scene.pieces[i].spin.nullify();
            }
            break;
        }

        double remaining = TIME_PER_TICK;
        do {
            double step = remaining;
            scene.collision = Collision{};

            for (int i = 0; i < scene.piecesCount; ++i)
                if (scene.pieces[i].onTable && scene.pieces[i].isMovingOrSpinning())
                    scene.pieces[i].findNextCollision(*this, &step);

            if (step < 0.0 || !std::isfinite(step)) step = 0.0;
            if (step > remaining) step = remaining;

            for (int i = 0; i < scene.piecesCount; ++i)
                if (scene.pieces[i].onTable && scene.pieces[i].isMovingOrSpinning())
                    scene.pieces[i].move(step);

            if (scene.collision.valid) {
                handleCollision();
                if (scene.collision.firstHitPiece && candidate.idx >= 0 && candidate.idx < scene.piecesCount) {
                    firstHitIsTarget = scene.collision.firstHitPiece->index == candidate.idx;
                    if (!firstHitIsTarget) return;
                }
            }

            if (step <= MIN_TIME) {
                if (scene.collision.valid && scene.collision.pieceA) scene.collision.pieceA->move(MIN_TIME);
                step = MIN_TIME;
            }
            remaining -= step;
        } while (remaining > MIN_TIME && physicsSteps < MAX_PHYSICS_STEPS);

        anyMoving = false;
        for (int i = 0; i < scene.piecesCount; ++i) {
            if (!scene.pieces[i].onTable) continue;
            scene.pieces[i].calcVelocity();
            if (scene.pieces[i].isMovingOrSpinning()) anyMoving = true;
        }
    } while (anyMoving && physicsSteps < MAX_PHYSICS_STEPS);
}

void Prediction::handleCollision() {
    if (!scene.collision.valid || !scene.collision.pieceA) return;
    SimPiece& a = *scene.collision.pieceA;
    if (!fastCalc) a.positions.push_back(a.predictedPosition);

    if (scene.collision.type == Collision::Type::PIECE) {
        if (!scene.collision.pieceB) return;
        handlePiecePieceCollision();
        if (!fastCalc) scene.collision.pieceB->positions.push_back(scene.collision.pieceB->predictedPosition);
        if (!scene.collision.firstHitPiece) scene.collision.firstHitPiece = scene.collision.pieceB;
    } else if (scene.collision.type == Collision::Type::LINE) {
        a.calcVelocityPostCollision(scene.collision.angle);
    } else {
        Point2D delta = {scene.collision.point.y - a.predictedPosition.y,
                         -(scene.collision.point.x - a.predictedPosition.x)};
        scene.collision.angle = -CalcVectorAngle(delta);
        a.calcVelocityPostCollision(scene.collision.angle);
    }
}

void Prediction::handlePiecePieceCollision() const {
    if (!scene.collision.pieceA || !scene.collision.pieceB) return;
    SimPiece& a = *scene.collision.pieceA;
    SimPiece& b = *scene.collision.pieceB;
    Point2D rel = a.predictedPosition - b.predictedPosition;
    const double distSq = rel.square();
    if (distSq < 1e-12) return;

    const double invDist = 1.0 / std::sqrt(distSq);
    Point2D normal = rel * invDist;
    const double vaN = a.velocity.x * normal.x + a.velocity.y * normal.y;
    const double vbN = b.velocity.x * normal.x + b.velocity.y * normal.y;
    Point2D va = normal * vaN;
    Point2D vb = normal * vbN;

    a.velocity.x = vb.x - (va.x - a.velocity.x);
    a.velocity.y = vb.y - (va.y - a.velocity.y);
    b.velocity.x = va.x - (vb.x - b.velocity.x);
    b.velocity.y = va.y - (vb.y - b.velocity.y);

    const double rSum = a.getRadius() + b.getRadius();
    const double dist = 1.0 / invDist;
    const double overlap = rSum - dist;
    if (overlap > 0.0) {
        const double push = overlap * 0.5 + 1e-6;
        a.predictedPosition.x += normal.x * push;
        a.predictedPosition.y += normal.y * push;
        b.predictedPosition.x -= normal.x * push;
        b.predictedPosition.y -= normal.y * push;
    }
}

void Prediction::SimPiece::calcVelocity() {
    if (!isMovingOrSpinning()) return;
    const double r = getRadius();
    const double relativeY = r * spin.x - velocity.y;
    const double relativeX = -velocity.x - spin.y * r;
    const double slidingSpeed = std::sqrt(relativeX * relativeX + relativeY * relativeY);
    const double equilibriumTime = slidingSpeed * 0.0008789064581287676;

    if (slidingSpeed > 1e-9 && equilibriumTime > 1e-5) {
        const double dt = std::min(equilibriumTime, TIME_PER_TICK);
        const double factor = 196.0 * dt / slidingSpeed;
        const double dvx = relativeX * factor;
        const double dvy = relativeY * factor;
        velocity.x += dvx;
        velocity.y += dvy;
        spin.x -= dvy * (2.5 / r);
        spin.y += dvx * (2.5 / r);
    }

    if (equilibriumTime < TIME_PER_TICK) {
        const double speed = std::sqrt(velocity.square());
        if (speed > 1e-9) {
            double scale = 1.0 - ((TIME_PER_TICK - equilibriumTime) * 11.0 / speed);
            scale = std::clamp(scale, 0.0, 1.0);
            velocity.x *= scale;
            velocity.y *= scale;
            spin.x = velocity.y / r;
            spin.y = -velocity.x / r;
        }
    }

    const double decay = 0.05 * TIME_PER_TICK;
    spin.z = spin.z > 0.0 ? std::max(0.0, spin.z - decay) : std::min(0.0, spin.z + decay);
}

void Prediction::SimPiece::calcVelocityPostCollision(double angle) {
    constexpr double CUSHION_RESTITUTION = 0.76;
    const double c = std::cos(angle);
    const double s = std::sin(angle);
    const double r = getRadius();

    const double vx = c * velocity.x - s * velocity.y;
    const double vy = s * velocity.x + c * velocity.y;
    const double spinFactor = vx - r * spin.z;
    const double absSpinFactor = std::abs(spinFactor);
    const double velocityFactor = absSpinFactor / 2.5;
    const double minSpinFactor = std::min(0.4 * std::abs(vy), velocityFactor);
    const double spinChange = (spinFactor >= 0.0 ? 1.0 : -1.0) * minSpinFactor;

    const double newVx = vx - spinChange / 2.5;
    const double newVy = -CUSHION_RESTITUTION * vy;
    velocity.x = s * newVy + c * newVx;
    velocity.y = c * newVy - s * newVx;

    const double newSpinX = s * spin.x + c * spin.y;
    const double newSpinY = c * spin.x - s * spin.y - spinChange / r;
    spin.x = s * newSpinX + c * newSpinY;
    spin.y = c * newSpinX - s * newSpinY;
    spin.z -= spinChange / r;
}

bool Prediction::SimPiece::isPiecePieceCollision(double* smallestTime, SimPiece& other) const {
    if (!smallestTime || !onTable || !other.onTable) return false;
    const double r = getRadius() + other.getRadius();
    const double dx = other.predictedPosition.x - predictedPosition.x;
    const double dy = other.predictedPosition.y - predictedPosition.y;
    const double dvx = other.velocity.x - velocity.x;
    const double dvy = other.velocity.y - velocity.y;
    const double a = dvx * dvx + dvy * dvy;
    const double b = 2.0 * (dx * dvx + dy * dvy);
    const double c = dx * dx + dy * dy - r * r;
    if (a < 1e-12) return false;
    if (b >= 0.0) return false;
    const double disc = b * b - 4.0 * a * c;
    if (disc < 0.0) return false;

    const double root = std::sqrt(disc);
    const double t1 = (-b - root) / (2.0 * a);
    const double t2 = (-b + root) / (2.0 * a);
    double t = std::numeric_limits<double>::max();
    if (t1 >= 0.0) t = t1;
    if (t2 >= 0.0) t = std::min(t, t2);
    if (!std::isfinite(t) || t >= *smallestTime) return false;
    *smallestTime = t;
    return true;
}

bool Prediction::SimPiece::isPiecePointCollision(double* smallestTime, const Point2D& point) const {
    if (!smallestTime) return false;
    const double vx = velocity.x, vy = velocity.y;
    const double speedSq = vx * vx + vy * vy;
    if (speedSq < 1e-12) return false;

    const double dx = point.x - predictedPosition.x;
    const double dy = point.y - predictedPosition.y;
    const double b = -2.0 * (vx * dx + vy * dy);
    const double c = dx * dx + dy * dy - getRadius() * getRadius();
    const double disc = b * b - 4.0 * speedSq * c;
    if (disc < 0.0) return false;

    const double t = (-b - std::sqrt(disc)) / (2.0 * speedSq);
    if (t < 0.0 || t >= *smallestTime) return false;
    *smallestTime = std::max(0.0, t - 1e-11);
    return true;
}

bool Prediction::SimPiece::isPieceLineCollision(double* smallestTime, const Point2D& a, const Point2D& b) const {
    if (!smallestTime || velocity.square() < 1e-12) return false;
    const double dx = b.x - a.x;
    const double dy = b.y - a.y;
    const double len = std::sqrt(dx * dx + dy * dy);
    if (len < 1e-12) return false;

    const double nx = dy / len;
    const double ny = -dx / len;
    const double relX = predictedPosition.x - a.x;
    const double relY = predictedPosition.y - a.y;
    const double signedDist = relX * nx + relY * ny;
    const double normalVel = velocity.x * nx + velocity.y * ny;
    if (normalVel >= -1e-12) return false;

    const double t = (getRadius() - signedDist) / normalVel;
    if (t <= 0.0 || t >= *smallestTime) return false;

    const double hitX = predictedPosition.x + velocity.x * t - nx * getRadius();
    const double hitY = predictedPosition.y + velocity.y * t - ny * getRadius();
    const double along = ((hitX - a.x) * dx + (hitY - a.y) * dy) / (len * len);
    if (along < 0.0 || along > 1.0) return false;

    *smallestTime = std::max(0.0, t - 1e-11);
    return true;
}

bool Prediction::SimPiece::willCollideWithBoard(const double* smallestTime) const {
    if (!smallestTime) return false;
    const auto& frame = TableShape();
    for (size_t i = 0; i < frame.size(); ++i) {
        const Point2D& a = frame[i];
        const Point2D& b = frame[(i + 1) % frame.size()];
        double lineTime = *smallestTime;
        if (isPieceLineCollision(&lineTime, a, b)) return true;
        double pointTime = *smallestTime;
        if (isPiecePointCollision(&pointTime, a)) return true;
    }
    return false;
}

void Prediction::SimPiece::determinePieceBoardCollision(Prediction& p, double* smallestTime) {
    if (!smallestTime) return;
    const auto& frame = TableShape();
    double best = *smallestTime;
    int kind = -1;
    Point2D point{};
    double angle = 0.0;

    for (size_t i = 0; i < frame.size(); ++i) {
        const Point2D& a = frame[i];
        const Point2D& b = frame[(i + 1) % frame.size()];
        double lt = best;
        if (isPieceLineCollision(&lt, a, b)) {
            best = lt;
            kind = 0;
            angle = CalcVectorAngle({b.x - a.x, b.y - a.y});
        }
        double pt = best;
        if (isPiecePointCollision(&pt, a)) {
            best = pt;
            kind = 1;
            point = a;
        }
    }
    if (kind == -1) return;
    *smallestTime = best;
    p.scene.collision.valid = true;
    p.scene.collision.pieceA = this;
    p.scene.collision.pieceB = nullptr;
    if (kind == 0) {
        p.scene.collision.type = Collision::Type::LINE;
        p.scene.collision.angle = angle;
    } else {
        p.scene.collision.type = Collision::Type::POINT;
        p.scene.collision.point = point;
    }
}

void Prediction::SimPiece::findNextCollision(Prediction& p, double* time) {
    if (!time || *time < 0.0 || !onTable) return;
    auto& sc = p.scene;

    if (state == PieceState::Default || state == PieceState::InPocket) {
        for (int i = index + 1; i < sc.piecesCount; ++i) {
            SimPiece& other = sc.pieces[i];
            if (!other.onTable) continue;
            if (other.state == PieceState::Default || other.state == PieceState::InPocket) {
                if (isPiecePieceCollision(time, other)) {
                    sc.collision.valid = true;
                    sc.collision.pieceA = this;
                    sc.collision.pieceB = &other;
                    sc.collision.type = Collision::Type::PIECE;
                }
            }
        }
    }

    if (!willCollideWithBoard(time)) return;

    bool inPocketZone = false;
    for (int pi = 0; pi < BOARD_POCKETS_COUNT; ++pi) {
        Point2D pd = p.pockets[pi] - predictedPosition;
        if (pd.square() < POCKET_RADIUS_SQUARE) { inPocketZone = true; break; }
    }
    if (state == PieceState::Default || state == PieceState::InPocket) {
        for (int i = 0; i < BOARD_POCKETS_COUNT; ++i) {
            Point2D d = p.pockets[i] - predictedPosition;
            const double dsq = d.square();
            if (dsq < POCKET_RADIUS_SQUARE) {
                const double pull = *time * 120.0;
                velocity.x += d.x * pull;
                velocity.y += d.y * pull;

                if (dsq < 4.95) {
                    state = PieceState::InPocket;
                    pocketIndex = i;
                    p.pocketStatus[i] = true;
                    onTable = false;
                    velocity.nullify();
                    spin.nullify();
                    return;
                }
            }
        }
    }

    if (!inPocketZone) determinePieceBoardCollision(p, time);
}

void Prediction::determineShotState() {
    scene.shotState = false;
    if (!scene.collision.firstHitPiece || scene.piecesCount <= 0 || !scene.pieces[0].onTable) return;
    for (int i = 1; i < scene.piecesCount; ++i) {
        if (scene.pieces[i].originalOnTable != scene.pieces[i].onTable) {
            scene.shotState = true;
            return;
        }
    }
}

} // namespace carrom
