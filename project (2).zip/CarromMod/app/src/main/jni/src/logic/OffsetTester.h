// Live memory inspector for finding/validating offsets on the real game build. This is the tool
// the user asked for: "offset tester jo game ke offset latest test ya dump kr sake". It reads
// relative to the game module's base (an RVA), optionally chases a chain of pointer+offset hops,
// and formats the result in every interpretation that is useful while reverse engineering
// (int32/int64, float/double, pointer, ASCII preview, raw hex).
#pragma once
#include <cstdint>
#include <string>
#include <vector>

#include "platform/Module.h"

namespace carrom {

struct TestResult {
    bool ok = false;
    std::string error;
    uintptr_t finalAddress = 0;     // absolute address the value was read from
    uint8_t bytes[32] = {};         // raw bytes actually read (up to 32)
    int bytesRead = 0;
    int32_t asInt32 = 0;
    int64_t asInt64 = 0;
    float asFloat = 0.f;
    double asDouble = 0.0;
    uintptr_t asPointer = 0;
    bool pointerPlausible = false;  // asPointer looks like it could itself be dereferenced
    std::string asAscii;            // printable bytes only, '.' for the rest
    std::string hexLine;            // "AA BB CC ..." of the bytes actually read
};

struct SavedOffset {
    std::string label;
    std::string chain;    // e.g. "0x10,0x8,0x50" as the user typed it
    std::string kind;      // "int32" "int64" "float" "double" "pointer" "bytes"
};

class OffsetTester {
public:
    void SetModule(const ModuleInfo& m) { m_module = m; }
    const ModuleInfo& module() const { return m_module; }

    // `chain`: "0x10" reads module.base+0x10. "0x10,0x8,0x50" dereferences module.base+0x10 as a
    // pointer, then that pointer+0x8 as a pointer, then reads 32 bytes at the result+0x50. Decimal
    // ("16") and hex ("0x10") are both accepted per hop. Nothing is read if the chain is empty,
    // malformed, or any hop lands outside a plausible user-space pointer.
    TestResult Read(const std::string& chain) const;

    // Same as Read(), but reads `count` pointer-sized slots starting at the final address and
    // returns one TestResult per slot (array / vtable inspection). count is capped at 64.
    std::vector<TestResult> ReadArray(const std::string& chain, int count) const;

    void Save(const std::string& label, const std::string& chain, const std::string& kind);
    void RemoveSaved(size_t index);
    const std::vector<SavedOffset>& saved() const { return m_saved; }

    // Re-reads every saved offset right now; parallel to saved() by index.
    std::vector<TestResult> ReadAllSaved() const;

    // Renders the saved list as offsets.cfg-style "key=value" lines using `kind` to pick the
    // right field, so a finding can be pasted straight into carrom_offsets.cfg.
    std::string ExportSavedAsConfig() const;

    bool LoadSavedFromFile(const std::string& path);
    bool SaveSavedToFile(const std::string& path) const;

private:
    ModuleInfo m_module;
    std::vector<SavedOffset> m_saved;
};

// Parses one chain string into its hop values. Returns false on any malformed hop.
bool ParseChain(const std::string& chain, std::vector<int64_t>* hops);

} // namespace carrom
