// Full port of Universal Dumper's MetadataHeader.java (read via its decompiled smali, saved at
// reference/universal_dumper_il2cpp_smali/MetadataHeader.smali in this project) — NOT a
// reimplementation from memory. Every version number, table name and comparison below was read
// directly out of that file's bytecode line by line; see logic/Il2CppMetadata.cpp's comments for
// which smali line each piece came from.
//
// This parses the plain, deterministic part of a Unity IL2CPP global-metadata.dat: the magic,
// the version, and the table-of-contents (name -> {offset, count} for every table Unity has ever
// put in this header, gated by version). It does NOT read string/type/method names or signatures
// (Universal Dumper's Il2CppBinary/TypeResolver/DumpWriter) — that is a separate, much larger
// port, not attempted here.
#pragma once
#include <cstdint>
#include <string>
#include <vector>

namespace carrom::il2cpp {

inline constexpr uint32_t kMetadataMagic = 0xFAB11BAFu;

struct MetadataTable {
    std::string name;
    int32_t offset = 0;
    int32_t count = 0;
};

struct MetadataResult {
    bool ok = false;
    std::string error;
    uint32_t magic = 0;
    int32_t rawVersion = 0;       // the int32 Unity actually wrote (e.g. 24, 27, 29)
    double resolvedVersion = 0.0; // the specific sub-version whose layout matched (e.g. 24.1)
    std::vector<MetadataTable> tables; // in file order, same order read() produced it in
    std::vector<double> candidatesTried;
};

// Parses a buffer already read into memory (e.g. the full global-metadata.dat, or at least its
// header region — needs 8 + layout_size*8 bytes, which is at most a few hundred).
MetadataResult ParseMetadataHeader(const uint8_t* data, size_t len);
MetadataResult ParseMetadataHeaderFromFile(const std::string& path);

// Exposed for testing against the ported logic directly:
std::vector<double> CandidatesFor(int32_t rawVersion);
std::vector<std::string> LayoutFor(double version);

} // namespace carrom::il2cpp
