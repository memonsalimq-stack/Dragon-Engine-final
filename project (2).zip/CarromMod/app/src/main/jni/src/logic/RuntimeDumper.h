// Runtime (self-process) dumper: pick any loaded library — auto-detected or typed by hand —
// and dump its mapped bytes to a file, without needing to know its exact name in advance.
// Also reads a Unity IL2CPP global-metadata.dat's full table-of-contents (magic, version, and
// every table's offset/count) via logic/Il2CppMetadata.h, a faithful port of Universal
// Dumper's MetadataHeader.java.
//
// What this does NOT do (yet): resolve those tables into actual type/method names and
// signatures (Universal Dumper's Il2CppBinary/TypeResolver/DumpWriter — the part that produces
// a complete dump.cs with every class, field and method). That is a large, separate port from
// the uploaded smali and is tracked as a next step in HANDOFF.md, not attempted here.
#pragma once
#include <cstdint>
#include <string>
#include <vector>

#include "logic/Il2CppMetadata.h"
#include "platform/ModuleEnum.h"

namespace carrom {

struct DumpResult {
    bool ok = false;
    std::string error;
    std::string outputPath;
    uintptr_t base = 0, end = 0;
    size_t bytesWritten = 0;
    size_t pagesSkipped = 0;   // unreadable pages inside the range (holes, guard pages): logged, not fatal
};

class RuntimeDumper {
public:
    // Dumps [mod.base, mod.end) by reading PAGE_SIZE-sized chunks through the safe memory
    // reader; a chunk that cannot be read (unmapped hole, guard page) is written as zeros and
    // counted in pagesSkipped rather than aborting the whole dump.
    DumpResult DumpModule(const MappedModule& mod, const std::string& outputPath) const;

    // Same, for any address range the user types in (e.g. a heap or anonymous region).
    DumpResult DumpRange(uintptr_t start, uintptr_t end, const std::string& outputPath) const;

    // Full table-of-contents read of a global-metadata.dat; see logic/Il2CppMetadata.h.
    static il2cpp::MetadataResult ReadMetadataHeaderFromFile(const std::string& path) {
        return il2cpp::ParseMetadataHeaderFromFile(path);
    }
};

} // namespace carrom
