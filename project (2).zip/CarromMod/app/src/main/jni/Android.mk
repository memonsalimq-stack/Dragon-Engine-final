LOCAL_PATH := $(call my-dir)

# --- Dobby (inline hooking) ------------------------------------------------
include $(CLEAR_VARS)
LOCAL_MODULE := dobby
DOBBY_DIR := $(LOCAL_PATH)/third_party/Dobby
LOCAL_SRC_FILES := \
  $(DOBBY_DIR)/source/dobby.cpp \
  $(DOBBY_DIR)/source/Backend/UserMode/ExecMemory/clear-cache-tool-all.c \
  $(DOBBY_DIR)/source/Backend/UserMode/ExecMemory/code-patch-tool-posix.cc \
  $(DOBBY_DIR)/source/Backend/UserMode/MultiThreadSupport/ThreadSupport.cpp \
  $(DOBBY_DIR)/source/Backend/UserMode/PlatformUtil/Linux/ProcessRuntime.cc \
  $(DOBBY_DIR)/source/Backend/UserMode/Thread/PlatformThread.cc \
  $(DOBBY_DIR)/source/Backend/UserMode/Thread/platform-thread-posix.cc \
  $(DOBBY_DIR)/source/Backend/UserMode/UnifiedInterface/platform-posix.cc \
  $(DOBBY_DIR)/source/Backend/UserMode/UnifiedInterface/semaphore.cc \
  $(DOBBY_DIR)/source/InstructionRelocation/arm64/InstructionRelocationARM64.cc \
  $(DOBBY_DIR)/source/InterceptRouting/InstrumentRouting/instrument_routing_handler.cpp \
  $(DOBBY_DIR)/source/InterceptRouting/NearBranchTrampoline/near_trampoline_arm64.cc \
  $(DOBBY_DIR)/source/TrampolineBridge/ClosureTrampolineBridge/arm64/ClosureTrampolineARM64.cc \
  $(DOBBY_DIR)/source/TrampolineBridge/ClosureTrampolineBridge/arm64/closure_bridge_arm64.cc \
  $(DOBBY_DIR)/source/TrampolineBridge/ClosureTrampolineBridge/arm64/helper_arm64.cc \
  $(DOBBY_DIR)/source/TrampolineBridge/Trampoline/trampoline_arm64.cc \
  $(DOBBY_DIR)/source/core/codegen/codegen-arm.cc \
  $(DOBBY_DIR)/source/core/emulator/dummy.cc \
  $(DOBBY_DIR)/builtin-plugin/SymbolResolver/elf/dobby_symbol_resolver.cc \
  $(DOBBY_DIR)/external/logging/logging.cc
LOCAL_EXPORT_C_INCLUDES := $(DOBBY_DIR)/include
LOCAL_C_INCLUDES := $(DOBBY_DIR)/include $(DOBBY_DIR)/source $(DOBBY_DIR)/source/dobby \
  $(DOBBY_DIR)/external/logging $(DOBBY_DIR)/external/osbase \
  $(DOBBY_DIR)/source/Backend/UserMode $(DOBBY_DIR)/builtin-plugin $(DOBBY_DIR) \
  $(DOBBY_DIR)/external $(DOBBY_DIR)/source/InterceptRouting $(DOBBY_DIR)/source/MemoryAllocator
LOCAL_CFLAGS := -O2 -fvisibility=hidden -fno-rtti -fno-exceptions -DNDEBUG
LOCAL_CPPFLAGS := -O2 -fno-rtti -fno-exceptions -std=c++17
include $(BUILD_STATIC_LIBRARY)

# --- Dear ImGui -------------------------------------------------------------
include $(CLEAR_VARS)
LOCAL_MODULE := imgui
IMGUI_DIR := $(LOCAL_PATH)/third_party/imgui
LOCAL_SRC_FILES := \
  $(IMGUI_DIR)/imgui.cpp \
  $(IMGUI_DIR)/imgui_draw.cpp \
  $(IMGUI_DIR)/imgui_tables.cpp \
  $(IMGUI_DIR)/imgui_widgets.cpp \
  $(IMGUI_DIR)/backends/imgui_impl_opengl3.cpp
LOCAL_EXPORT_C_INCLUDES := $(IMGUI_DIR) $(IMGUI_DIR)/backends
LOCAL_C_INCLUDES := $(IMGUI_DIR) $(IMGUI_DIR)/backends
LOCAL_CPPFLAGS := -O2 -std=c++20 -DIMGUI_IMPL_OPENGL_ES3
include $(BUILD_STATIC_LIBRARY)

# --- CarromMod ---------------------------------------------------------------
include $(CLEAR_VARS)
LOCAL_MODULE := CarromMod
SRC_DIR := $(LOCAL_PATH)/src
LOCAL_SRC_FILES := \
  $(SRC_DIR)/main.cpp \
  $(SRC_DIR)/app/App.cpp \
  $(SRC_DIR)/config/Offsets.cpp \
  $(SRC_DIR)/config/Settings.cpp \
  $(SRC_DIR)/game/GameBridge.cpp \
  $(SRC_DIR)/game/ShotExecutor.cpp \
  $(SRC_DIR)/logic/AutoPlayer.cpp \
  $(SRC_DIR)/logic/MetadataFinder.cpp \
  $(SRC_DIR)/logic/OffsetTester.cpp \
  $(SRC_DIR)/logic/PatternScanner.cpp \
  $(SRC_DIR)/logic/Il2CppMetadata.cpp \
  $(SRC_DIR)/logic/Prediction.cpp \
  $(SRC_DIR)/logic/RuntimeDumper.cpp \
  $(SRC_DIR)/logic/ScreenMap.cpp \
  $(SRC_DIR)/logic/StringScanner.cpp \
  $(SRC_DIR)/platform/GlOverlay.cpp \
  $(SRC_DIR)/platform/Hooks.cpp \
  $(SRC_DIR)/platform/Jni.cpp \
  $(SRC_DIR)/platform/JniTouchSink.cpp \
  $(SRC_DIR)/platform/Memory.cpp \
  $(SRC_DIR)/platform/MemoryRegions.cpp \
  $(SRC_DIR)/platform/Module.cpp \
  $(SRC_DIR)/platform/ModuleEnum.cpp \
  $(SRC_DIR)/ui/PredictionDraw.cpp \
  $(SRC_DIR)/ui/Ui.cpp
LOCAL_C_INCLUDES := $(SRC_DIR) $(LOCAL_PATH)/third_party/stb
LOCAL_CPPFLAGS := -std=c++20 -Wall -Wextra
LOCAL_STATIC_LIBRARIES := dobby imgui
LOCAL_LDLIBS := -landroid -llog -lEGL -lGLESv3 -ldl
include $(BUILD_SHARED_LIBRARY)
