// Mod loader. Same entry shape as the Easy Victory loader found in the reference APK:
// CarromActivity.onCreate calls MainActivity.Start(Context) once, right after
// super.onCreate(...). Start() loads the native library and then wires touch events from the
// game window into the native menu, so the game itself needs exactly ONE patched line.
package com.carrommod.loader;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.MotionEvent;
import android.view.Window;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

public final class MainActivity {
    private static final String TAG = "CarromMod";
    private static volatile boolean started = false;

    private MainActivity() {}

    // Implemented in jni/src/main.cpp. Returns true when the touch belongs to the menu and must
    // not reach the game. action is MotionEvent.getActionMasked() (0 down, 1 up, 2 move, 3 cancel).
    private static native boolean nativeTouch(int action, float x, float y);

    // Call once from CarromActivity.onCreate (see hook.txt). Never throws: a failed load must not
    // crash the game.
    public static void Start(Context context) {
        if (started) return;
        started = true;
        try {
            // Matches Android.mk: LOCAL_MODULE := CarromMod -> libCarromMod.so
            System.loadLibrary("CarromMod");
            Log.i(TAG, "libCarromMod loaded");
        } catch (Throwable t) {
            Log.e(TAG, "failed to load libCarromMod", t);
            return;
        }
        try {
            if (context instanceof Activity) {
                installTouchForwarding((Activity) context);
            } else {
                Log.w(TAG, "context is not an Activity: touches will not reach the menu");
            }
        } catch (Throwable t) {
            Log.e(TAG, "touch forwarding not installed", t);
        }
    }

    // Wraps the window's callback (the Activity itself) with a proxy that offers every touch to
    // the native menu first. Everything else is passed through untouched.
    private static void installTouchForwarding(Activity activity) {
        final Window window = activity.getWindow();
        final Window.Callback original = window.getCallback();
        if (original == null) {
            Log.w(TAG, "window has no callback: touches will not reach the menu");
            return;
        }
        final Window.Callback proxy = (Window.Callback) Proxy.newProxyInstance(
                Window.Callback.class.getClassLoader(),
                new Class<?>[] { Window.Callback.class },
                new TouchHandler(original));
        window.setCallback(proxy);
        Log.i(TAG, "touch forwarding installed");
    }

    private static final class TouchHandler implements InvocationHandler {
        private final Window.Callback target;

        TouchHandler(Window.Callback target) {
            this.target = target;
        }

        @Override
        public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
            if (args != null && args.length == 1 && args[0] instanceof MotionEvent
                    && "dispatchTouchEvent".equals(method.getName())) {
                final MotionEvent e = (MotionEvent) args[0];
                final int action = e.getActionMasked();
                // Only the primary pointer's down/up/move/cancel (0..3). Secondary-pointer actions
                // (5, 6) are never claimed, so multi-touch in the game keeps working.
                if (action >= 0 && action <= 3) {
                    boolean consumed = false;
                    try {
                        consumed = nativeTouch(action, e.getX(), e.getY());
                    } catch (Throwable ignored) {
                        // native side not ready: treat as not consumed
                    }
                    if (consumed) return Boolean.TRUE;
                }
            }
            try {
                return method.invoke(target, args);
            } catch (InvocationTargetException ex) {
                throw ex.getCause() != null ? ex.getCause() : ex;
            }
        }
    }
}
