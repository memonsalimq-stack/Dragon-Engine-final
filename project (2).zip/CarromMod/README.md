# CarromMod

A single Android Studio project. Open the `CarromMod/` folder directly in Android Studio (or
run `./gradlew :app:assembleDebug` from a shell with the Android SDK/NDK on PATH) — it is one
Gradle module, `app`, that builds `libCarromMod.so` (native hooks, menu, prediction, autoplay,
offset tester, runtime dumper) via `externalNativeBuild.ndkBuild`, plus the Java loader class,
in one build. It is not meant to be installed and launched as its own app (no launcher
activity) — it is a build vehicle for two artifacts you then insert into the real game's APK:
`lib/arm64-v8a/libCarromMod.so` and `com/carrommod/loader/MainActivity.class` (in `classes.dex`).

No game offset is filled in anywhere in this project; every one starts unset and is loaded at
runtime from a config file on the device (see below), so filling them in and rebuilding are two
separate, independent steps.

## Opening and building
1. Android Studio: **Open** -> select the `CarromMod/` folder (the one with `settings.gradle.kts` in
   it) -> let Gradle sync -> **Build > Build APK(s)**. First sync will prompt to install the NDK
   if Android Studio doesn't already have one; any NDK r25 or newer works (`app/build.gradle.kts`
   does not pin an NDK version, so AGP's default is used).
2. Command line (wrapper for Gradle 8.7 is included): `./gradlew :app:assembleDebug` (needs `ANDROID_HOME`/`ANDROID_SDK_ROOT` set and
   an NDK installed; Android Studio normally sets this up for you the first time).
3. Output: `app/build/outputs/apk/debug/app-debug.apk`. Inside it:
   `lib/arm64-v8a/libCarromMod.so` and the compiled loader class in `classes.dex`.

This step has NOT been run in the sandbox this project was written in - there is no Android
SDK/NDK available there, only a plain C++ compiler, so the C++ logic itself was built and
tested on the host instead (see "Testing" below) and the Gradle/NDK config was written by hand
against documented, standard `externalNativeBuild.ndkBuild` usage. Building it for real, on your
own machine, is the next concrete step.

## Layout
```
settings.gradle.kts, build.gradle.kts, gradle.properties    Gradle project root
app/
  build.gradle.kts               the only Gradle module: wires externalNativeBuild.ndkBuild to
                                app/src/main/jni/Android.mk, arm64-v8a only
  src/main/
    AndroidManifest.xml        minimal: application tag only, no launcher activity
    java/com/carrommod/loader/MainActivity.java   the loader (see loader/README.md)
    jni/
      Android.mk, Application.mk    NDK build (C++20, Dobby + ImGui as static libs)
      src/
        config/      Offsets.h (every build-dependent value, all unset) + Settings (menu state)
        logic/        Prediction, AutoPlayer, ScreenMap, OffsetTester, RuntimeDumper,
                      Il2CppMetadata, PatternScanner
        game/         GameBridge (reads the live game via Offsets), ShotExecutor, TouchSink
        platform/     Memory, Module, ModuleEnum, Hooks (Dobby), Jni, JniTouchSink, GlOverlay,
                      Log, TouchQueue
        ui/           Ui (the ported DARK_OWNER menu, gold theme, 5 tabs), PredictionDraw
        app/          App: wires all of the above together; the only class main.cpp talks to
        main.cpp      JNI_OnLoad, the two nativeOverlayTouch/nativeDumperTouch exports
      third_party/    Dobby, Dear ImGui, stb_image (copied from the old DARK_OWNER project)
hook.txt               every hook: where it goes, what it needs, how to check it (READ THIS)
loader/README.md       the smali/APK patch steps for the OTHER apk (the game you're modding)
tests/                 Host-side tests (no NDK needed) + run_tests.sh
reference/              Carrom_Pool_Dump.cs, Universal Dumper's IL2CPP smali, 8 Ball Pool source
```

## Menu tabs (ported look, new content)
- **FUNCTIONS** - Enable Prediction, Striker/Puck Path toggles, Auto Play (+ FAST/HUMAN mode),
  Clean Table, plus a status block: bridge state, module, hooks installed, fire-path availability.
- **AUTO MATCH** - mode + coin selection UI, kept from the old project; stored only (queueing
  itself needs lobby hooks this project does not implement yet - the menu says so).
- **ESP LINE** - line style (classic / sea blue), thickness, opacity.
- **TESTER** - type an RVA or a comma-separated pointer chain, read it as every numeric type,
  read an array of slots, save/export/persist labelled findings as `offsets.cfg` lines.
- **DUMPER** - list every loaded library (auto-detect common engine names, or search by hand),
  dump a selected one's raw bytes to a file, check a `global-metadata.dat`'s full table-of-
  contents (Unity/IL2CPP games only), and run an AOB pattern or known-float/double-constant
  scan against the selected library (the way to re-find an offset in a non-IL2CPP game like
  Carrom Pool itself, which has no metadata file at all).

## Filling in offsets (the only step this project deliberately leaves to you)
1. Build and install the patched game APK (see `loader/README.md`) - every offset starts
   unset, so nothing hooks yet, but the overlay and the TESTER/DUMPER tabs work as soon as the
   game module is found.
2. Use the DUMPER tab's pattern/constant scanner and the TESTER tab (or a disassembler) to find
   each value `app/src/main/jni/src/config/Offsets.h` documents.
3. Write them into `<app files dir>/carrom_offsets.cfg` (a template is generated there on first
   run) or paste the TESTER tab's exported lines.
4. Relaunch the game. No rebuild needed: offsets are read from that file at process start.

## Testing (done in this sandbox, repeatable by you)
`tests/run_tests.sh` builds and runs 10 host test suites (489 checks) covering physics, the
autoplay planner, config parsing, the game-memory bridge (against a fake in-memory object
graph), the drag/tap touch executor, the IL2CPP metadata table parser, the AOB/constant
scanner (against this process' own real memory), the runtime dumper, the headless UI (simulated
taps), and an end-to-end App test - plus a syntax check of the four Android-only files against
hand-written stub headers (NOT a real NDK build; see `HANDOFF.md` for exactly what that does and
doesn't prove). Current result: all pass. Nothing has been run inside the real game, and the
Gradle/NDK build itself has not been run anywhere: both need a real Android toolchain.

See `HANDOFF.md` for what's measured, what's assumed, and the next steps.

## Note on the Gradle files
The three build scripts are Kotlin DSL (`*.gradle.kts`): `settings.gradle.kts`, `build.gradle.kts`,
`app/build.gradle.kts`. They were Kotlin syntax inside Groovy-named `.gradle` files before, which makes
Gradle sync fail (`listOf` does not exist in Groovy). Renamed only; contents unchanged. Gradle sync has
still not been run (no Android SDK in the sandbox).
