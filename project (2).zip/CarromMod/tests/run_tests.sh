#!/usr/bin/env bash
# Builds and runs every host test. Exit code 0 only if everything compiled and passed.
# Usage: tests/run_tests.sh            (from anywhere)
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/.." && pwd)"
S="$ROOT/app/src/main/jni/src"; IM="$ROOT/app/src/main/jni/third_party/imgui"; B="${TMPDIR:-/tmp}/carrommod_tests"
mkdir -p "$B"
CXX="${CXX:-g++}"
FLAGS="-std=c++20 -O1 -g -Wall -Wextra -I$S -I$HERE"
fail=0

echo "== building ImGui core (cached)"
for f in imgui imgui_draw imgui_tables imgui_widgets; do
  [ -f "$B/im_$f.o" ] || $CXX -std=c++17 -O1 -w -I"$IM" -c "$IM/$f.cpp" -o "$B/im_$f.o" || { echo "ImGui build failed"; exit 2; }
done

run() { # name sources...
  local name="$1"; shift
  echo "== $name"
  if ! $CXX $FLAGS -I"$IM" "$HERE/$name.cpp" "$@" -o "$B/$name"; then echo "BUILD FAILED: $name"; fail=1; return; fi
  "$B/$name" || fail=1
}

run test_logic    "$S/logic/Prediction.cpp" "$S/logic/AutoPlayer.cpp" "$S/logic/ScreenMap.cpp"
run test_config   "$S/config/Offsets.cpp" "$S/config/Settings.cpp"
run test_bridge   "$S/game/GameBridge.cpp" "$S/config/Offsets.cpp" "$S/platform/Memory.cpp" "$S/logic/ScreenMap.cpp"
run test_offset_tester "$S/logic/OffsetTester.cpp" "$S/platform/Memory.cpp"
run test_runtime_dumper "$S/logic/RuntimeDumper.cpp" "$S/logic/Il2CppMetadata.cpp" "$S/platform/ModuleEnum.cpp" "$S/platform/Memory.cpp"
run test_il2cpp_metadata "$S/logic/Il2CppMetadata.cpp"
run test_pattern_scanner "$S/logic/PatternScanner.cpp" "$S/platform/ModuleEnum.cpp" "$S/platform/Memory.cpp"
run test_metadata_finder -pthread "$S/logic/MetadataFinder.cpp" "$S/logic/Il2CppMetadata.cpp" "$S/logic/StringScanner.cpp" "$S/logic/RuntimeDumper.cpp" \
                  "$S/platform/Memory.cpp" "$S/platform/MemoryRegions.cpp" "$S/platform/ModuleEnum.cpp"
run test_executor "$S/game/ShotExecutor.cpp"
run test_app      "$S/app/App.cpp" "$S/ui/Ui.cpp" "$S/ui/PredictionDraw.cpp" "$S/game/GameBridge.cpp" "$S/game/ShotExecutor.cpp" \
                  "$S/logic/Prediction.cpp" "$S/logic/AutoPlayer.cpp" "$S/logic/ScreenMap.cpp" "$S/logic/OffsetTester.cpp" "$S/logic/RuntimeDumper.cpp" "$S/logic/Il2CppMetadata.cpp" "$S/logic/PatternScanner.cpp" "$S/logic/MetadataFinder.cpp" "$S/logic/StringScanner.cpp" "$S/platform/MemoryRegions.cpp" -pthread "$S/config/Offsets.cpp" \
                  "$S/config/Settings.cpp" "$S/platform/Hooks.cpp" "$S/platform/Module.cpp" "$S/platform/Memory.cpp" "$S/platform/ModuleEnum.cpp" "$B"/im_*.o
run test_ui       "$S/ui/Ui.cpp" "$S/ui/PredictionDraw.cpp" "$S/logic/Prediction.cpp" "$S/logic/AutoPlayer.cpp" \
                  "$S/logic/ScreenMap.cpp" "$S/logic/OffsetTester.cpp" "$S/logic/RuntimeDumper.cpp" "$S/logic/Il2CppMetadata.cpp" "$S/logic/PatternScanner.cpp" "$S/logic/MetadataFinder.cpp" "$S/logic/StringScanner.cpp" "$S/platform/MemoryRegions.cpp" -pthread "$S/config/Settings.cpp" "$S/platform/Memory.cpp" "$S/platform/ModuleEnum.cpp" "$B"/im_*.o

echo "== android-only sources: SYNTAX CHECK against hand-written stub headers (not an NDK build)"
for f in platform/Jni.cpp platform/JniTouchSink.cpp platform/GlOverlay.cpp main.cpp; do
  if $CXX $FLAGS -fsyntax-only -I"$HERE/stubs" -I"$IM" -I"$ROOT/app/src/main/jni/third_party/stb" -I"$ROOT/app/src/main/jni/src" "$S/$f" 2>"$B/syntax.log"; then
    echo "  ok   $f"
  else
    echo "  FAIL $f"; head -20 "$B/syntax.log"; fail=1
  fi
done

if [ $fail -eq 0 ]; then echo "ALL TESTS PASSED"; else echo "SOME TESTS FAILED"; fi
exit $fail
