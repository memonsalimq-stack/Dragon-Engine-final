// The finder is tested against THIS process' real memory: a synthetic "decrypted metadata" block
// is placed on the heap, and the scan must find exactly that block (and reject look-alikes).
#include <chrono>
#include <cstdio>
#include <cstring>
#include <thread>

#include "check.h"
#include "logic/Il2CppMetadata.h"
#include "logic/MetadataFinder.h"
#include "logic/RuntimeDumper.h"
#include "logic/StringScanner.h"
#include "platform/Memory.h"
#include "platform/MemoryRegions.h"

using namespace carrom;

namespace {
// Builds a metadata block: valid header for `layoutVersion`, every table empty except one that
// ends exactly at `totalSize`, so ComputeSize() must return totalSize.
std::vector<uint8_t> BuildMetadata(int32_t raw, double layoutVersion, size_t totalSize) {
    const auto layout = il2cpp::LayoutFor(layoutVersion);
    const int32_t headerSize = 8 + (int32_t)layout.size() * 8;
    std::vector<uint8_t> b(totalSize, 0);
    uint32_t magic = il2cpp::kMetadataMagic;
    std::memcpy(b.data(), &magic, 4);
    std::memcpy(b.data() + 4, &raw, 4);
    for (size_t i = 0; i < layout.size(); ++i) {
        int32_t off = headerSize, cnt = 0;
        if (i + 1 == layout.size()) { off = headerSize + 16; cnt = (int32_t)totalSize - off; }
        std::memcpy(b.data() + 8 + i * 8, &off, 4);
        std::memcpy(b.data() + 12 + i * 8, &cnt, 4);
    }
    // the first table's recorded offset must equal the header size (candidate selection check)
    std::memcpy(b.data() + 8, &headerSize, 4);
    return b;
}
} // namespace

static void TestRegions() {
    std::printf("[memory regions]\n");
    int local = 0;
    bool foundStack = false;
    std::vector<uint8_t> heap(1 << 20, 1);   // allocated BEFORE the snapshot so it must appear in it
    const auto regs = EnumerateRegions();
    CHECK(!regs.empty());
    bool foundHeap = false;
    for (const auto& r : regs) {
        CHECK(r.end > r.start);
        const uintptr_t a = (uintptr_t)&local, h = (uintptr_t)heap.data();
        if (a >= r.start && a < r.end) { foundStack = true; CHECK(r.r && r.w); }
        if (h >= r.start && h < r.end) { foundHeap = true; CHECK(r.r && r.w); }
    }
    CHECK(foundStack);
    CHECK(foundHeap);
}

static void TestComputeSize() {
    std::printf("[compute size]\n");
    auto buf = BuildMetadata(29, 29.0, 5000);
    auto h = il2cpp::ParseMetadataHeader(buf.data(), buf.size());
    CHECK(h.ok);
    CHECK(MetadataFinder::ComputeSize(h) == 5000);
    il2cpp::MetadataResult bad;
    CHECK(MetadataFinder::ComputeSize(bad) == 0);
    h.tables[3].offset = -5;                       // a negative value means a corrupt header
    CHECK(MetadataFinder::ComputeSize(h) == 0);
}

static void TestFindInHeap() {
    std::printf("[find: decrypted metadata block on the heap]\n");
    auto real = BuildMetadata(29, 29.0, 20000);

    // decoy 1: the magic followed by zeros (version 0 is outside 16..40)
    std::vector<uint8_t> decoy1(4096, 0);
    uint32_t magic = il2cpp::kMetadataMagic;
    std::memcpy(decoy1.data(), &magic, 4);
    // decoy 2: magic + a plausible version, but a first-table offset matching no layout
    std::vector<uint8_t> decoy2(4096, 0);
    std::memcpy(decoy2.data(), &magic, 4);
    int32_t v = 29, junk = 12345;
    std::memcpy(decoy2.data() + 4, &v, 4);
    std::memcpy(decoy2.data() + 8, &junk, 4);

    const uintptr_t realAddr = (uintptr_t)real.data();
    const auto found = MetadataFinder::Scan(EnumerateRegions(), 16, size_t(1) << 30, nullptr, nullptr);

    bool foundReal = false;
    for (const auto& f : found) {
        CHECK(f.address != (uintptr_t)decoy1.data());   // decoys are rejected
        CHECK(f.address != (uintptr_t)decoy2.data());
        CHECK(f.rawVersion >= 16 && f.rawVersion <= 40);
        CHECK(f.size > 0);
        if (f.address == realAddr) {
            foundReal = true;
            CHECK(f.rawVersion == 29);
            CHECK(f.version == 29.0);
            CHECK(f.size == 20000);
        }
    }
    CHECK(foundReal);

    // dump it and compare the bytes
    for (const auto& f : found) {
        if (f.address != realAddr) continue;
        const std::string path = "/tmp/carrom_found_metadata.dat";
        std::string err, note;
        CHECK(MetadataFinder::Dump(f, path, &err, &note));
        std::FILE* fp = std::fopen(path.c_str(), "rb");
        CHECK(fp != nullptr);
        if (fp) {
            std::vector<uint8_t> back(20000);
            const size_t n = std::fread(back.data(), 1, back.size(), fp);
            std::fclose(fp);
            CHECK(n == 20000);
            CHECK(std::memcmp(back.data(), real.data(), 20000) == 0);
        }
        // and the dumped file parses with the file-based path too
        CHECK(RuntimeDumper::ReadMetadataHeaderFromFile(path).ok);
    }
    CHECK(!MetadataFinder::Dump(FoundMetadata{}, "/tmp/x.dat", nullptr));
    FoundMetadata fm; fm.address = realAddr; fm.size = 100;
    CHECK(!MetadataFinder::Dump(fm, "/nonexistent_dir/x.dat", nullptr));
}

static void TestAsync() {
    std::printf("[find: async scan]\n");
    auto real = BuildMetadata(24, 24.2, 9000);   // a different version/layout, to exercise candidates
    MetadataFinder finder;
    CHECK(!finder.Running());
    finder.StartAsync(16);
    for (int i = 0; i < 600 && finder.Running(); ++i) std::this_thread::sleep_for(std::chrono::milliseconds(50));
    CHECK(!finder.Running());
    CHECK(finder.BytesScanned() > 0);
    bool ok = false;
    for (const auto& f : finder.Results())
        if (f.address == (uintptr_t)real.data()) { ok = true; CHECK(f.version == 24.2); CHECK(f.size == 9000); }
    CHECK(ok);

    // cancel stops a scan promptly and the destructor joins safely
    MetadataFinder second;
    second.StartAsync(16);
    second.Cancel();
    for (int i = 0; i < 200 && second.Running(); ++i) std::this_thread::sleep_for(std::chrono::milliseconds(50));
    CHECK(!second.Running());
}

static void TestStrings() {
    std::printf("[string scanner]\n");
    const char* blob = "\x01\x02Hello_World_Test\x00\x03xx\x00StrikerRadius\x00\xff";
    const size_t len = 2 + 16 + 1 + 1 + 2 + 1 + 13 + 1 + 1;
    auto all = FindStringsInBuffer((const uint8_t*)blob, len, 6, "", 10);
    CHECK(all.size() == 2);
    CHECK(all[0].text == "Hello_World_Test");
    CHECK(all[0].offset == 2);
    auto filtered = FindStringsInBuffer((const uint8_t*)blob, len, 6, "STRIKER", 10);   // case-insensitive
    CHECK(filtered.size() == 1 && filtered[0].text == "StrikerRadius");
    CHECK(FindStringsInBuffer((const uint8_t*)blob, len, 40, "", 10).empty());
    CHECK(FindStringsInBuffer(nullptr, 10, 6, "", 10).empty());
    CHECK(FindStringsInBuffer((const uint8_t*)blob, len, 6, "", 1).size() == 1);   // result cap
    MappedModule empty;
    CHECK(FindStrings(empty, 6, "").empty());
}

static void TestDumpRange() {
    std::printf("[dump an arbitrary range]\n");
    std::vector<uint8_t> src(8192);
    for (size_t i = 0; i < src.size(); ++i) src[i] = (uint8_t)(i * 7);
    RuntimeDumper d;
    auto r = d.DumpRange((uintptr_t)src.data(), (uintptr_t)src.data() + src.size(), "/tmp/carrom_range_dump.bin");
    CHECK(r.ok && r.bytesWritten == src.size());
    std::FILE* f = std::fopen("/tmp/carrom_range_dump.bin", "rb");
    CHECK(f != nullptr);
    if (f) {
        std::vector<uint8_t> back(src.size());
        CHECK(std::fread(back.data(), 1, back.size(), f) == back.size());
        std::fclose(f);
        CHECK(back == src);
    }
    CHECK(!d.DumpRange(100, 50, "/tmp/x.bin").ok);
}

int main() {
    TestRegions();
    TestComputeSize();
    TestFindInHeap();
    TestAsync();
    TestStrings();
    TestDumpRange();
    return Finish("test_metadata_finder");
}
