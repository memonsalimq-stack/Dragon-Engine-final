#include <cstdio>
#include <string>
#include <vector>

#include "check.h"
#include "config/Offsets.h"
#include "config/Settings.h"

using namespace carrom;

static void TestOffsetsParsing() {
    std::printf("[offsets parsing]\n");
    Offsets o;
    CHECK(o.SetCount() == 0);
    CHECK(o.MissingRequired().size() > 5);
    CHECK(!o.HookGameUpdate.set);

    std::vector<std::string> errs;
    const std::string text =
        "# comment line\n"
        "rva.hook_game_update = 0x1A999D0   # trailing comment\n"
        "field.gm.board=1000\n"
        "field.piece.radius=0x0\n"              // a real zero must be 'set'
        "sym.touches_begin=Java_x_y_nativeTouchesBegin\n"
        "field.gm.rules=\n"                      // blank: stays unset
        "field.gm.state_manager=zzz\n"           // bad number
        "no.such.key=5\n"                        // unknown key
        "garbage line without equals\n";
    const int applied = o.LoadFromText(text, &errs);
    CHECK(applied == 4);
    CHECK(o.HookGameUpdate.set && o.HookGameUpdate.value == 0x1A999D0);
    CHECK(o.GmBoard.set && o.GmBoard.value == 1000);
    CHECK(o.PieceRadius.set && o.PieceRadius.value == 0);
    CHECK(o.SymTouchBegin.set && o.SymTouchBegin.name == "Java_x_y_nativeTouchesBegin");
    CHECK(!o.GmRules.set);
    CHECK(!o.GmStateManager.set);
    CHECK(errs.size() == 3);

    // template: parsing the shipped template applies nothing (all values blank) and has every key
    const std::string tpl = Offsets::TemplateText();
    Offsets t;
    std::vector<std::string> terrs;
    CHECK(t.LoadFromText(tpl, &terrs) == 0);
    CHECK(terrs.empty());
    int keyLines = 0;
    size_t pos = 0;
    while ((pos = tpl.find("\n", pos)) != std::string::npos) {
        ++pos;
        if (tpl.compare(pos, 1, "#") != 0 && pos < tpl.size() && tpl.find('=', pos) < tpl.find('\n', pos)) ++keyLines;
    }
    CHECK(keyLines == Offsets::TotalCount());

    // required vs optional bookkeeping
    Offsets full;
    std::string all = "";
    for (const auto& k : full.MissingRequired()) all += k + "=0x10\n";
    full.LoadFromText(all);
    CHECK(full.MissingRequired().empty());
    CHECK(!full.MissingOptional().empty());   // optional ones are still unset
}

static void TestOffsetsFile() {
    std::printf("[offsets file]\n");
    const std::string path = "/tmp/carrom_offsets_test.cfg";
    FILE* f = std::fopen(path.c_str(), "w");
    std::fputs("rva.hook_game_update=0x40\n", f);
    std::fclose(f);
    Offsets o;
    CHECK(o.LoadFromFile(path));
    CHECK(o.HookGameUpdate.set && o.HookGameUpdate.value == 0x40);
    CHECK(!o.LoadFromFile("/nonexistent/dir/file.cfg"));
}

static void TestSettings() {
    std::printf("[settings]\n");
    Settings s;
    s.autoPlay = true;
    s.autoQueue = true;
    s.predictionLine = false;
    s.autoPlayMode = 1;
    s.lineThickness = 4.5f;
    s.menuX = 12.f;

    Settings r;
    r.Deserialize(s.Serialize());
    CHECK(!r.autoPlay);            // never restored armed
    CHECK(!r.autoQueue);
    CHECK(!r.predictionLine);
    CHECK(r.autoPlayMode == 1);
    CHECK_NEAR(r.lineThickness, 4.5, 1e-6);
    CHECK_NEAR(r.menuX, 12.0, 1e-6);

    // hostile / corrupt input is clamped
    Settings h;
    h.Deserialize("lineThickness=9999\nlineOpacity=-5\nautoPlayMode=77\nqueueMode=-3\nfontPixels=1\nmenuW=0\n");
    CHECK(h.lineThickness <= 10.f && h.lineThickness >= 1.f);
    CHECK(h.lineOpacity >= 0.1f && h.lineOpacity <= 1.f);
    CHECK(h.autoPlayMode == 1);
    CHECK(h.queueMode == 0);
    CHECK(h.fontPixels >= 10.f);
    CHECK(h.menuW >= 200.f);

    const std::string path = "/tmp/carrom_settings_test.ini";
    CHECK(s.Save(path));
    Settings l;
    CHECK(l.Load(path));
    CHECK(l.autoPlayMode == 1);
    CHECK(!l.Load("/nonexistent/x.ini"));
}

int main() {
    TestOffsetsParsing();
    TestOffsetsFile();
    TestSettings();
    return Finish("test_config");
}
