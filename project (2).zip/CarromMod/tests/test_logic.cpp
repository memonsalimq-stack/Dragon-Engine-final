#include <cmath>

#include "check.h"
#include "logic/AutoPlayer.h"
#include "logic/Prediction.h"
#include "logic/ScreenMap.h"

using namespace carrom;

static FrameSnapshot MakeSnapshot() {
    FrameSnapshot s;
    s.valid = true;
    s.generation = 1;
    s.playerTurn = true;
    s.targetPiece = PieceType::White;
    SnapshotPiece st;
    st.id = 0; st.type = PieceType::Striker; st.state = PieceState::Default; st.pos = {0.0, 0.0};
    s.pieces.push_back(st);
    // a white piece on the diagonal towards pocket 2 (34.5, 34.5)
    SnapshotPiece w;
    w.id = 1; w.type = PieceType::White; w.state = PieceState::Default; w.pos = {20.0, 20.0};
    s.pieces.push_back(w);
    // a black piece far away so it does not interfere
    SnapshotPiece b;
    b.id = 2; b.type = PieceType::Black; b.state = PieceState::Default; b.pos = {-20.0, 10.0};
    s.pieces.push_back(b);
    return s;
}

static void TestPredictionBasics() {
    std::printf("[prediction basics]\n");
    Prediction p;
    FrameSnapshot s = MakeSnapshot();

    // invalid snapshot: nothing computed
    FrameSnapshot bad;
    CHECK(!p.Run(bad, false, 0.0, 0.5));
    CHECK(p.scene.piecesCount == 0);

    // a shot straight into empty space: the striker moves and eventually stops or bounces
    CHECK(p.Run(s, false, PI / 2.0, 0.5));
    CHECK(p.scene.piecesCount == 3);
    CHECK(p.scene.pieces[0].positions.size() >= 2);
    CHECK(p.scene.pieces[0].predictedPosition != p.scene.pieces[0].initialPosition);
    // same inputs again: cache hit, nothing recomputed
    CHECK(!p.Run(s, false, PI / 2.0, 0.5));
    // a table change (new generation) invalidates the cache
    s.generation = 2;
    CHECK(p.Run(s, false, PI / 2.0, 0.5));

    // NaN inputs are rejected
    CHECK(!p.Run(s, false, std::nan(""), 0.5));

    // finiteness: every recorded position is finite and on a sane scale
    for (int i = 0; i < p.scene.piecesCount; ++i)
        for (const auto& pt : p.scene.pieces[i].positions) CHECK(IsFinite(pt) && std::fabs(pt.x) < 200 && std::fabs(pt.y) < 200);
}

static void TestPocketing() {
    std::printf("[pocketing a piece on the diagonal]\n");
    Prediction p;
    FrameSnapshot s = MakeSnapshot();
    // striker aimed along the 45 degree diagonal, full power: it must hit the white piece first
    CHECK(p.Run(s, true, PI / 4.0, 1.0, {}, Candidate{1, PI / 4.0, 0, 2, 1.0}));
    CHECK(p.firstHitIsTarget);
    CHECK(!p.scene.pieces[1].onTable);
    CHECK(p.scene.pieces[1].pocketIndex == 2);
    CHECK(p.pocketStatus[2]);

    // negative control: aimed the wrong way, the target is not hit first and not pocketed
    Prediction q;
    CHECK(q.Run(s, true, 3.0 * PI / 2.0, 1.0, {}, Candidate{1, 0.0, 0, 2, 1.0}));
    CHECK(!q.firstHitIsTarget);
    CHECK(q.scene.pieces[1].onTable);
}

static void TestScanFastAndUpdate() {
    std::printf("[autoplay planner]\n");
    Prediction pred;
    AutoPlayer ap;
    FrameSnapshot s = MakeSnapshot();

    pred.Run(s, true, s.aimAngle, s.aimPower);
    CHECK(pred.scene.piecesCount == 3);
    CHECK(ap.ScanFast(pred, s));
    CHECK(ap.candidate().idx == 1);
    CHECK(ap.candidate().pocketIndex == 2);
    CHECK_NEAR(ap.candidate().angle, PI / 4.0, 0.05);
    CHECK(ap.candidate().power >= 0.24 && ap.candidate().power <= 1.0);

    // full Update() flow: disabled -> nothing
    AutoPlayer ap2;
    Prediction pred2;
    ShotAction a = ap2.Update(pred2, s, 100.0);
    CHECK(a.kind == ShotAction::Kind::None);

    ap2.SetEnabled(true);
    a = ap2.Update(pred2, s, 100.0);      // Idle -> Scanning
    CHECK(a.kind == ShotAction::Kind::None);
    a = ap2.Update(pred2, s, 104.0);      // scans, finds, fires
    CHECK(a.kind == ShotAction::Kind::Fire);
    CHECK_NEAR(a.angle, PI / 4.0, 0.05);
    CHECK(a.pieceIdx == 1);
    CHECK(a.gamePieceId == 1);

    // not my turn: no action
    FrameSnapshot notMine = s;
    notMine.playerTurn = false;
    AutoPlayer ap3; Prediction pred3;
    ap3.SetEnabled(true);
    ap3.Update(pred3, notMine, 1.0);
    a = ap3.Update(pred3, notMine, 10.0);
    CHECK(a.kind == ShotAction::Kind::None);

    // cooldown after firing
    AutoPlayer ap4; Prediction pred4;
    ap4.SetEnabled(true);
    ap4.NotifyFired(3);
    for (int i = 0; i < 3; ++i) CHECK(ap4.Update(pred4, s, 100.0 + i).kind == ShotAction::Kind::None);
}

static void TestQueenNomination() {
    std::printf("[queen cover nomination]\n");
    Prediction pred; AutoPlayer ap;
    FrameSnapshot s = MakeSnapshot();
    s.queenCoverRequired = true;
    s.pottedPocketId = 1;       // a different pocket than the one the planner will pick (2)
    ap.SetEnabled(true);
    // restrict to pocket 1 only: the planner will not find the diagonal shot, so nothing fires
    ap.Update(pred, s, 100.0);
    ShotAction a = ap.Update(pred, s, 104.0);
    CHECK(a.kind != ShotAction::Kind::Fire);

    // unrestricted pocket + cover required + a different pocket nominated => nominate, then fire
    FrameSnapshot s2 = MakeSnapshot();
    s2.queenCoverRequired = true;
    s2.pottedPocketId = 0xFFFFFFFFu;
    AutoPlayer ap2; Prediction pred2;
    ap2.SetEnabled(true);
    ap2.Update(pred2, s2, 100.0);
    a = ap2.Update(pred2, s2, 104.0);
    // pottedPocketId >= 4 and candidate pocket 2 != 0xFFFFFFFF => nomination path
    CHECK(a.kind == ShotAction::Kind::None);
    CHECK(ap2.state() == AutoPlayer::State::Nominating);
    bool sawNominate = false, sawFire = false;
    for (int i = 0; i < 40 && !sawFire; ++i) {
        a = ap2.Update(pred2, s2, 105.0 + i);
        if (a.kind == ShotAction::Kind::Nominate) { sawNominate = true; CHECK(a.pocketIndex == 2); }
        if (a.kind == ShotAction::Kind::Fire) sawFire = true;
    }
    CHECK(sawNominate);
    CHECK(sawFire);
}

static void TestScreenMap() {
    std::printf("[screen map]\n");
    ScreenMap m;
    m.SetViewport(694, 1536);
    CHECK(!m.Usable());
    CHECK(!m.WorldToScreen({0, 0}).valid);   // no guessing without a game transform

    WorldAffine a;
    a.ox = 347; a.oy = 768; a.vxx = 10; a.vxy = 0; a.vyx = 0; a.vyy = 10; a.valid = true;
    m.SetAffine(a);
    CHECK(m.Usable());
    const ScreenPoint c = m.WorldToScreen({0, 0});
    CHECK(c.valid);
    CHECK_NEAR(c.x, 347, 1e-3);
    CHECK_NEAR(c.y, 1536 - 768, 1e-3);          // y flipped against the screen height
    const ScreenPoint up = m.WorldToScreen({0, 10});
    CHECK(up.y < c.y);                          // world +y is up on screen
    CHECK_NEAR(m.PixelsPerUnit(), 10.0, 1e-6);
    CHECK(!m.WorldToScreen({std::nan(""), 0}).valid);
    m.ClearAffine();
    CHECK(!m.Usable());
}

int main() {
    TestPredictionBasics();
    TestPocketing();
    TestScanFastAndUpdate();
    TestQueenNomination();
    TestScreenMap();
    return Finish("test_logic");
}
