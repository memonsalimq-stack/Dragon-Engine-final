#include <cstdint>
#include <cstring>

#include "check.h"
#include "logic/OffsetTester.h"

using namespace carrom;

namespace {
alignas(16) uint8_t g_blob[0x200];
alignas(16) uint8_t g_target[0x200];
uintptr_t P(const void* p) { return (uintptr_t)p; }
template <class T> void Put(uint8_t* base, size_t off, T v) { std::memcpy(base + off, &v, sizeof(T)); }
} // namespace

static void TestDirectRead() {
    std::printf("[direct read]\n");
    std::memset(g_blob, 0, sizeof g_blob);
    Put<int32_t>(g_blob, 0x10, -7);
    Put<float>(g_blob, 0x20, 3.5f);
    Put<double>(g_blob, 0x28, 2.25);
    std::memcpy(g_blob + 0x30, "HELLO", 5);

    ModuleInfo mod; mod.found = true; mod.base = P(g_blob); mod.size = 0x200;
    OffsetTester t;
    t.SetModule(mod);

    TestResult bad = t.Read("");
    CHECK(!bad.ok);
    TestResult bad2 = t.Read("not_a_number");
    CHECK(!bad2.ok);

    TestResult r1 = t.Read("0x10");
    CHECK(r1.ok);
    CHECK(r1.asInt32 == -7);
    CHECK(r1.finalAddress == P(g_blob) + 0x10);

    TestResult r2 = t.Read("0x20");
    CHECK_NEAR(r2.asFloat, 3.5, 1e-6);

    TestResult r3 = t.Read("0x28");
    CHECK_NEAR(r3.asDouble, 2.25, 1e-9);

    TestResult r4 = t.Read("0x30");
    CHECK(r4.asAscii.substr(0, 5) == "HELLO");
    CHECK(r4.hexLine.substr(0, 2) == "48");  // 'H'

    // module not found
    OffsetTester t2;
    TestResult r5 = t2.Read("0x10");
    CHECK(!r5.ok);
    CHECK(r5.error.find("module") != std::string::npos);
}

static void TestPointerChain() {
    std::printf("[pointer chain]\n");
    std::memset(g_blob, 0, sizeof g_blob);
    std::memset(g_target, 0, sizeof g_target);
    Put<uintptr_t>(g_blob, 0x10, P(g_target));
    Put<int64_t>(g_target, 0x8, 123456789LL);

    ModuleInfo mod; mod.found = true; mod.base = P(g_blob); mod.size = 0x200;
    OffsetTester t;
    t.SetModule(mod);

    TestResult r = t.Read("0x10,0x8");
    CHECK(r.ok);
    CHECK(r.asInt64 == 123456789LL);
    CHECK(r.finalAddress == P(g_target) + 0x8);

    // a hop that is not a plausible pointer breaks the chain cleanly
    Put<uintptr_t>(g_blob, 0x10, 4);     // tiny, implausible
    TestResult bad = t.Read("0x10,0x8");
    CHECK(!bad.ok);
    CHECK(bad.error.find("plausible") != std::string::npos);

    // decimal hops work too
    Put<uintptr_t>(g_blob, 0x10, P(g_target));
    TestResult r2 = t.Read("16,8");
    CHECK(r2.ok);
    CHECK(r2.asInt64 == 123456789LL);
}

static void TestArrayRead() {
    std::printf("[array read]\n");
    std::memset(g_blob, 0, sizeof g_blob);
    for (int i = 0; i < 5; ++i) Put<int64_t>(g_blob, 0x40 + i * 8, (int64_t)(i * 100));

    ModuleInfo mod; mod.found = true; mod.base = P(g_blob); mod.size = 0x200;
    OffsetTester t;
    t.SetModule(mod);

    auto arr = t.ReadArray("0x40", 5);
    CHECK(arr.size() == 5);
    for (int i = 0; i < 5; ++i) { CHECK(arr[(size_t)i].ok); CHECK(arr[(size_t)i].asInt64 == i * 100); }

    auto clamped = t.ReadArray("0x40", 999);
    CHECK(clamped.size() == 64);

    auto badChain = t.ReadArray("bad", 3);
    CHECK(badChain.size() == 1 && !badChain[0].ok);
}

static void TestSavedOffsets() {
    std::printf("[saved offsets]\n");
    std::memset(g_blob, 0, sizeof g_blob);
    Put<int32_t>(g_blob, 0x50, 42);
    ModuleInfo mod; mod.found = true; mod.base = P(g_blob); mod.size = 0x200;
    OffsetTester t;
    t.SetModule(mod);

    CHECK(t.saved().empty());
    t.Save("field.gm.rules", "0x50", "int32");
    t.Save("field.gm.board", "0x60", "pointer");
    CHECK(t.saved().size() == 2);
    t.Save("field.gm.rules", "0x58", "int32");       // same label overwrites
    CHECK(t.saved().size() == 2);
    CHECK(t.saved()[0].chain == "0x58");

    auto results = t.ReadAllSaved();
    CHECK(results.size() == 2);

    t.RemoveSaved(0);
    CHECK(t.saved().size() == 1);
    CHECK(t.saved()[0].label == "field.gm.board");
    t.RemoveSaved(99);                                 // out of range: no-op, no crash
    CHECK(t.saved().size() == 1);

    const std::string cfg = t.ExportSavedAsConfig();
    CHECK(cfg.find("field.gm.board=") != std::string::npos);

    const std::string path = "/tmp/carrom_offset_tester_test.tsv";
    CHECK(t.SaveSavedToFile(path));
    OffsetTester t2;
    CHECK(t2.LoadSavedFromFile(path));
    CHECK(t2.saved().size() == 1);
    CHECK(t2.saved()[0].label == "field.gm.board");
    CHECK(t2.saved()[0].chain == "0x60");
    CHECK(!t2.LoadSavedFromFile("/nonexistent/x.tsv"));
}

static void TestParseChain() {
    std::printf("[parse chain]\n");
    std::vector<int64_t> h;
    CHECK(ParseChain("0x10,0x20,-8", &h));
    CHECK(h.size() == 3 && h[0] == 0x10 && h[1] == 0x20 && h[2] == -8);
    CHECK(!ParseChain("", &h));
    CHECK(ParseChain("0x10,,0x20", &h) && h.size() == 2); // empty hop between commas is skipped, not fatal
    CHECK(!ParseChain("notahex", &h));
    CHECK(!ParseChain("0x10,bogus", &h));
}

int main() {
    TestDirectRead();
    TestPointerChain();
    TestArrayRead();
    TestSavedOffsets();
    TestParseChain();
    return Finish("test_offset_tester");
}
