#include <vector>

#include "check.h"
#include "game/ShotExecutor.h"
#include "platform/TouchQueue.h"

using namespace carrom;

struct FakeSink : TouchSink {
    struct Ev { char kind; int id; float x, y; };
    std::vector<Ev> ev;
    bool ok = true;
    bool Available() const override { return ok; }
    void Begin(int id, float x, float y) override { ev.push_back({'B', id, x, y}); }
    void Move(int id, float x, float y) override { ev.push_back({'M', id, x, y}); }
    void End(int id, float x, float y) override { ev.push_back({'E', id, x, y}); }
};

static void Run(ShotExecutor& e, float seconds) {
    for (float t = 0; t < seconds; t += 1.f / 60.f) e.Update(1.f / 60.f);
}

static void TestDrag() {
    std::printf("[drag executor]\n");
    FakeSink sink;
    ShotExecutor e;
    CHECK(!e.CanFire());
    e.SetSink(&sink);
    CHECK(e.CanFire());

    CHECK(!e.FireDrag({100, 100}, std::nan(""), 0.5, 1536));   // rejects NaN
    CHECK(!e.FireDrag({100, 100}, 0.0, 0.5, 0.f));             // rejects bad height
    CHECK(e.FireDrag({300, 800}, 3.14159265 / 2.0, 1.0, 1000.f));  // straight up on screen
    CHECK(e.Busy());
    CHECK(!e.FireDrag({1, 1}, 0.0, 0.5, 1000.f));              // busy
    Run(e, 1.2f);
    CHECK(!e.Busy());
    CHECK(sink.ev.front().kind == 'B');
    CHECK(sink.ev.back().kind == 'E');
    int begins = 0, ends = 0;
    for (auto& v : sink.ev) { begins += v.kind == 'B'; ends += v.kind == 'E'; }
    CHECK(begins == 1 && ends == 1);
    // shot direction is up (screen y decreases), so the finger is pulled DOWN (y increases) by 0.30*H
    CHECK_NEAR(sink.ev.back().x, 300.0, 0.5);
    CHECK_NEAR(sink.ev.back().y, 800.0 + 300.0, 0.5);
    // monotonic pull
    float prev = 800.f;
    for (auto& v : sink.ev) if (v.kind == 'M') { CHECK(v.y >= prev - 1e-3f); prev = v.y; }
}

static void TestTapAndAbort() {
    std::printf("[tap + abort]\n");
    FakeSink sink;
    ShotExecutor e;
    e.SetSink(&sink);
    CHECK(e.Tap({50, 60}));
    Run(e, 0.5f);
    CHECK(!e.Busy());
    CHECK(sink.ev.size() == 2 && sink.ev[0].kind == 'B' && sink.ev[1].kind == 'E');

    sink.ev.clear();
    CHECK(e.FireDrag({10, 10}, 0.0, 0.5, 500.f));
    Run(e, 0.3f);                      // past the press, in the pull
    e.Abort();
    CHECK(!e.Busy());
    CHECK(sink.ev.back().kind == 'E');   // the finger is always released

    FakeSink dead; dead.ok = false;
    ShotExecutor e2; e2.SetSink(&dead);
    CHECK(!e2.CanFire());
    CHECK(!e2.FireDrag({1, 1}, 0.0, 0.5, 100.f));
    CHECK(!e2.Tap({1, 1}));
}

static void TestTouchQueue() {
    std::printf("[touch queue]\n");
    auto& q = TouchQueue::Get();
    q.Drain();
    q.Push(0, 1.f, 2.f);
    q.Push(2, 3.f, 4.f);
    auto v = q.Drain();
    CHECK(v.size() == 2 && v[0].action == 0 && v[1].x == 3.f);
    CHECK(q.Drain().empty());
    for (int i = 0; i < 1000; ++i) q.Push(2, 0, 0);
    CHECK(q.Drain().size() <= 256);        // bounded
}

static void TestHitTest() {
    std::printf("[touch hit test]\n");
    TouchQueue q;
    q.SetHitRects({{10, 10, 100, 100}});
    CHECK(!q.ShouldConsume(0, 50, 50));          // overlay not ready: never claims
    q.overlayReady = true;
    CHECK(q.ShouldConsume(0, 50, 50));           // down on the menu
    CHECK(q.ShouldConsume(2, 500, 500));         // drag leaves the rect: still owned
    CHECK(q.ShouldConsume(1, 500, 500));         // up: last owned event
    CHECK(!q.ShouldConsume(2, 50, 50));          // gesture is over
    CHECK(!q.ShouldConsume(0, 300, 300));        // down on the game
    CHECK(!q.ShouldConsume(2, 50, 50));          // moving over the menu does not steal it
    CHECK(!q.ShouldConsume(1, 50, 50));
    CHECK(q.ShouldConsume(0, 10, 10));           // edges count
    CHECK(q.ShouldConsume(3, 0, 0));             // cancel releases
    CHECK(!q.ShouldConsume(2, 50, 50));
}

int main() {
    TestHitTest();
    TestDrag();
    TestTapAndAbort();
    TestTouchQueue();
    return Finish("test_executor");
}
