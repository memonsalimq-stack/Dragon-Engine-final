// MINIMAL HAND-WRITTEN STUB (syntax check only, not the real EGL header).
#pragma once
typedef void* EGLDisplay; typedef void* EGLSurface; typedef void* EGLContext;
typedef unsigned int EGLBoolean; typedef int EGLint;
#define EGL_NO_CONTEXT ((EGLContext)0)
#define EGL_FALSE 0
#define EGL_WIDTH 0x3057
#define EGL_HEIGHT 0x3056
inline EGLContext eglGetCurrentContext() { return nullptr; }
inline EGLBoolean eglQuerySurface(EGLDisplay, EGLSurface, EGLint, EGLint*) { return 0; }
