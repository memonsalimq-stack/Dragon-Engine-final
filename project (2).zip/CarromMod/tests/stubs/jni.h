// MINIMAL HAND-WRITTEN STUB of jni.h, only to syntax-check CarromMod's Android-only sources on a
// host that has no NDK. It is NOT the real header and proves nothing about ABI conformance.
#pragma once
#include <cstdint>
typedef int32_t jint; typedef int64_t jlong; typedef uint8_t jboolean; typedef float jfloat;
typedef void* jobject; typedef void* jclass; typedef void* jarray;
typedef jarray jintArray; typedef jarray jfloatArray;
#define JNI_OK 0
#define JNI_FALSE 0
#define JNI_TRUE 1
#define JNI_VERSION_1_6 0x00010006
#define JNIEXPORT __attribute__((visibility("default")))
#define JNICALL
struct JNIEnv_ {
    jintArray NewIntArray(jint) { return nullptr; }
    jfloatArray NewFloatArray(jint) { return nullptr; }
    void SetIntArrayRegion(jintArray, jint, jint, const jint*) {}
    void SetFloatArrayRegion(jfloatArray, jint, jint, const jfloat*) {}
    void DeleteLocalRef(jobject) {}
};
typedef JNIEnv_ JNIEnv;
struct JavaVM_ {
    jint GetEnv(void** e, jint) { *e = nullptr; return -1; }
    jint AttachCurrentThread(JNIEnv** e, void*) { *e = nullptr; return -1; }
    jint DetachCurrentThread() { return 0; }
};
typedef JavaVM_ JavaVM;
