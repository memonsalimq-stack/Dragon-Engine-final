// Root build file. Nothing per-module goes here; see app/build.gradle.
plugins {
    id("com.android.application") version "8.5.2" apply false
}
