package com.easyvictory.mods;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Puck colour picker. The core decides which colour it uses for your pucks, the opponent's pucks and the lines,
 * and that choice is not visible from here. So the panel asks the native draw layer which colours were drawn
 * recently, shows them as swatches, and lets the user replace any one of them. The user tells the roles apart
 * by looking at the game. Replacements are applied by source colour in Main.cpp and saved between sessions.
 */
final class EvColourPanel {
    interface Bridge {
        /** Colours drawn since the last reset, as ARGB ints. reset=true clears the list first. */
        int[] seen(boolean reset);

        /** Replaces from[i] with to[i] in everything the core draws. */
        void apply(int[] from, int[] to);
    }

    private static final String PREFS = "ev_colours";
    private static final int MAX_SLOTS = 8;
    private static final int[] PALETTE = {
            0xFFFF3B30, 0xFFFF9500, 0xFFFFD60A, 0xFF30D158,
            0xFF00E5FF, 0xFF0A84FF, 0xFFBF5AF2, 0xFFFFFFFF
    };

    private final Context ctx;
    private final Bridge bridge;
    private final SharedPreferences prefs;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Map<Integer, Integer> remap = new LinkedHashMap<Integer, Integer>();
    private final List<Integer> seen = new ArrayList<Integer>();
    private Integer selected;
    private LinearLayout swatchRow;
    private TextView status;

    private EvColourPanel(Context ctx, Bridge bridge) {
        this.ctx = ctx;
        this.bridge = bridge;
        this.prefs = ctx.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        load();
    }

    /** Builds the card and immediately sends the saved replacements to the native layer. */
    static LinearLayout create(Context ctx, Bridge bridge) {
        EvColourPanel panel = new EvColourPanel(ctx, bridge);
        LinearLayout root = panel.build();
        panel.push(false);
        return root;
    }

    private static int rgb(int argb) {
        return 0xFF000000 | (argb & 0x00FFFFFF);
    }

    private void load() {
        remap.clear();
        String raw = prefs.getString("remap", "");
        if (raw == null || raw.isEmpty()) return;
        for (String pair : raw.split(",")) {
            String[] parts = pair.split(":");
            if (parts.length != 2 || remap.size() >= MAX_SLOTS) continue;
            try {
                remap.put(rgb((int) Long.parseLong(parts[0])), rgb((int) Long.parseLong(parts[1])));
            } catch (NumberFormatException ignored) {
            }
        }
    }

    private void push(boolean save) {
        int n = remap.size();
        int[] from = new int[n];
        int[] to = new int[n];
        StringBuilder sb = new StringBuilder();
        int i = 0;
        for (Map.Entry<Integer, Integer> e : remap.entrySet()) {
            from[i] = e.getKey();
            to[i] = e.getValue();
            if (i > 0) sb.append(',');
            sb.append(e.getKey() & 0xFFFFFFFFL).append(':').append(e.getValue() & 0xFFFFFFFFL);
            ++i;
        }
        if (save) prefs.edit().putString("remap", sb.toString()).apply();
        if (bridge != null) bridge.apply(from, to);
    }

    private LinearLayout build() {
        LinearLayout card = new LinearLayout(ctx);
        card.setOrientation(LinearLayout.VERTICAL);
        EvIcons.styleFeatureCard(ctx, card, 44);

        TextView title = new TextView(ctx);
        EvIcons.styleSeekLabel(ctx, title, "Puck colours");
        title.setText("Puck colours");
        card.addView(title);

        TextView hint = new TextView(ctx);
        hint.setText("Scan while a match with prediction is on screen. Tap a colour, then pick its new colour.");
        hint.setTextColor(EvIcons.TEXT_MUTED);
        hint.setTextSize(10f);
        hint.setPadding(0, EvIcons.dp(ctx, 2), 0, EvIcons.dp(ctx, 6));
        card.addView(hint);

        Button scan = EvIcons.createChoiceButton(ctx);
        EvIcons.styleChoiceButton(ctx, scan, false, 0, "Scan colours", "Puck colours");
        scan.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                scanNow();
            }
        });
        card.addView(scan, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, EvIcons.dp(ctx, 30)));

        status = new TextView(ctx);
        status.setTextColor(EvIcons.TEXT_MUTED);
        status.setTextSize(10f);
        status.setPadding(0, EvIcons.dp(ctx, 4), 0, EvIcons.dp(ctx, 2));
        card.addView(status);

        swatchRow = new LinearLayout(ctx);
        swatchRow.setOrientation(LinearLayout.HORIZONTAL);
        swatchRow.setGravity(Gravity.CENTER_VERTICAL);
        card.addView(swatchRow, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout palette = new LinearLayout(ctx);
        palette.setOrientation(LinearLayout.HORIZONTAL);
        palette.setGravity(Gravity.CENTER_VERTICAL);
        palette.setPadding(0, EvIcons.dp(ctx, 6), 0, 0);
        for (int i = 0; i < PALETTE.length; ++i) {
            final int colour = PALETTE[i];
            palette.addView(circle(colour, colour, false, new View.OnClickListener() {
                @Override public void onClick(View v) {
                    applyToSelected(colour);
                }
            }));
        }
        card.addView(palette);

        Button reset = EvIcons.createChoiceButton(ctx);
        EvIcons.styleChoiceButton(ctx, reset, false, 0, "Reset this colour", "Puck colours");
        reset.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (selected == null) {
                    Toast.makeText(ctx, "Tap a colour above first", Toast.LENGTH_SHORT).show();
                    return;
                }
                remap.remove(selected);
                push(true);
                refreshSwatches();
            }
        });
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, EvIcons.dp(ctx, 30));
        rlp.topMargin = EvIcons.dp(ctx, 6);
        card.addView(reset, rlp);

        refreshSwatches();
        return card;
    }

    private void scanNow() {
        status.setText("Scanning...");
        if (bridge != null) bridge.seen(true);
        handler.postDelayed(new Runnable() {
            @Override public void run() {
                int[] found = bridge != null ? bridge.seen(false) : null;
                seen.clear();
                if (found != null) {
                    for (int c : found) {
                        if (seen.size() < MAX_SLOTS) seen.add(rgb(c));
                    }
                }
                status.setText(seen.isEmpty()
                        ? "Nothing drawn yet. Open a match with Show Prediction on, then scan again."
                        : "Found " + seen.size() + " colour(s). Tap one.");
                refreshSwatches();
            }
        }, 1500);
    }

    private void applyToSelected(int colour) {
        if (selected == null) {
            Toast.makeText(ctx, "Tap a colour above first", Toast.LENGTH_SHORT).show();
            return;
        }
        if (remap.size() >= MAX_SLOTS && !remap.containsKey(selected)) {
            Toast.makeText(ctx, "Too many replaced colours. Reset one first.", Toast.LENGTH_SHORT).show();
            return;
        }
        remap.put(selected, rgb(colour));
        push(true);
        refreshSwatches();
    }

    private List<Integer> sources() {
        List<Integer> all = new ArrayList<Integer>(seen);
        for (Integer key : remap.keySet()) {
            if (!all.contains(key) && all.size() < MAX_SLOTS) all.add(key);
        }
        return all;
    }

    private void refreshSwatches() {
        swatchRow.removeAllViews();
        for (final Integer source : sources()) {
            Integer replacement = remap.get(source);
            boolean isSelected = selected != null && selected.equals(source);
            // Fill shows what is drawn now; the ring shows the original colour when it has been replaced.
            swatchRow.addView(circle(replacement != null ? replacement : source, source, isSelected,
                    new View.OnClickListener() {
                        @Override public void onClick(View v) {
                            selected = source;
                            refreshSwatches();
                        }
                    }));
        }
    }

    private View circle(int fill, int ring, boolean highlighted, View.OnClickListener click) {
        View v = new View(ctx);
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(fill);
        d.setStroke(EvIcons.dp(ctx, highlighted ? 3 : 2), highlighted ? 0xFFFFFFFF : ring);
        v.setBackground(d);
        v.setOnClickListener(click);
        int size = EvIcons.dp(ctx, 20);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(size, size);
        lp.setMargins(EvIcons.dp(ctx, 2), EvIcons.dp(ctx, 2), EvIcons.dp(ctx, 2), EvIcons.dp(ctx, 2));
        v.setLayoutParams(lp);
        return v;
    }
}
