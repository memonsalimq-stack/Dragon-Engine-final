package com.easyvictory.mods;

import android.content.Context;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import org.json.JSONObject;

/**
 * Key check against the Firebase Realtime Database configured in name.h /
 * nativeGetLicenseEndpoint(), replacing the old evloader.top panel used by
 * CrmAuth. This class only does network I/O and JSON field extraction; the
 * actual expiry/revoke/device-limit decision is made in native code
 * (nativeEvaluateLicense) so it is not a single edit away in the Java/smali.
 *
 * Record shape expected at {endpoint}/keys/{KEY}.json :
 *   { "admin": "Memon_salim", "createdAt": <sec>, "expiresAt": <sec or 0>,
 *     "maxDevices": <int or 0>, "revoked": <bool>, "devices": { "<fp>": <sec> } }
 *
 * Ground truth: this is a client-only check. A patched/cracked APK can always
 * skip the verdict this class returns; the Firebase rules are what actually
 * stop an unregistered device from being written into "devices", not this
 * class. Nothing here is claimed to be unbypassable.
 */
final class FirebaseLicense {
    private FirebaseLicense() {}

    static native String nativeGetLicenseEndpoint();
    static native boolean nativeValidateKeyFormat(String key);
    static native String nativeEvaluateLicense(long expiresAtEpochSec, boolean revoked,
            int maxDevices, boolean deviceAlreadyRegistered, int deviceCount, long nowEpochSec);

    static final class Result {
        final String status;       // OK, FORMAT, NOT_FOUND, EXPIRED, REVOKED, DEVICE_LIMIT, NETWORK_ERROR
        final String admin;
        final long expiresAtMillis;
        final int maxDevices;
        final int deviceCount;
        Result(String status, String admin, long expiresAtMillis, int maxDevices, int deviceCount) {
            this.status = status; this.admin = admin; this.expiresAtMillis = expiresAtMillis;
            this.maxDevices = maxDevices; this.deviceCount = deviceCount;
        }
    }

    /** Network call: must run off the main thread. */
    static Result check(Context context, String rawKey) {
        String key = rawKey == null ? "" : rawKey.trim().toUpperCase(java.util.Locale.US);
        boolean formatOk;
        try {
            formatOk = nativeValidateKeyFormat(key);
        } catch (UnsatisfiedLinkError | Exception e) {
            formatOk = key.matches("^[0-9A-F]{5}-[0-9A-F]{5}-[0-9A-F]{5}-[0-9A-F]{5}$");
        }
        if (!formatOk) return new Result("FORMAT", null, 0L, 0, 0);

        String endpoint;
        try {
            endpoint = nativeGetLicenseEndpoint();
        } catch (UnsatisfiedLinkError | Exception e) {
            endpoint = null;
        }
        if (endpoint == null || endpoint.trim().isEmpty()) return new Result("NETWORK_ERROR", null, 0L, 0, 0);
        endpoint = endpoint.trim();
        if (endpoint.endsWith("/")) endpoint = endpoint.substring(0, endpoint.length() - 1);

        JSONObject record;
        try {
            record = httpGetJson(endpoint + "/keys/" + key + ".json");
        } catch (IOException e) {
            return new Result("NETWORK_ERROR", null, 0L, 0, 0);
        }
        if (record == null) return new Result("NOT_FOUND", null, 0L, 0, 0);

        String admin = record.optString("admin", "");
        long expiresAtSec = record.optLong("expiresAt", 0L);
        int maxDevices = record.optInt("maxDevices", 0);
        boolean revoked = record.optBoolean("revoked", false);
        JSONObject devices = record.optJSONObject("devices");
        if (devices == null) devices = new JSONObject();

        String fp = CrmDeviceKey.fingerprint();
        if (fp.isEmpty()) return new Result("NETWORK_ERROR", null, 0L, 0, 0);
        boolean already = devices.has(fp);
        int deviceCount = devices.length();
        long nowSec = System.currentTimeMillis() / 1000L;

        String verdict;
        try {
            verdict = nativeEvaluateLicense(expiresAtSec, revoked, maxDevices, already, deviceCount, nowSec);
        } catch (UnsatisfiedLinkError | Exception e) {
            if (revoked) verdict = "REVOKED";
            else if (expiresAtSec > 0 && nowSec > expiresAtSec) verdict = "EXPIRED";
            else if (!already && maxDevices > 0 && deviceCount >= maxDevices) verdict = "DEVICE_LIMIT";
            else verdict = "OK";
        }

        if ("OK".equals(verdict) && !already) {
            try {
                httpPutNumber(endpoint + "/keys/" + key + "/devices/" + fp + ".json", nowSec);
                deviceCount += 1;
            } catch (IOException ignored) {
                // Registration failed (offline/rule rejection); still let this check
                // through since the server independently enforces the device cap on
                // the next write attempt, but don't claim the device as counted.
            }
        }
        return new Result(verdict, admin, expiresAtSec > 0 ? expiresAtSec * 1000L : 0L, maxDevices, deviceCount);
    }

    private static JSONObject httpGetJson(String url) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod("GET");
        c.setConnectTimeout(9000);
        c.setReadTimeout(9000);
        try {
            int code = c.getResponseCode();
            if (code != 200) return null;
            String body = readAll(c.getInputStream());
            if (body == null || body.trim().isEmpty() || "null".equals(body.trim())) return null;
            return new JSONObject(body);
        } catch (Exception e) {
            throw new IOException(e);
        } finally {
            c.disconnect();
        }
    }

    private static void httpPutNumber(String url, long value) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod("PUT");
        c.setDoOutput(true);
        c.setConnectTimeout(9000);
        c.setReadTimeout(9000);
        c.setRequestProperty("Content-Type", "application/json");
        try {
            byte[] body = String.valueOf(value).getBytes(StandardCharsets.US_ASCII);
            OutputStream out = c.getOutputStream();
            out.write(body);
            out.flush();
            int code = c.getResponseCode();
            if (code != 200) throw new IOException("PUT " + code);
        } finally {
            c.disconnect();
        }
    }

    private static String readAll(InputStream in) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[2048];
        int n;
        while ((n = in.read(buf)) != -1) {
            bos.write(buf, 0, n);
            if (bos.size() > 65536) break;
        }
        return bos.toString("UTF-8");
    }
}
