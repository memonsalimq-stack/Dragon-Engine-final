package com.easyvictory.mods;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.InputFilter;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Blocking full-screen key gate. MainActivity.Start() will not start the Menu
 * overlay service until this activity finishes with RESULT_OK, which it only
 * does after FirebaseLicense.check() returns "OK". Device registration and
 * the expiry/revoke/device-limit decision happen inside FirebaseLicense; this
 * class is presentation plus the one network call.
 */
public final class LicenseGateActivity extends Activity {
    static final String EXTRA_VERIFIED = "verified";
    private static final String PREFS = "dragon_license_gate";
    private static final String PREF_LAST_KEY = "last_key";
    private static final String TELEGRAM_CHANNEL = "https://t.me/DragonEngineOfficial";

    private EditText input;
    private TextView status;
    private ProgressBar spinner;
    private Button loginBtn;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.parseColor("#1A1B1F"));
        setContentView(buildView());
        String remembered = getSharedPreferences(PREFS, MODE_PRIVATE).getString(PREF_LAST_KEY, "");
        if (!remembered.isEmpty()) input.setText(remembered);
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private View buildView() {
        final int bg = Color.parseColor("#1A1B1F");
        final int card = Color.parseColor("#25262B");
        final int border = Color.parseColor("#F87858");
        final int blue = Color.parseColor("#FF7A59");
        final int textWhite = Color.parseColor("#F1F1F3");
        final int textMuted = Color.parseColor("#8C8C94");

        ScrollView root = new ScrollView(this);
        root.setBackgroundColor(bg);
        root.setFillViewport(true);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER);
        content.setPadding(dp(28), dp(48), dp(28), dp(48));
        content.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        TextView title = new TextView(this);
        title.setText("DRAGON ENGINE");
        title.setTextColor(blue);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24f);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        content.addView(title);

        TextView sub = new TextView(this);
        sub.setText("Enter your key to continue");
        sub.setTextColor(textMuted);
        sub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, dp(6), 0, dp(28));
        content.addView(sub);

        LinearLayout card1 = new LinearLayout(this);
        card1.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setColor(card);
        cardBg.setCornerRadius(dp(14));
        cardBg.setStroke(dp(1), border);
        card1.setBackground(cardBg);
        card1.setPadding(dp(18), dp(18), dp(18), dp(18));
        card1.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        input = new EditText(this);
        input.setHint("XXXXX-XXXXX-XXXXX-XXXXX");
        input.setHintTextColor(Color.parseColor("#6B6C74"));
        input.setTextColor(textWhite);
        input.setSingleLine(true);
        input.setAllCaps(true);
        input.setFilters(new InputFilter[]{new InputFilter.AllCaps(), new InputFilter.LengthFilter(23)});
        input.setGravity(Gravity.CENTER);
        input.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f);
        GradientDrawable inputBg = new GradientDrawable();
        inputBg.setColor(bg);
        inputBg.setCornerRadius(dp(10));
        inputBg.setStroke(dp(1), border);
        input.setBackground(inputBg);
        input.setPadding(dp(12), dp(12), dp(12), dp(12));
        card1.addView(input, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(10), 0, 0);
        Button paste = outlineButton("PASTE", blue, border);
        paste.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null && cm.hasPrimaryClip() && cm.getPrimaryClip().getItemCount() > 0) {
                    CharSequence c = cm.getPrimaryClip().getItemAt(0).getText();
                    if (c != null) input.setText(c.toString().trim().toUpperCase(java.util.Locale.US));
                }
            }
        });
        LinearLayout.LayoutParams half = new LinearLayout.LayoutParams(0, dp(44), 1f);
        half.setMargins(0, 0, dp(6), 0);
        row.addView(paste, half);

        loginBtn = new Button(this);
        loginBtn.setText("LOGIN");
        loginBtn.setAllCaps(false);
        loginBtn.setTextColor(Color.parseColor("#2B1208"));
        loginBtn.setTypeface(Typeface.DEFAULT_BOLD);
        GradientDrawable loginBg = new GradientDrawable();
        loginBg.setColor(blue);
        loginBg.setCornerRadius(dp(10));
        loginBtn.setBackground(loginBg);
        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { attemptLogin(); }
        });
        LinearLayout.LayoutParams half2 = new LinearLayout.LayoutParams(0, dp(44), 1f);
        half2.setMargins(dp(6), 0, 0, 0);
        row.addView(loginBtn, half2);
        card1.addView(row);

        spinner = new ProgressBar(this);
        spinner.setVisibility(View.GONE);
        LinearLayout.LayoutParams spinnerLp = new LinearLayout.LayoutParams(dp(28), dp(28));
        spinnerLp.gravity = Gravity.CENTER;
        spinnerLp.topMargin = dp(12);
        card1.addView(spinner, spinnerLp);

        status = new TextView(this);
        status.setTextColor(Color.parseColor("#F0606A"));
        status.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, dp(10), 0, 0);
        card1.addView(status);

        content.addView(card1, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        Button getKey = outlineButton("GET KEY  •  @DragonEngineOfficial", blue, border);
        getKey.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(TELEGRAM_CHANNEL)));
            }
        });
        LinearLayout.LayoutParams getKeyLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44));
        getKeyLp.topMargin = dp(14);
        content.addView(getKey, getKeyLp);

        root.addView(content);
        return root;
    }

    private Button outlineButton(String text, int textColor, int border) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(textColor);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.TRANSPARENT);
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), border);
        b.setBackground(bg);
        return b;
    }

    private void attemptLogin() {
        final String key = input.getText().toString().trim().toUpperCase(java.util.Locale.US);
        if (key.isEmpty()) { status.setText("Enter a key first."); return; }
        loginBtn.setEnabled(false);
        spinner.setVisibility(View.VISIBLE);
        status.setText("");
        new AsyncTask<Void, Void, FirebaseLicense.Result>() {
            @Override protected FirebaseLicense.Result doInBackground(Void... v) {
                return FirebaseLicense.check(getApplicationContext(), key);
            }
            @Override protected void onPostExecute(FirebaseLicense.Result r) {
                spinner.setVisibility(View.GONE);
                loginBtn.setEnabled(true);
                if (r == null) { status.setText("Network error. Try again."); return; }
                switch (r.status) {
                    case "OK":
                        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(PREF_LAST_KEY, key).apply();
                        LicenseSession.set(key, r.admin, r.expiresAtMillis, r.maxDevices, r.deviceCount);
                        Toast.makeText(LicenseGateActivity.this, "License verified.", Toast.LENGTH_SHORT).show();
                        setResult(RESULT_OK, new Intent().putExtra(EXTRA_VERIFIED, true));
                        finish();
                        break;
                    case "FORMAT":
                        status.setText("Key format must be XXXXX-XXXXX-XXXXX-XXXXX.");
                        break;
                    case "NOT_FOUND":
                        status.setText("USER OR KEY NOT REGISTERED");
                        break;
                    case "EXPIRED":
                        status.setText("This key has expired.");
                        break;
                    case "REVOKED":
                        status.setText("This key was revoked.");
                        break;
                    case "DEVICE_LIMIT":
                        status.setText("Device limit reached for this key.");
                        break;
                    default:
                        status.setText("Could not reach the license server. Check your connection.");
                }
            }
        }.execute();
    }
}
