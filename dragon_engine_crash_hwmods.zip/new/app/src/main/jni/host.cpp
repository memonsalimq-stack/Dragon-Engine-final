// libCrash.so: the library the Java side loads. It owns JNI_OnLoad and the touch natives the
// game activity calls, locates libHwMods.so, checks its ABI version, and starts it.
#include <jni.h>
#include <dlfcn.h>
#include <android/log.h>

#include <atomic>
#include <cstdint>
#include <string>

#define HOST_LOG(...) __android_log_print(ANDROID_LOG_INFO, "Crash", __VA_ARGS__)

namespace {

constexpr const char* kCoreName = "libHwMods.so";
constexpr uint32_t    kCoreAbi  = 0x44524701u;   // must equal DRAGON_CORE_ABI in main.cpp

using AbiFn   = uint32_t (*)();
using StartFn = int (*)(JavaVM*);
using TouchFn = int (*)(int, float, float);

std::atomic<TouchFn> g_touch{nullptr};

void HostAnchor() {}

void* OpenCore() {
    // Already loaded by Java (System.loadLibrary) or by a previous call.
    if (void* h = dlopen(kCoreName, RTLD_NOW | RTLD_NOLOAD)) return h;
    if (void* h = dlopen(kCoreName, RTLD_NOW)) return h;

    // Fall back to the directory this library was loaded from.
    Dl_info info{};
    if (dladdr(reinterpret_cast<void*>(&HostAnchor), &info) && info.dli_fname) {
        std::string path = info.dli_fname;
        const size_t slash = path.rfind('/');
        if (slash != std::string::npos) {
            const std::string sibling = path.substr(0, slash + 1) + kCoreName;
            if (void* h = dlopen(sibling.c_str(), RTLD_NOW)) return h;
        }
    }
    HOST_LOG("cannot open %s: %s", kCoreName, dlerror());
    return nullptr;
}

}  // namespace

extern "C" JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void*) {
    // The game must keep running even when the core is unavailable, so every failure below
    // returns a normal JNI version and leaves the mod inactive.
    void* core = OpenCore();
    if (!core) return JNI_VERSION_1_6;

    auto abi = reinterpret_cast<AbiFn>(dlsym(core, "dragon_core_abi_version"));
    if (!abi || abi() != kCoreAbi) {
        HOST_LOG("core ABI mismatch (found 0x%x, need 0x%x)", abi ? abi() : 0u, kCoreAbi);
        return JNI_VERSION_1_6;
    }

    auto touch = reinterpret_cast<TouchFn>(dlsym(core, "dragon_core_touch"));
    auto start = reinterpret_cast<StartFn>(dlsym(core, "dragon_core_start"));
    if (!touch || !start) {
        HOST_LOG("core is missing dragon_core_start / dragon_core_touch");
        return JNI_VERSION_1_6;
    }

    g_touch.store(touch, std::memory_order_release);
    start(vm);
    return JNI_VERSION_1_6;
}

extern "C" JNIEXPORT jboolean JNICALL Java_com_miniclip_carrom_CarromActivity_nativeOverlayTouch(
        JNIEnv*, jclass, jint action, jfloat x, jfloat y) {
    if (TouchFn f = g_touch.load(std::memory_order_acquire)) f(action, x, y);
    return JNI_FALSE;
}

extern "C" JNIEXPORT jboolean JNICALL Java_com_miniclip_carrom_CarromActivity_nativeDumperTouch(
        JNIEnv*, jclass, jint action, jfloat x, jfloat y) {
    if (TouchFn f = g_touch.load(std::memory_order_acquire)) f(action, x, y);
    return JNI_FALSE;
}
