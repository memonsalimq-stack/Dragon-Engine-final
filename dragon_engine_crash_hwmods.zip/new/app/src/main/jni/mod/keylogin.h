/*
 * Dragon Engine - Firebase Realtime Database license check
 * Created by @Memon_salim
 *
 * Key format : XXXXX-XXXXX-XXXXX-XXXXX  (4 groups of 5 hex digits, upper case)  e.g. 5E343-92B79-F3A72-8413E
 *
 * Database layout (see firebase_database.rules.json):
 *   /keys/<sha256(KEY)>   = { active:true, expiry:<epoch ms, 0 = lifetime>, deviceLimit:<n>,
 *                              createdBy:"<admin name>", created:<epoch ms>,
 *                              devices:{ <deviceId>:{ first:<ms>, last:<ms>, model:"..." } } }
 *   /config               = { about:"...", channels:{ a:{ name:"...", url:"https://t.me/..." } } }   (optional)
 *
 * The plain key never leaves the device: only its SHA-256 is used as the database path.
 * Expiry is judged against the server clock (HTTP Date header), not the phone clock.
 *
 * Client side checks can always be patched out of a shipped binary by a determined person. This file
 * makes that expensive (obfuscated strings, split/derived session token, several independent gates,
 * periodic re-verification) but it cannot make it impossible.
 */

#pragma once
#ifndef DRAGON_KEYLOGIN_H
#define DRAGON_KEYLOGIN_H

#include <string>
#include <vector>
#include <utility>
#include <mutex>
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <ctime>
#include <sstream>
#include <iomanip>
#include <pthread.h>
#include <unistd.h>
#include <jni.h>
#include <android/log.h>

#include "oxorany/oxorany.h"
#include "json/json.hpp"

// The ONLY host the app may contact. jnihttp.h refuses every other URL (old panel/API endpoints included).
#define KL_FIREBASE_HOST  "nova-engine-3c69b-default-rtdb.firebaseio.com"
#define JNIHTTP_ALLOWED_HOST KL_FIREBASE_HOST

// HTTPS over JNI (replaces libcurl/OpenSSL, no prebuilt .a needed)
#include "jnihttp.h"

// ----------------------------------------------------------------------------------------------
//  CONFIGURATION
// ----------------------------------------------------------------------------------------------
// (KL_FIREBASE_HOST is defined above the jnihttp.h include)
#define KL_TELEGRAM_URL   "https://t.me/DragonEngineOfficial"
#define KL_OWNER_HANDLE   "@Memon_salim"
#define KL_RECHECK_SECONDS 240

#define KL_K1 0x5A17C3E1u
#define KL_K2 0xC0DE5EEDu
#define KL_K3 0x1B873593u

// ----------------------------------------------------------------------------------------------
//  SHA-256 (pure C++, no OpenSSL)
// ----------------------------------------------------------------------------------------------
namespace SHA256Impl {
    static const uint32_t K[64] = {
        0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
        0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
        0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
        0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
        0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
        0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
        0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
        0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
    };
    static inline uint32_t rotr(uint32_t x, int n) { return (x >> n) | (x << (32 - n)); }

    static inline std::string hash(const std::string& msg) {
        uint32_t h0=0x6a09e667,h1=0xbb67ae85,h2=0x3c6ef372,h3=0xa54ff53a;
        uint32_t h4=0x510e527f,h5=0x9b05688c,h6=0x1f83d9ab,h7=0x5be0cd19;
        std::string data = msg;
        uint64_t bitLen = (uint64_t)msg.size() * 8;
        data += (char)0x80;
        while (data.size() % 64 != 56) data += (char)0x00;
        for (int i = 7; i >= 0; i--) data += (char)((bitLen >> (i * 8)) & 0xFF);
        for (size_t chunk = 0; chunk < data.size(); chunk += 64) {
            uint32_t w[64];
            for (int i = 0; i < 16; i++) {
                w[i] = ((uint32_t)(uint8_t)data[chunk+i*4]   << 24) |
                       ((uint32_t)(uint8_t)data[chunk+i*4+1] << 16) |
                       ((uint32_t)(uint8_t)data[chunk+i*4+2] <<  8) |
                       ((uint32_t)(uint8_t)data[chunk+i*4+3]);
            }
            for (int i = 16; i < 64; i++) {
                uint32_t s0 = rotr(w[i-15],7)^rotr(w[i-15],18)^(w[i-15]>>3);
                uint32_t s1 = rotr(w[i-2],17)^rotr(w[i-2],19)^(w[i-2]>>10);
                w[i] = w[i-16] + s0 + w[i-7] + s1;
            }
            uint32_t a=h0,b=h1,c=h2,d=h3,e=h4,f=h5,g=h6,hh=h7;
            for (int i = 0; i < 64; i++) {
                uint32_t S1 = rotr(e,6)^rotr(e,11)^rotr(e,25);
                uint32_t ch = (e&f)^(~e&g);
                uint32_t t1 = hh+S1+ch+K[i]+w[i];
                uint32_t S0 = rotr(a,2)^rotr(a,13)^rotr(a,22);
                uint32_t maj = (a&b)^(a&c)^(b&c);
                uint32_t t2 = S0+maj;
                hh=g; g=f; f=e; e=d+t1; d=c; c=b; b=a; a=t1+t2;
            }
            h0+=a; h1+=b; h2+=c; h3+=d; h4+=e; h5+=f; h6+=g; h7+=hh;
        }
        std::ostringstream oss;
        uint32_t hs[8] = {h0,h1,h2,h3,h4,h5,h6,h7};
        for (int i = 0; i < 8; i++) oss << std::hex << std::setw(8) << std::setfill('0') << hs[i];
        return oss.str();
    }
}

// ----------------------------------------------------------------------------------------------
//  Session state
// ----------------------------------------------------------------------------------------------
struct KlSession {
    std::string createdBy;
    int64_t     expiryMs    = 0;     // 0 = lifetime
    int         deviceLimit = 0;
    int         deviceCount = 0;
    std::string about;
    std::vector<std::pair<std::string, std::string>> channels;   // name, url
};

static std::mutex      g_klMutex;
static KlSession       g_klSession;
static std::string     g_klStatus;
static volatile bool   g_klStatusOk = false;
static volatile bool   g_auth_checking = false;
static volatile bool   g_auth_done = false;
static std::string     g_klDeviceId;
static std::string     g_klActiveHash;
static volatile int64_t g_klOffsetMs = 0;       // server time - device time
static volatile uint32_t g_klTokA = 0, g_klTokB = 0, g_klTokC = 0;
static volatile int    g_klRecheckGen = 0;

static inline uint32_t KlMix(uint32_t x) {
    x ^= x >> 16; x *= 0x7feb352dU; x ^= x >> 15; x *= 0x846ca68bU; x ^= x >> 16;
    return x;
}
static inline uint32_t KlStrHash(const std::string& s) {
    uint32_t h = 2166136261u;
    for (unsigned char c : s) { h ^= c; h *= 16777619u; }
    return KlMix(h);
}
static inline int64_t KlNowMs() {
    struct timespec ts; clock_gettime(CLOCK_REALTIME, &ts);
    return (int64_t)ts.tv_sec * 1000 + ts.tv_nsec / 1000000 + g_klOffsetMs;
}
static void KlSetStatus(const std::string& s, bool ok) {
    std::lock_guard<std::mutex> l(g_klMutex);
    g_klStatus = s; g_klStatusOk = ok;
}
static std::string KlGetStatus() {
    std::lock_guard<std::mutex> l(g_klMutex);
    return g_klStatus;
}
static KlSession KlGetSession() {
    std::lock_guard<std::mutex> l(g_klMutex);
    return g_klSession;
}

// ----------------------------------------------------------------------------------------------
//  Gate. Three variables must agree with each other AND with the device id, and the license must not
//  have expired by server time. Call it from several places (UI, hooks) - never cache the result.
// ----------------------------------------------------------------------------------------------
__attribute__((noinline)) static bool NovaEngine_IsLoggedIn() {
    const uint32_t a = g_klTokA, b = g_klTokB, c = g_klTokC;
    if (!a || !b || !c) return false;
    const uint32_t r = a ^ KL_K1;
    const uint32_t dev = KlStrHash(g_klDeviceId);
    if (b != (KlMix(r) ^ dev ^ KL_K2)) return false;
    if (c != (KlMix(b + r) ^ KL_K3)) return false;
    const int64_t exp = g_klSession.expiryMs;
    if (exp > 0 && KlNowMs() >= exp) return false;
    return true;
}

static void KlGrant() {
    uint32_t r = (uint32_t)(time(nullptr) * 2654435761u) ^ (uint32_t)(uintptr_t)&r ^ (uint32_t)rand();
    if (!r) r = 0xA5A5A5A5u;
    const uint32_t dev = KlStrHash(g_klDeviceId);
    const uint32_t b = KlMix(r) ^ dev ^ KL_K2;
    const uint32_t c = KlMix(b + r) ^ KL_K3;
    g_klTokA = r ^ KL_K1; g_klTokB = b; g_klTokC = c;
}
static void KlRevoke() {
    g_klTokA = 0; g_klTokB = 0; g_klTokC = 0;
}

// ----------------------------------------------------------------------------------------------
//  Key format
// ----------------------------------------------------------------------------------------------
static std::string KlNormalizeKey(const std::string& in) {
    std::string out;
    for (char ch : in) {
        if (ch == ' ' || ch == '\n' || ch == '\r' || ch == '\t') continue;
        out += (ch >= 'a' && ch <= 'z') ? (char)(ch - 32) : ch;
    }
    return out;
}
// 5-5-5-5 upper-case hex, e.g. 5E343-92B79-F3A72-8413E
static bool KlKeyFormatOk(const std::string& k) {
    if (k.size() != 23) return false;
    for (size_t i = 0; i < k.size(); i++) {
        const bool dash = (i == 5 || i == 11 || i == 17);
        const char c = k[i];
        if (dash) { if (c != '-') return false; }
        else if (!((c >= '0' && c <= '9') || (c >= 'A' && c <= 'F'))) return false;
    }
    return true;
}

// ----------------------------------------------------------------------------------------------
//  Device id (hashed ANDROID_ID, 16 hex chars)
// ----------------------------------------------------------------------------------------------
static std::string KlRawAndroidId() {
    if (!VM) return "";
    JNIEnv* env = nullptr;
    bool attached = false;
    if (VM->GetEnv((void**)&env, JNI_VERSION_1_6) != JNI_OK) {
        if (VM->AttachCurrentThread(&env, nullptr) != JNI_OK) return "";
        attached = true;
    }
    std::string result;
    do {
        jclass settingsClass = env->FindClass("android/provider/Settings$Secure");
        if (!settingsClass) break;
        jmethodID getStr = env->GetStaticMethodID(settingsClass, "getString",
            "(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;");
        jclass activityThread = env->FindClass("android/app/ActivityThread");
        if (!getStr || !activityThread) break;
        jmethodID curApp = env->GetStaticMethodID(activityThread, "currentApplication", "()Landroid/app/Application;");
        if (!curApp) break;
        jobject app = env->CallStaticObjectMethod(activityThread, curApp);
        if (!app) break;
        jmethodID getRes = env->GetMethodID(env->GetObjectClass(app), "getContentResolver", "()Landroid/content/ContentResolver;");
        if (!getRes) break;
        jobject cr = env->CallObjectMethod(app, getRes);
        jstring jkey = env->NewStringUTF("android_id");
        jstring jid = (jstring)env->CallStaticObjectMethod(settingsClass, getStr, cr, jkey);
        if (jid) {
            const char* cid = env->GetStringUTFChars(jid, nullptr);
            if (cid) { result = cid; env->ReleaseStringUTFChars(jid, cid); }
        }
        env->DeleteLocalRef(jkey);
    } while (false);
    if (env->ExceptionCheck()) env->ExceptionClear();
    if (attached) VM->DetachCurrentThread();
    return result;
}
static std::string KlDeviceId() {
    if (!g_klDeviceId.empty()) return g_klDeviceId;
    std::string raw = KlRawAndroidId();
    if (raw.empty()) raw = "no-id";
    g_klDeviceId = SHA256Impl::hash(raw + "|dragon-engine|" + "device").substr(0, 16);
    return g_klDeviceId;
}

// ----------------------------------------------------------------------------------------------
//  Firebase REST helpers
// ----------------------------------------------------------------------------------------------
static int64_t KlParseHttpDate(const std::string& date) {
    // "Sun, 06 Nov 1994 08:49:37 GMT"
    if (date.empty()) return 0;
    int day = 0, year = 0, hh = 0, mm = 0, ss = 0;
    char mon[8] = {0};
    if (sscanf(date.c_str(), "%*3s, %d %3s %d %d:%d:%d", &day, mon, &year, &hh, &mm, &ss) != 6) return 0;
    static const char* const names[12] = {"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
    int m = -1;
    for (int i = 0; i < 12; i++) if (strncmp(mon, names[i], 3) == 0) { m = i; break; }
    if (m < 0) return 0;
    struct tm tmv; memset(&tmv, 0, sizeof(tmv));
    tmv.tm_mday = day; tmv.tm_mon = m; tmv.tm_year = year - 1900; tmv.tm_hour = hh; tmv.tm_min = mm; tmv.tm_sec = ss;
    return (int64_t)timegm(&tmv) * 1000;
}

struct KlReply { bool net = false; int status = 0; std::string body; int64_t serverMs = 0; };

static KlReply KlFirebase(const char* method, const std::string& path, const std::string& body = std::string()) {
    KlReply out;
    std::string url = std::string("https://") + O(KL_FIREBASE_HOST) + path;
    JniHttpResult r = JniHttpRequest(VM, method, url, body);
    out.net = r.transportOk; out.status = r.status; out.body = r.body;
    out.serverMs = KlParseHttpDate(r.date);
    return out;
}

static std::string KlJsonEscape(const std::string& s) {
    std::string o;
    for (char c : s) {
        if (c == '"' || c == '\\') { o += '\\'; o += c; }
        else if ((unsigned char)c >= 0x20 && (unsigned char)c < 0x7f) o += c;
    }
    return o;
}

static void KlLoadConfig() {
    KlReply r = KlFirebase("GET", "/config.json");
    if (!r.net || r.status != 200) return;
    nlohmann::json j = nlohmann::json::parse(r.body, nullptr, false);
    if (j.is_discarded() || !j.is_object()) return;
    std::string about;
    std::vector<std::pair<std::string, std::string>> ch;
    if (j.contains("about") && j["about"].is_string()) about = j["about"].get<std::string>();
    if (j.contains("channels")) {
        auto add = [&](const nlohmann::json& it) {
            if (it.is_object() && it.contains("url") && it["url"].is_string()) {
                std::string url = it["url"].get<std::string>();
                if (url.rfind("https://t.me/", 0) != 0) return;
                std::string name = (it.contains("name") && it["name"].is_string()) ? it["name"].get<std::string>() : std::string("Channel");
                ch.emplace_back(name, url);
            }
        };
        const nlohmann::json& c = j["channels"];
        if (c.is_array()) { for (const auto& it : c) add(it); }
        else if (c.is_object()) { for (auto it = c.begin(); it != c.end(); ++it) add(it.value()); }
    }
    std::lock_guard<std::mutex> l(g_klMutex);
    g_klSession.about = about;
    g_klSession.channels = ch;
}

enum KlResult { KL_OK, KL_NET, KL_DENIED_RULES, KL_NOT_FOUND, KL_DISABLED, KL_EXPIRED, KL_LIMIT, KL_BADCFG, KL_DEVICE_GONE };

// Reads the key node and validates it. When 'register_device' is set the device is added (or its last-seen refreshed).
static KlResult KlCheckNode(const std::string& hash, bool register_device, std::string& msg) {
    const std::string dev = KlDeviceId();
    KlReply r = KlFirebase("GET", "/keys/" + hash + ".json");
    if (!r.net) { msg = "No connection to server. Check your internet."; return KL_NET; }
    if (r.status == 401 || r.status == 403) { msg = "Server denied access. Contact admin."; return KL_DENIED_RULES; }
    if (r.status != 200) { char b[64]; snprintf(b, sizeof(b), "Server error (%d)", r.status); msg = b; return KL_NET; }
    if (r.serverMs > 0) {
        struct timespec ts; clock_gettime(CLOCK_REALTIME, &ts);
        g_klOffsetMs = r.serverMs - ((int64_t)ts.tv_sec * 1000 + ts.tv_nsec / 1000000);
    }
    nlohmann::json j = nlohmann::json::parse(r.body, nullptr, false);
    if (j.is_discarded() || j.is_null() || !j.is_object()) { msg = "Invalid key."; return KL_NOT_FOUND; }

    if (j.contains("active") && j["active"].is_boolean() && !j["active"].get<bool>()) { msg = "This key is disabled."; return KL_DISABLED; }

    int64_t expiry = 0;
    if (j.contains("expiry") && j["expiry"].is_number()) {
        expiry = j["expiry"].get<int64_t>();
        if (expiry > 0 && expiry < 100000000000LL) expiry *= 1000;   // seconds -> ms
    }
    const int64_t now = KlNowMs();
    if (expiry > 0 && now >= expiry) { msg = "This key has expired."; return KL_EXPIRED; }

    if (!(j.contains("deviceLimit") && j["deviceLimit"].is_number_integer())) { msg = "Key is not configured (device limit missing)."; return KL_BADCFG; }
    const int limit = j["deviceLimit"].get<int>();
    int used = 0; bool known = false;
    if (j.contains("devices") && j["devices"].is_object()) {
        used = (int)j["devices"].size();
        known = j["devices"].contains(dev);
    }
    if (!known) {
        if (!register_device) { msg = "This device was removed from the key."; return KL_DEVICE_GONE; }
        if (used >= limit) {
            char b[96]; snprintf(b, sizeof(b), "Device limit reached (%d/%d).", used, limit);
            msg = b; return KL_LIMIT;
        }
        char body[256];
        snprintf(body, sizeof(body), "{\"first\":%lld,\"last\":%lld,\"model\":\"android\"}", (long long)now, (long long)now);
        KlReply put = KlFirebase("PUT", "/keys/" + hash + "/devices/" + dev + ".json", body);
        if (!put.net) { msg = "No connection to server. Check your internet."; return KL_NET; }
        if (put.status < 200 || put.status >= 300) { msg = "Device registration refused (limit reached?)."; return KL_LIMIT; }
        used++;
    } else {
        char ts[32]; snprintf(ts, sizeof(ts), "%lld", (long long)now);
        KlFirebase("PUT", "/keys/" + hash + "/devices/" + dev + "/last.json", ts);
    }

    {
        std::lock_guard<std::mutex> l(g_klMutex);
        g_klSession.expiryMs = expiry;
        g_klSession.deviceLimit = limit;
        g_klSession.deviceCount = used;
        g_klSession.createdBy = (j.contains("createdBy") && j["createdBy"].is_string()) ? j["createdBy"].get<std::string>() : std::string();
    }
    return KL_OK;
}

// ----------------------------------------------------------------------------------------------
//  Threads
// ----------------------------------------------------------------------------------------------
static void* KlRecheckThread(void* arg) {
    const int gen = (int)(intptr_t)arg;
    while (true) {
        for (int i = 0; i < KL_RECHECK_SECONDS; i++) {
            sleep(1);
            if (gen != g_klRecheckGen) return nullptr;
        }
        if (gen != g_klRecheckGen) return nullptr;
        std::string msg;
        std::string hash;
        { std::lock_guard<std::mutex> l(g_klMutex); hash = g_klActiveHash; }
        if (hash.empty()) return nullptr;
        KlResult res = KlCheckNode(hash, false, msg);
        if (gen != g_klRecheckGen) return nullptr;
        if (res == KL_NET) continue;                      // network trouble keeps the session
        if (res != KL_OK) { KlRevoke(); KlSetStatus(msg, false); return nullptr; }
    }
}

struct KlVerifyArgs { std::string key; };

static void* KlVerifyThread(void* arg) {
    KlVerifyArgs* va = (KlVerifyArgs*)arg;
    std::string msg;
    const std::string key = KlNormalizeKey(va->key);
    delete va;
    KlRevoke();
    g_klRecheckGen++;

    if (key.empty()) { KlSetStatus("Please enter your license key.", false); g_auth_done = true; return nullptr; }
    if (!KlKeyFormatOk(key)) {
        KlSetStatus("Invalid key format. Use XXXXX-XXXXX-XXXXX-XXXXX", false);
        g_auth_done = true; return nullptr;
    }
    const std::string hash = SHA256Impl::hash(key);
    KlResult res = KlCheckNode(hash, true, msg);
    if (res == KL_OK) {
        KlLoadConfig();
        { std::lock_guard<std::mutex> l(g_klMutex); g_klActiveHash = hash; }
        KlGrant();
        KlSetStatus("Access granted. Welcome!", true);
        pthread_t tid;
        if (pthread_create(&tid, nullptr, KlRecheckThread, (void*)(intptr_t)g_klRecheckGen) == 0) pthread_detach(tid);
    } else {
        if (res == KL_NOT_FOUND) msg = "Invalid key. Tap GET KEY on Telegram.";
        KlSetStatus(msg, false);
    }
    g_auth_done = true;
    return nullptr;
}

// ----------------------------------------------------------------------------------------------
//  Public API used by the UI
// ----------------------------------------------------------------------------------------------
static void StartVerify(const std::string& rawKey) {
    if (g_auth_checking) return;
    g_auth_done = false;
    g_auth_checking = true;
    KlSetStatus("Verifying...", false);
    KlDeviceId();   // compute on the UI thread once, JNI is attached there
    KlVerifyArgs* va = new KlVerifyArgs{rawKey};
    pthread_t tid;
    if (pthread_create(&tid, nullptr, KlVerifyThread, va) == 0) pthread_detach(tid);
    else { delete va; g_auth_checking = false; KlSetStatus("Could not start verification.", false); }
}

// Call every frame; clears the busy flag when the worker finished.
static void PollVerify() {
    if (g_auth_checking && g_auth_done) g_auth_checking = false;
}

static void KlLogout() {
    KlRevoke();
    g_klRecheckGen++;
    std::lock_guard<std::mutex> l(g_klMutex);
    g_klActiveHash.clear();
    g_klSession = KlSession();
}

static std::string KlExpiryText() {
    KlSession s = KlGetSession();
    if (s.expiryMs <= 0) return "Lifetime";
    int64_t left = s.expiryMs - KlNowMs();
    if (left <= 0) return "Expired";
    int64_t mins = left / 60000, hrs = mins / 60, days = hrs / 24;
    char b[64];
    if (days > 0) snprintf(b, sizeof(b), "%lldd %lldh left", (long long)days, (long long)(hrs % 24));
    else snprintf(b, sizeof(b), "%lldh %lldm left", (long long)hrs, (long long)(mins % 60));
    return b;
}

static std::string KlExpiryDate() {
    KlSession s = KlGetSession();
    if (s.expiryMs <= 0) return "Never";
    time_t t = (time_t)(s.expiryMs / 1000);
    struct tm tmv; localtime_r(&t, &tmv);
    char b[64]; strftime(b, sizeof(b), "%d %b %Y, %H:%M", &tmv);
    return b;
}

// Opens a URL in the user's browser / Telegram app.
static void KlOpenUrl(const char* urlC) {
    if (!VM || !urlC) return;
    JNIEnv* env = nullptr;
    bool att = false;
    if (VM->GetEnv((void**)&env, JNI_VERSION_1_6) != JNI_OK) {
        if (VM->AttachCurrentThread(&env, nullptr) != JNI_OK) return;
        att = true;
    }
    do {
        jclass uriClass = env->FindClass("android/net/Uri");
        jclass intentClass = env->FindClass("android/content/Intent");
        jclass atClass = env->FindClass("android/app/ActivityThread");
        if (!uriClass || !intentClass || !atClass) break;
        jmethodID parse = env->GetStaticMethodID(uriClass, "parse", "(Ljava/lang/String;)Landroid/net/Uri;");
        jmethodID ctor = env->GetMethodID(intentClass, "<init>", "(Ljava/lang/String;Landroid/net/Uri;)V");
        jmethodID addFlags = env->GetMethodID(intentClass, "addFlags", "(I)Landroid/content/Intent;");
        jmethodID curApp = env->GetStaticMethodID(atClass, "currentApplication", "()Landroid/app/Application;");
        if (!parse || !ctor || !addFlags || !curApp) break;
        jstring jurl = env->NewStringUTF(urlC);
        jobject uri = env->CallStaticObjectMethod(uriClass, parse, jurl);
        jstring action = env->NewStringUTF("android.intent.action.VIEW");
        jobject intent = env->NewObject(intentClass, ctor, action, uri);
        if (!intent) break;
        env->CallObjectMethod(intent, addFlags, 0x10000000);   // FLAG_ACTIVITY_NEW_TASK
        jobject app = env->CallStaticObjectMethod(atClass, curApp);
        if (!app) break;
        jclass ctxClass = env->FindClass("android/content/Context");
        jmethodID startA = env->GetMethodID(ctxClass, "startActivity", "(Landroid/content/Intent;)V");
        if (startA) env->CallVoidMethod(app, startA, intent);
    } while (false);
    if (env->ExceptionCheck()) env->ExceptionClear();
    if (att) VM->DetachCurrentThread();
}

#endif // DRAGON_KEYLOGIN_H
