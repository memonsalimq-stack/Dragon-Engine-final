/*
 * DARK OWNER ADMIN SERVER
 * Crafted with passion & dedication.
 * Original Credits: DARK OWNER ADMIN SERVER
 * Telegram: @DARK_OWNER_VIP
 * Private Source & Support: DM @DARK_OWNER_VIP
 * Proudly Made for India
 */

#pragma once
#include "include/includes.h"
#include "include/crash_log.h"
#include "game.h"
#include "game/Ruleset.h"
#include "include/java.h"
#include "mod/keylogin.h"
#include "mod/offsets_optional.h"
#include "oxorany/oxorany.h"
#include <EGL/egl.h>
#include <EGL/eglext.h>
#include <GLES3/gl3.h>
#include <sys/system_properties.h>
#include <cstring>
#include <unistd.h>
#include <cstdio>
#include <ctime>
#include <Vector/Vectors.h>
#include <thread>
#include <condition_variable>
#include <imgui/imgui.h>
#include "icons/embedded_images.h"

using namespace ImGui;
using namespace std;

struct MenuState {
    bool isOpen = false;
    int currentTab = 0;
    float sidebarWidth = 750.0f;
    float animProgress = 0.0f;
    float menuAlpha = 0.0f;
    float menuScale = 0.9f;
    ImVec4 accentColor = ImVec4(1.0f, 0.0f, 0.0f, 1.0f);
};
static MenuState g_menu;

// 0=FAST, 1=HUMAN, 2=ULTRA_FAST
static int   g_refAutoPlayMode = 0;
static int   g_refEspLineStyle = 0;
// Skin unlock: memory-side only, persisted per session
static bool  g_skinUnlockEnabled = false;
static float g_refLineThickness = 6.9f;
static float g_refLineOpacity = 0.9f;

// Customizable colors, pocket style and puck highlight (saved in svConfig.txt)
static ImVec4 g_colStrikerLine = ImVec4(1.00f, 0.84f, 0.00f, 1.f);   // striker path
static ImVec4 g_colPieceLine   = ImVec4(0.30f, 0.95f, 1.00f, 1.f);   // other pieces' paths (Classic)
static ImVec4 g_colGlowLine    = ImVec4(0.18f, 0.72f, 1.00f, 1.f);   // Sea Blue Glow style
static ImVec4 g_colMyPuck      = ImVec4(0.20f, 1.00f, 0.30f, 1.f);
static ImVec4 g_colOppPuck     = ImVec4(1.00f, 0.30f, 0.30f, 1.f);
static ImVec4 g_colQueenPuck   = ImVec4(1.00f, 0.25f, 0.65f, 1.f);
static ImVec4 g_colPocket      = ImVec4(1.00f, 0.84f, 0.00f, 1.f);
static bool   g_puckRings      = true;
static int    g_pocketStyle    = 1;   // 0 off, 1 ring, 2 glow, 3 target
static int    g_mySideManual   = 0;   // 0 auto, 1 white, 2 black: used only when the game value is unavailable
static float g_refLineAnim = 0.0f;

static const int64_t EXPIRY_TS = O(1874793600LL);

// DEBUG_BYPASS_LOGIN REMOVED — Firebase verification is mandatory.
// No bypass exists. Keys are SHA-256 hashed and device-bound in Firebase.
// static bool DEBUG_BYPASS_LOGIN = false;  // DELETED FOR SECURITY

static float EaseOutBack(float x) {
    const float c1 = 1.70158f;
    const float c3 = c1 + 1.0f;
    return 1.0f + c3 * powf(x - 1.0f, 3.0f) + c1 * powf(x - 1.0f, 2.0f);
}

static float EaseOutQuart(float x) {
    return 1.0f - powf(1.0f - x, 4.0f);
}

static void DrawGradientRect(ImDrawList* dl, ImVec2 p1, ImVec2 p2, ImU32 col1, ImU32 col2, bool horizontal = true) {
    if (horizontal) {
        dl->AddRectFilledMultiColor(p1, p2, col1, col2, col2, col1);
    } else {
        dl->AddRectFilledMultiColor(p1, p2, col1, col1, col2, col2);
    }
}

static const ImU32 UI_GOLD       = IM_COL32(255, 215, 0, 255);
static const ImU32 UI_GOLD_DARK   = IM_COL32(180, 150, 0, 255);
static const ImU32 UI_GOLD_LIGHT  = IM_COL32(255, 235, 59, 255);
static const ImU32 UI_CREAM       = IM_COL32(42, 42, 42, 255);
static const ImU32 UI_PANEL       = IM_COL32(45, 45, 45, 255);
static const ImU32 UI_PANEL_DARK  = IM_COL32(26, 26, 26, 255);
static const ImU32 UI_TEXT        = IM_COL32(255, 255, 255, 255);
static const ImU32 UI_MUTED       = IM_COL32(112, 83, 45, 255);

static void DrawGoldPanel(ImDrawList* dl, ImVec2 a, ImVec2 b, float rounding = 18.0f) {
    dl->AddRectFilled(a, b, UI_PANEL, rounding);
    dl->AddRect(a, b, IM_COL32(132, 82, 20, 255), rounding, 0, 2.0f);
    dl->AddRect(ImVec2(a.x+3, a.y+3), ImVec2(b.x-3, b.y-3), IM_COL32(236, 196, 105, 220), rounding-3.0f, 0, 1.0f);
}

static void DrawAutoPlayTarget(ImDrawList* dl, ImVec2 center, float r) {
    const ImU32 gold = IM_COL32(151, 94, 18, 255);
    const ImU32 light = IM_COL32(196, 135, 43, 255);
    dl->AddCircle(center, r, gold, 40, 2.2f);
    dl->AddCircle(center, r * 0.56f, light, 40, 2.0f);
    dl->AddCircleFilled(center, r * 0.18f, gold);
    dl->AddLine(ImVec2(center.x-r*1.18f, center.y), ImVec2(center.x-r*0.72f, center.y), gold, 2.0f);
    dl->AddLine(ImVec2(center.x+r*0.72f, center.y), ImVec2(center.x+r*1.18f, center.y), gold, 2.0f);
    dl->AddLine(ImVec2(center.x, center.y-r*1.18f), ImVec2(center.x, center.y-r*0.72f), gold, 2.0f);
    dl->AddLine(ImVec2(center.x, center.y+r*0.72f), ImVec2(center.x, center.y+r*1.18f), gold, 2.0f);
}

static bool SidebarButton(const char* label, GLuint iconTex, bool selected, float width) {
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems) return false;
    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;
    const ImGuiID id = window->GetID(label);
    float iconSize = 46.0f;
    float vPad = 8.0f;
    float btnH = vPad + iconSize + 4.0f + g.FontSize + vPad;
    ImVec2 pos = window->DC.CursorPos;
    ImVec2 size(width, btnH);
    const ImRect bb(pos, pos + size);
    ItemSize(size, style.FramePadding.y);
    if (!ItemAdd(bb, id)) return false;
    bool hovered=false, held=false;
    bool pressed=ButtonBehavior(bb,id,&hovered,&held);
    ImDrawList* dl=window->DrawList;
    if (selected) {
        dl->AddRectFilled(bb.Min, bb.Max, UI_GOLD, 12.0f);
        dl->AddRect(bb.Min, bb.Max, IM_COL32(255,236,173,180), 12.0f, 0, 1.5f);
    } else if (hovered) {
        dl->AddRectFilled(bb.Min, bb.Max, IM_COL32(190,145,70,75), 12.0f);
    }
    ImVec2 center(bb.Min.x + width*0.5f, bb.Min.y + vPad + iconSize*0.5f);
    if (iconTex) {
        ImVec2 mn(center.x-iconSize*0.5f,center.y-iconSize*0.5f);
        ImVec2 mx(center.x+iconSize*0.5f,center.y+iconSize*0.5f);
        dl->AddImage((void*)(intptr_t)iconTex,mn,mx,ImVec2(0,0),ImVec2(1,1));
    }
    ImVec2 labelSize=CalcTextSize(label);
    ImVec2 textPos(bb.Min.x+(width-labelSize.x)*0.5f,bb.Min.y+vPad+iconSize+4.0f);
    dl->AddText(textPos,selected?IM_COL32(255,248,225,255):UI_TEXT,label);
    return pressed;
}

static bool ToggleSwitch(const char* label, bool* v) {
    ImGuiWindow* window=GetCurrentWindow();
    if(window->SkipItems) return false;
    ImGuiContext& g=*GImGui;
    const ImGuiID id=window->GetID(label);
    float height=28.0f, width=54.0f, radius=height*0.5f;
    ImVec2 textSize=CalcTextSize(label);
    ImVec2 pos=window->DC.CursorPos;
    ImVec2 size(GetContentRegionAvail().x, ImMax(height,textSize.y)+14.0f);
    ImRect bb(pos,pos+size);
    ItemSize(size,g.Style.FramePadding.y);
    if(!ItemAdd(bb,id)) return false;
    bool hovered=false,held=false;
    bool pressed=ButtonBehavior(bb,id,&hovered,&held);
    if(pressed)*v=!*v;
    static std::map<ImGuiID,float> anim;
    float &t=anim[id];
    float target=*v?1.0f:0.0f;
    t+=(target-t)*g.IO.DeltaTime*14.0f;
    ImDrawList* dl=window->DrawList;
    if(hovered) dl->AddRectFilled(bb.Min,bb.Max,IM_COL32(126,87,34,32),10.0f);
    ImVec2 togglePos(bb.Max.x-width-12.0f,bb.Min.y+(size.y-height)*0.5f);
    ImVec2 toggleEnd(togglePos.x+width,togglePos.y+height);
    ImVec4 off=ImVec4(0.2f,0.2f,0.2f,1.0f);
    ImVec4 on =ImVec4(1.0f,0.84f,0.0f,1.0f);
    dl->AddRectFilled(togglePos,toggleEnd,ImColor(ImLerp(off,on,t)),radius);
    dl->AddRect(togglePos,toggleEnd,IM_COL32(60,60,60,180),radius,0,1.0f);
    float knobX=togglePos.x+radius+(width-height)*t;
    float knobY=togglePos.y+radius;
    dl->AddCircleFilled(ImVec2(knobX+1,knobY+1),radius-3,IM_COL32(0,0,0,55));
    dl->AddCircleFilled(ImVec2(knobX,knobY),radius-4,IM_COL32(255,250,232,255));
    dl->AddText(ImVec2(bb.Min.x+12.0f,bb.Min.y+(size.y-textSize.y)*0.5f),UI_TEXT,label);
    return pressed;
}

static bool g_aqCounting = false;
static std::chrono::steady_clock::time_point g_aqLastCall;
static std::chrono::steady_clock::time_point g_aqCountdownStart;

static bool IsExpired() {
    return false;   // per-key expiry is enforced by NovaEngine_IsLoggedIn()
}

INLINE void DrawExpired(ImGuiIO& io) {
    float winW = g_menu.sidebarWidth;

    SetNextWindowPos(ImVec2(io.DisplaySize.x * 0.5f, io.DisplaySize.y * 0.5f), ImGuiCond_Always, ImVec2(0.5f, 0.5f));
    SetNextWindowSize(ImVec2(winW, 0), ImGuiCond_Always);
    PushStyleColor(ImGuiCol_WindowBg, IM_COL32(18, 18, 18, 255));
    PushStyleVar(ImGuiStyleVar_WindowRounding, 20.0f);
    PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(30.0f, 30.0f));
    PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);

    if (Begin(O("##ExpiredWin"), nullptr,
              ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove |
              ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoSavedSettings |
              ImGuiWindowFlags_AlwaysAutoResize)) {

        SetWindowFontScale(1.6f);
        ImVec2 titleSz = CalcTextSize(O("DRAGON ENGINE - LICENSE EXPIRED"));
        SetCursorPosX((winW - 60.0f - titleSz.x) * 0.5f);
        TextColored(ImVec4(1.0f, 0.1f, 0.1f, 1.0f), "%s", O("DRAGON ENGINE - LICENSE EXPIRED"));
        SetWindowFontScale(1.0f);

        Dummy(ImVec2(0, 16));

        PushTextWrapPos(GetCursorPosX() + winW - 60.0f);
        TextColored(ImVec4(0.85f, 0.85f, 0.90f, 1.0f), "%s",
            O("Beta Version Expired. Update on our Telegram Your Id"));
        PopTextWrapPos();

        Dummy(ImVec2(0, 10));
    }
    End();
    PopStyleVar(3);
    PopStyleColor();
}

INLINE void DrawAutoQueue() {
    AutoQueueTick();
    if (NovaEngine_IsLoggedIn()) {
        auto now = std::chrono::steady_clock::now();

        static bool hasStartedOnce = false;
        static auto lastStart = std::chrono::steady_clock::now() - std::chrono::milliseconds(2500);
        const auto sinceStart = std::chrono::duration_cast<std::chrono::milliseconds>(now - lastStart).count();
        if (hasStartedOnce && sinceStart < 2500) return;

        if (std::chrono::duration_cast<std::chrono::milliseconds>(now - g_aqLastCall).count() > 500)
            g_aqCounting = false;
        g_aqLastCall = now;

        if (!g_aqCounting) {
            g_aqCounting = true;
            g_aqCountdownStart = now;
        }

        auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(now - g_aqCountdownStart).count();
        const int countdown_ms = 1200;
        int remaining_ms = countdown_ms - (int)elapsed;

        if (remaining_ms <= 0) {
            StartAutoQueue();
            lastStart = now;
            hasStartedOnce = true;
            g_aqCounting = false;
            g_aqLastCall = now;
            return;
        }

        std::string count_str = std::to_string((remaining_ms + 999) / 1000);

        SetNextWindowPos(ImVec2(Width * 0.5f, Height * 0.5f), ImGuiCond_Always, ImVec2(0.5f, 0.5f));
        PushStyleColor(ImGuiCol_WindowBg, ImVec4(0, 0, 0, 1.f));
        PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(32.0f, 20.0f));
        PushStyleVar(ImGuiStyleVar_WindowRounding, 24.0f);

        if (Begin(O("##AutoQueueCD"), nullptr,
                  ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove |
                  ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoSavedSettings |
                  ImGuiWindowFlags_AlwaysAutoResize)) {
            ImDrawList* dl  = GetWindowDrawList();
            ImVec2      wp  = GetWindowPos();
            ImVec2      ws  = GetWindowSize();
            dl->AddRectFilled(wp, ImVec2(wp.x + ws.x, wp.y + ws.y), IM_COL32(20, 20, 28, 0), 24.0f);

            SetWindowFontScale(3.5f);
            TextColored(ImVec4(1.f, 0.f, 0.f, 1.0f), "%s", count_str.c_str());
            SetWindowFontScale(1.0f);
        }
        End();
        PopStyleVar(2);
        PopStyleColor();
    }
}

#include "mod/ButtonClicker.h"

static void DrawToggleButton(bool cancelMode);

extern volatile bool g_autoQueueEnabled;

extern char g_espLastReason[160];

static struct SimWorker {
    std::mutex mtx;
    std::condition_variable cv;
    double reqAngle = 0.0, reqPower = 0.0;
    uint64_t reqVer = 0, servedVer = 0;
    bool started = false;
    std::thread th;
    int snapCount = 0;
    Prediction::PieceState snapPieces[MAX_PIECES_COUNT];
    void start() {
        if (started) return;
        started = true;
        th = std::thread([this]{
            for (;;) {
                double a, p;
                { std::unique_lock<std::mutex> lk(mtx);
                  cv.wait(lk, [&]{ return reqVer > servedVer; });
                  a = reqAngle; p = reqPower; servedVer = reqVer; }
                if (gPrediction) {
                    gPrediction->determineShotResult(false, a, p);
                    std::lock_guard<std::mutex> lk(mtx);
                    snapCount = gPrediction->guiData.piecesCount;
                    if (snapCount > MAX_PIECES_COUNT) snapCount = MAX_PIECES_COUNT;
                    for (int i = 0; i < snapCount; i++)
                        snapPieces[i] = gPrediction->guiData.pieces[i];
                }
            }
        });
        th.detach();
    }
    void submit(double a, double p) {
        if (!started) start();
        { std::lock_guard<std::mutex> lk(mtx); reqAngle = a; reqPower = p; reqVer++; }
        cv.notify_one();
    }
} s_simWorker;

inline void esp_status_impl(const char* line) {
    static const char* lastReason = "";
    static int lastLogMs = 0;
    auto nowMs = (int)(std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::steady_clock::now().time_since_epoch()).count() % 1000000000);
    bool changed = strcmp(lastReason, line) != 0;
    if (changed || nowMs - lastLogMs > 5000) {

        bug_log_write("ESP: %s", line);
        lastReason = line;
        lastLogMs = nowMs;

        snprintf(g_espLastReason, sizeof(g_espLastReason), "%s", line);
    }
}
inline void esp_status(const char* reason) { esp_status_impl(reason); }
inline void esp_status_id(const char* reason, int id) {
    char buf[96]; snprintf(buf, sizeof(buf), "%s %d", reason, id); esp_status_impl(buf);
}

extern struct CachedGameState g_cgs;
static uint64_t esp_now_ms() {
    return (uint64_t)std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::steady_clock::now().time_since_epoch()).count();
}

volatile int g_espStep = 0;
const char* g_espStepName = "frame start";
#define ESP_STEP(n, name) do { g_espStep = (n); g_espStepName = (name); } while(0)

INLINE void DrawESP(ImDrawList* draw) {
    if (NovaEngine_IsLoggedIn()) {
        ESP_STEP(1, "g_cgs.gameManager check (.so 0x5ce0ff8)");
        if (!g_cgs.gameManager) { esp_status("stop: gameManager null (gameUpdateHook not fired)"); return; }

        ESP_STEP(2, "UpdateScreenTable");
        UpdateScreenTable(Width, Height);

        ESP_STEP(3, "lobby check (.so: frame piece count == 0)");

        if (g_cgs.framePieceCount == 0 || !g_cgs.frameDataValid) {
            esp_status("lobby mode (overlayFrame returned no pieces) — AutoQueue branch");
            g_autoQueueEnabled = persistent_bool[O("bAutoQueue")];

            g_bridgeActive2 = g_autoQueueEnabled;
            if (persistent_bool[O("bAutoQueue")]) DrawAutoQueue();
            return;
        }

        ESP_STEP(4, "stateId from cache (no stateStack walk)");
        auto stateId = g_cgs.stateId;
        if (g_cgs.playerTurn && gPrediction) {

            if (g_CurrentCandidate.idx < 0 && g_cgs.aimValid && g_cgs.gameManager) {
                static double lastEspScan = 0.0;
                double now = ImGui::GetTime();
                if (now - lastEspScan > 1.5) {
                    lastEspScan = now;
                    AutoPlay::ScanFast();
                }
            }
            if (g_CurrentCandidate.idx >= 0) {

                static int lastCandIdx = -1;
                static double lastRenderT = 0.0;

                double nowR = ImGui::GetTime();

                g_GameTrScreenH = (double)ImGui::GetIO().DisplaySize.y;
                static double lastAimAng = -99.0;
                static double s_liveAng = -100.0, s_livePow = 0.5;
                bool dragging = g_AimTouchActive && g_GameTrValid && g_cgs.aimValid;
                if (dragging) {
                    double ox = g_GameTrOrigin[0], oy = g_GameTrOrigin[1];
                    double ax = g_GameTrVecX[0],  ay = g_GameTrVecX[1];
                    double bx = g_GameTrVecY[0],  by = g_GameTrVecY[1];
                    double det = ax*by - ay*bx;
                    if (det != 0.0) {

                        double dx = (double)g_AimTouchX - ox;
                        double dy = (g_GameTrScreenH - (double)g_AimTouchY) - oy;
                        double fw_x = (dx*by - dy*bx) / det;
                        double fw_y = (dy*ax - dx*ay) / det;
                        Vec2d strikerW(g_cgs.aimAngle, g_cgs.aimPower);
                        double ddx = strikerW.x - fw_x, ddy = strikerW.y - fw_y;
                        double ang = std::atan2(ddy, ddx);

        ImVec2 spx = WorldToScreen(strikerW);
        double pdx = (double)g_AimTouchX - spx.x;
        double pdy = (double)g_AimTouchY - spx.y;
        double dist = std::sqrt(pdx*pdx + pdy*pdy);
                        if (std::fabs(ang - lastAimAng) > 0.01 || nowR - lastRenderT > 0.25) {
                            lastAimAng = ang; lastRenderT = nowR;
                            float ph = ImGui::GetIO().DisplaySize.y;
                            if (ph <= 0.f) ph = 1080.f;
                            double ratio = dist / (0.30 * (double)ph);
                            if (ratio < 0.10) ratio = 0.10;
                            if (ratio > 1.0)  ratio = 1.0;
                            s_liveAng = ang; s_livePow = ratio;
                            s_simWorker.submit(ang, ratio);
                        }
                    }
                } else if (g_CurrentCandidate.idx != -1 &&
                           (g_CurrentCandidate.idx != lastCandIdx || nowR - lastRenderT > 0.5)) {
                    lastAimAng = -99.0;
                    lastCandIdx = g_CurrentCandidate.idx;
                    lastRenderT = nowR;
                    s_liveAng = g_CurrentCandidate.angle; s_livePow = g_CurrentCandidate.power;
                    s_simWorker.submit(g_CurrentCandidate.angle, g_CurrentCandidate.power);
                } else if (nowR - lastRenderT > 0.5) {

                    if (s_liveAng < -90.0) {
                        Vec2d sw2(g_cgs.aimAngle, g_cgs.aimPower);
                        s_liveAng = std::atan2(0.0 - sw2.y, 0.0 - sw2.x);
                        s_livePow = 0.5;
                    }
                    lastRenderT = nowR;
                    s_simWorker.submit(s_liveAng, s_livePow);
                }
            }
        }
        if (!g_cgs.playerTurn) {
            esp_status_id("wait: stateId= (rolling/opponent turn)", stateId);
            return;
        }
        if (gPrediction && gPrediction->guiData.piecesCount == 0 && !g_cgs.playerTurn) {
            esp_status_id("no prediction data: stateId=", stateId);
        }

        ESP_STEP(11, "mBoard from cache (g_cgs.board) — .so 0x5ce0ff8+8");
        Board table = g_cgs.board;
        if (!table) { esp_status("stop: board null (cached from gameUpdateHook)"); return; }

        ESP_STEP(14, "mBoardProperties read");
        auto tableProperties = table.mBoardProperties();

        if (!tableProperties) { esp_status("DRAWING (boardProps null — pocket circles off)"); }

        ESP_STEP(15, "mPockets read");
        auto& pockets = tableProperties.mPockets();

        ESP_STEP(19, "ESP draw loops");
        esp_status_id("DRAWING ESP stateId=", stateId);
        g_GameTrScreenH = (double)ImGui::GetIO().DisplaySize.y;
        esp_status_id("TRF valid=", g_GameTrValid);

        if (persistent_bool[O("bESP_DrawPredictionLine")]) {

            std::lock_guard<std::mutex> s_lk(s_simWorker.mtx);
            int s_n = s_simWorker.snapCount;
            for (int i = 0; i < s_n; i++) {
                auto& piece = s_simWorker.snapPieces[i];

                if (piece.initialPosition != piece.predictedPosition && piece.positions.size() > 1) {

    float lineThick = (float)persistent_int[O("iLineThickness")];
                    float lineAlpha = persistent_float[O("fLineOpacity")];
                    if (lineThick < 1.f) lineThick = 1.f;
                    if (lineAlpha <= 0.f) lineAlpha = 1.f;
                    if (lineAlpha > 1.f) lineAlpha = 1.f;

                    ImColor lineColor;
                    if (g_refEspLineStyle == 0) {

                        lineColor = (i == 0)
                            ? ImColor(g_colStrikerLine.x, g_colStrikerLine.y, g_colStrikerLine.z, lineAlpha)
                            : ImColor(g_colPieceLine.x, g_colPieceLine.y, g_colPieceLine.z, lineAlpha);
                    } else {

                        lineColor = ImColor(g_colGlowLine.x, g_colGlowLine.y, g_colGlowLine.z, lineAlpha);
                    }

                    if (i == 0) lineThick += 1.0f;

                    auto clampBoard = [](ImVec2 p) {
                        float maxX = ImGui::GetIO().DisplaySize.x;
                        float maxY = ImGui::GetIO().DisplaySize.y;
                        if (p.x < 0) p.x = 0; if (p.x > maxX) p.x = maxX;
                        if (p.y < 0) p.y = 0; if (p.y > maxY) p.y = maxY;
                        return p;
                    };
                    ImVec2 firstPos = clampBoard(WorldToScreen(piece.positions[0]));
                    if (i == 0) {

                        auto drawDotted = [&](ImVec2 a, ImVec2 b) {
                            ImVec2 d(b.x - a.x, b.y - a.y);
                            float len = sqrtf(d.x * d.x + d.y * d.y);
                            if (len < 2.f) return;
                            d.x /= len; d.y /= len;
                            float t = 0.f; bool on = true;
                            while (t < len) {
                                float step = on ? 8.f : 7.f;
                                if (t + step > len) step = len - t;
                                if (on)
                                    draw->AddLine(ImVec2(a.x + d.x * t, a.y + d.y * t),
                                                  ImVec2(a.x + d.x * (t + step), a.y + d.y * (t + step)),
                                                  lineColor, lineThick * 0.8f);
                                t += step; on = !on;
                            }
                        };
                        ImVec2 lastPos = firstPos;
                        for (int j = 1; j < (int)piece.positions.size(); j++) {
                            auto point = clampBoard(WorldToScreen(piece.positions[j]));
                            if (j == 1) draw->AddLine(lastPos, point, lineColor, lineThick);
                            else        drawDotted(lastPos, point);
                            lastPos = point;
                        }
                        int pn = (int)piece.positions.size();
                        if (pn >= 2) {
                            Vec2d a = piece.positions[pn - 2], b = piece.positions[pn - 1];
                            Vec2d dirv(b.x - a.x, b.y - a.y);
                            double dl = std::sqrt(dirv.x * dirv.x + dirv.y * dirv.y);
                            if (dl > 1e-6) {
                                dirv.x /= dl; dirv.y /= dl;
                                Vec2d ext(b.x + dirv.x * 80.0, b.y + dirv.y * 80.0);
                                drawDotted(lastPos, clampBoard(WorldToScreen(ext)));
                            }
                        }
                        if (pn >= 2) {
                            ImVec2 p1 = clampBoard(WorldToScreen(piece.positions[1]));
                            ImVec2 d(p1.x - firstPos.x, p1.y - firstPos.y);
                            float dl2 = sqrtf(d.x * d.x + d.y * d.y);
                            if (dl2 > 4.f) {
                                d.x /= dl2; d.y /= dl2;
                                ImVec2 tip(firstPos.x + d.x * 44.f, firstPos.y + d.y * 44.f);
                                ImVec2 n(-d.y, d.x);
                                draw->AddTriangleFilled(tip,
                                    ImVec2(tip.x - d.x * 14.f + n.x * 6.f, tip.y - d.y * 14.f + n.y * 6.f),
                                    ImVec2(tip.x - d.x * 14.f - n.x * 6.f, tip.y - d.y * 14.f - n.y * 6.f),
                                    lineColor);
                            }
                        }
                    } else {

                        ImVec2 lastPos = firstPos;
                        for (int j = 1; j < (int)piece.positions.size(); j++) {
                            auto point = clampBoard(WorldToScreen(piece.positions[j]));
                            draw->AddLine(lastPos, point, lineColor, lineThick);
                            draw->AddCircle(point, lineThick + 2.0f, lineColor, 10, 1.6f);
                            lastPos = point;
                        }
                    }

                    if (i != 0) {
                        int pn = (int)piece.positions.size();
                        draw->AddCircle(clampBoard(WorldToScreen(piece.positions[0])),
                                        lineThick + 2.0f, lineColor, 12, 2.0f);
                        draw->AddCircle(clampBoard(WorldToScreen(piece.positions[pn-1])),
                                        lineThick + 2.0f, lineColor, 12, 2.0f);
                    }
                }
            }
        }

        if ((g_pocketStyle != 0 || g_puckRings) && gPrediction) {
            const int mySide = (g_cgs.targetPiece == 0 || g_cgs.targetPiece == 1) ? (int)g_cgs.targetPiece
                             : (g_mySideManual == 1 ? 0 : (g_mySideManual == 2 ? 1 : -1));
            auto screenR = [](Vec2d c, double r) {
                ImVec2 a = WorldToScreen(c), b = WorldToScreen(Vec2d(c.x + r, c.y));
                float dx = a.x - b.x, dy = a.y - b.y;
                return sqrtf(dx * dx + dy * dy);
            };
            const int nPieces = gPrediction->guiData.piecesCount;
            if (g_pocketStyle != 0) {
                bool potted[BOARD_POCKETS_COUNT] = {}, foul[BOARD_POCKETS_COUNT] = {};
                for (int i = 0; i < nPieces; i++) {
                    auto& pc = gPrediction->guiData.pieces[i];
                    if (pc.originalOnTable && pc.state == CarromPieceEnums::State::IN_POCKET &&
                        pc.pocketIndex >= 0 && pc.pocketIndex < BOARD_POCKETS_COUNT) {
                        if (pc.classification == CarromPieceEnums::Type::STRIKER) foul[pc.pocketIndex] = true;
                        else potted[pc.pocketIndex] = true;
                    }
                }
                const auto& pk = getPockets();
                const double pr = std::sqrt(POCKET_RADIUS_SQUARE);
                for (int k = 0; k < BOARD_POCKETS_COUNT; k++) {
                    Vec2d c(pk[k].x, pk[k].y);
                    ImVec2 sc = WorldToScreen(c);
                    float r = screenR(c, pr);
                    if (r < 4.f || r > 400.f) continue;
                    bool hot = potted[k] || foul[k];
                    ImVec4 base = foul[k] ? ImVec4(1.f, 0.15f, 0.15f, 1.f) : g_colPocket;
                    ImU32 line = ImColor(base.x, base.y, base.z, hot ? 1.0f : 0.45f);
                    ImU32 fill = ImColor(base.x, base.y, base.z, hot ? 0.40f : 0.12f);
                    float th = hot ? 3.0f : 1.5f;
                    if (g_pocketStyle == 2) draw->AddCircleFilled(sc, r, fill, 32);
                    draw->AddCircle(sc, r, line, 32, th);
                    if (g_pocketStyle == 3) {
                        draw->AddLine(ImVec2(sc.x - r * 1.3f, sc.y), ImVec2(sc.x + r * 1.3f, sc.y), line, th * 0.7f);
                        draw->AddLine(ImVec2(sc.x, sc.y - r * 1.3f), ImVec2(sc.x, sc.y + r * 1.3f), line, th * 0.7f);
                    }
                }
            }
            if (g_puckRings) {
                for (int i = 0; i < nPieces; i++) {
                    auto& pc = gPrediction->guiData.pieces[i];
                    if (!pc.originalOnTable) continue;
                    ImVec4 col;
                    if (pc.classification == CarromPieceEnums::Type::QUEEN) col = g_colQueenPuck;
                    else if (pc.classification == CarromPieceEnums::Type::WHITE_PUCK ||
                             pc.classification == CarromPieceEnums::Type::BLACK_PUCK) {
                        if (mySide < 0) continue;
                        col = ((int)pc.classification == mySide) ? g_colMyPuck : g_colOppPuck;
                    } else continue;
                    Vec2d c(pc.initialPosition.x, pc.initialPosition.y);
                    float r = screenR(c, pc.getRadius());
                    if (r < 3.f || r > 200.f) continue;
                    draw->AddCircle(WorldToScreen(c), r + 2.0f, ImColor(col.x, col.y, col.z, 0.95f), 24, 2.5f);
                }
            }
        }

        if (persistent_bool[O("bESP_DrawPredictionLine")]) {
            for (int i = 0; i < gPrediction->guiData.piecesCount; i++) {
                auto& piece = gPrediction->guiData.pieces[i];

                if (piece.initialPosition != piece.predictedPosition) {
                    float circleR = g_refLineThickness + 1.f;
                    if (circleR < 2.f) circleR = 2.f;

                    ImColor yellow(1.0f, 0.84f, 0.0f, 1.0f);
                    ImColor white(1.0f, 1.0f, 1.0f, 0.7f);
                    draw->AddCircleFilled(WorldToScreen(piece.initialPosition), circleR, yellow);
                    draw->AddCircleFilled(WorldToScreen(piece.predictedPosition), 16, white);
                }
            }
        }
    } else {

        esp_status("stop: AUTH GATE CLOSED — keylogin not passed (g_Token/g_Auth empty or mismatch). Check KEYLOGIN line in Bug.txt");
    }
}

static void DrawSidebar(float sidebarW) {
    static GLuint draw_icon_tex = LoadTextureFromMemory(embedded_assets::drawIcon.data, embedded_assets::drawIcon.size);
    static GLuint play_icon_tex = LoadTextureFromMemory(embedded_assets::playIcon.data, embedded_assets::playIcon.size);
    static GLuint q_icon_tex    = LoadTextureFromMemory(embedded_assets::questionIcon.data, embedded_assets::questionIcon.size);
    static GLuint user_icon_tex = LoadTextureFromMemory(embedded_assets::userIcon.data, embedded_assets::userIcon.size);

    ImGuiContext& g  = *GImGui;
    ImDrawList*   dl = GetWindowDrawList();
    ImVec2        wp = GetWindowPos();

    float closeSize = 35.0f;
    float closeBtnW = 70.0f;
    float tabsW     = sidebarW - closeBtnW;
    float btnW      = tabsW / 4.0f;
    float marginB   = 12.0f;

    dl->ChannelsSplit(2);
    dl->ChannelsSetCurrent(1);

    BeginGroup();
    SetCursorPos(ImVec2(0.0f, 0.0f));

    float btnW4 = tabsW / 4.0f;
    if (SidebarButton(O("COMBAT"),  draw_icon_tex, g_menu.currentTab == 0, btnW4)) g_menu.currentTab = 0;
    SameLine(0, 0);
    if (SidebarButton(O("VISUAL"),  play_icon_tex, g_menu.currentTab == 1, btnW4)) g_menu.currentTab = 1;
    SameLine(0, 0);
    if (SidebarButton(O("TOOL"),    q_icon_tex,    g_menu.currentTab == 2, btnW4)) g_menu.currentTab = 2;
    SameLine(0, 0);
    if (SidebarButton(O("ABOUT"),   user_icon_tex, g_menu.currentTab == 3, btnW4)) g_menu.currentTab = 3;
    EndGroup();

    float sidebarH = GetItemRectMax().y - wp.y;

    dl->ChannelsSetCurrent(0);
    dl->AddRectFilled(wp, ImVec2(wp.x + sidebarW, wp.y + sidebarH), IM_COL32(26, 26, 26, 245), 18.0f);
    dl->AddRect(wp, ImVec2(wp.x + sidebarW, wp.y + sidebarH), IM_COL32(255, 215, 0, 220), 18.0f, 0, 1.5f);
    dl->ChannelsMerge();

    float sepX       = wp.x + sidebarW - closeBtnW;
    float sepCenterY = wp.y + sidebarH * 0.5f;
    float sepHalfH   = sidebarH * 0.28f;
    dl->AddLine(
        ImVec2(sepX, sepCenterY - sepHalfH),
        ImVec2(sepX, sepCenterY + sepHalfH),
        IM_COL32(236, 196, 105, 180), 1.5f
    );

    float closePosX = (sidebarW - closeBtnW) + (closeBtnW - closeSize) * 0.5f;
    float closePosY = (sidebarH - closeSize) * 0.5f;
    SetCursorPos(ImVec2(closePosX, closePosY));
    {
        ImGuiWindow* win = GetCurrentWindow();
        ImGuiID closeId  = win->GetID(O("##CloseMenu"));
        ImVec2 closePos  = win->DC.CursorPos;
        ImRect closeBb(closePos, closePos + ImVec2(closeSize, closeSize));
        ItemSize(ImVec2(closeSize, closeSize), g.Style.FramePadding.y);
        ItemAdd(closeBb, closeId);
        bool closeHovered = false, closeHeld = false;
        bool closePressed = ButtonBehavior(closeBb, closeId, &closeHovered, &closeHeld);
        if (closePressed) g_menu.isOpen = false;

        float xCX = closeBb.Min.x + closeSize * 0.5f;
        float xCY = closeBb.Min.y + closeSize * 0.5f;
        float xH  = closeSize * 0.32f;
        ImU32 xCol = closeHovered ? IM_COL32(255, 255, 255, 240) : IM_COL32(160, 160, 170, 200);
        dl->AddLine(ImVec2(xCX - xH, xCY - xH), ImVec2(xCX + xH, xCY + xH), xCol, 2.2f);
        dl->AddLine(ImVec2(xCX + xH, xCY - xH), ImVec2(xCX - xH, xCY + xH), xCol, 2.2f);
    }

    SetCursorPos(ImVec2(0.0f, sidebarH));
    Dummy(ImVec2(sidebarW, marginB));
}

static std::string ReadNSString(ptr str) {
    if (!str) return "null";
    int32_t len = F(int32_t, str + 0x10);
    if (len <= 0 || len > 512) return "?";
    std::string result;
    result.reserve(len);
    for (int32_t i = 0; i < len; i++) {
        uint16_t ch = F(uint16_t, str + 0x14 + i * 2);
        result += (ch > 0 && ch < 128) ? (char)ch : '?';
    }
    return result;
}

static float g_menuX = 108.0f;
static float g_menuY = 435.0f;
static float g_menuW = 540.0f;
static float g_menuH = 560.0f;

static float g_playBtnX = 54.0f;
static float g_playBtnY = 252.0f;
static float g_playBtnSize = 90.0f;

static float g_logoBtnX = 48.0f;
static float g_logoBtnY = 128.0f;
static float g_logoBtnSize = 100.0f;

static float g_toggleRotAngle = 0.0f;

static bool  g_autoPlayCalculating = false;

struct SvColorEntry { const char* key; ImVec4* v; };
static const std::array<SvColorEntry, 7>& svColorTable() {
    static const std::array<SvColorEntry, 7> t = {{
        {"cStrikerLine", &g_colStrikerLine}, {"cPieceLine", &g_colPieceLine}, {"cGlowLine", &g_colGlowLine},
        {"cMyPuck", &g_colMyPuck}, {"cOppPuck", &g_colOppPuck}, {"cQueenPuck", &g_colQueenPuck},
        {"cPocket", &g_colPocket}}};
    return t;
}

static void svConfig_Save() {
    std::string path = O("/data/user/0/") + PACKAGE_NAME + O("/files/svConfig.txt");
    FILE* f = fopen(path.c_str(), O("w"));
    if (!f) return;
    fprintf(f, O("iLineThickness=%d\n"),  persistent_int[O("iLineThickness")]);
    fprintf(f, O("iMenuSizeOffset=%d\n"), persistent_int[O("iMenuSizeOffset")]);
    for (const auto& c : svColorTable()) fprintf(f, "%s=%.3f,%.3f,%.3f\n", c.key, c.v->x, c.v->y, c.v->z);
    fprintf(f, "bPuckRings=%d\niPocketStyle=%d\niMySide=%d\n", g_puckRings ? 1 : 0, g_pocketStyle, g_mySideManual);
    fclose(f);
}
static void svConfig_Load() {
    std::string path = O("/data/user/0/") + PACKAGE_NAME + O("/files/svConfig.txt");
    FILE* f = fopen(path.c_str(), O("r"));
    if (!f) return;
    char line[64];
    while (fgets(line, sizeof(line), f)) {
        int v = 0;
        if (sscanf(line, O("iLineThickness=%d"),  &v) == 1) { persistent_int[O("iLineThickness")]  = v; continue; }
        if (sscanf(line, O("iMenuSizeOffset=%d"), &v) == 1) { persistent_int[O("iMenuSizeOffset")] = v; continue; }
        if (sscanf(line, "bPuckRings=%d", &v) == 1) { g_puckRings = (v != 0); continue; }
        if (sscanf(line, "iPocketStyle=%d", &v) == 1) { g_pocketStyle = ImClamp(v, 0, 3); continue; }
        if (sscanf(line, "iMySide=%d", &v) == 1) { g_mySideManual = ImClamp(v, 0, 2); continue; }
        for (const auto& c : svColorTable()) {
            size_t kl = strlen(c.key);
            float r, g, b;
            if (strncmp(line, c.key, kl) == 0 && line[kl] == '=' &&
                sscanf(line + kl + 1, "%f,%f,%f", &r, &g, &b) == 3) {
                c.v->x = ImClamp(r, 0.f, 1.f); c.v->y = ImClamp(g, 0.f, 1.f); c.v->z = ImClamp(b, 0.f, 1.f);
                break;
            }
        }
    }
    fclose(f);
}

static void DrawCalculating(ImGuiIO& io) {

    SetNextWindowPos(ImVec2(Width * 0.5f, Height * 0.5f), ImGuiCond_Always, ImVec2(0.5f, 0.5f));

    PushStyleColor(ImGuiCol_WindowBg, IM_COL32(18, 18, 18, 255));
    PushStyleColor(ImGuiCol_Border, IM_COL32(220, 30, 30, 255));
    PushStyleVar(ImGuiStyleVar_WindowRounding, 18.0f);
    PushStyleVar(ImGuiStyleVar_WindowBorderSize, 2.0f);

    if (Begin(O("##CalcOverlay"), nullptr,
              ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize |
              ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoScrollbar |
              ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoInputs)) {

        SetWindowFontScale(1.4f);
        TextColored(ImVec4(1.0f, 1.0f, 1.0f, 1.0f), O("CALCULATING..."));
        SetWindowFontScale(1.0f);
    }
    End();
    PopStyleVar(2);
    PopStyleColor(2);
}

// ---------------------------------------------------------------------------------------------
//  Smooth-UI helpers
// ---------------------------------------------------------------------------------------------
static ImU32 UiLerpCol(ImU32 a, ImU32 b, float t) {
    ImVec4 x = ColorConvertU32ToFloat4(a), y = ColorConvertU32ToFloat4(b);
    return ColorConvertFloat4ToU32(ImVec4(x.x + (y.x - x.x) * t, x.y + (y.y - x.y) * t,
                                          x.z + (y.z - x.z) * t, x.w + (y.w - x.w) * t));
}
// Eases a stored float toward 'target' (first call snaps to it, so nothing animates on first draw).
static float UiAnim(ImGuiID id, float target, float speed = 16.0f) {
    ImGuiStorage* st = GetStateStorage();
    float v = st->GetFloat(id, target);
    v += (target - v) * ImMin(1.0f, GetIO().DeltaTime * speed);
    if (fabsf(target - v) < 0.002f) v = target;
    st->SetFloat(id, v);
    return v;
}

static float g_scrollTarget[4] = {0, 0, 0, 0};
static float g_scrollShown[4]  = {0, 0, 0, 0};
static float g_scrollMax[4]    = {0, 0, 0, 0};
static float g_tabAnim = 1.0f;
static int   g_lastTab = -1;
static int   g_colOpen = -1;          // which colour row is expanded in the VISUAL tab
static bool  g_colDirty = false;
static std::vector<ImRect> g_sliderRectsPrev, g_sliderRectsNow;

static void DrawContentArea(float winW, float winH) {
    bool need_save = false;
    ImGuiIO& io = GetIO();
    ImDrawList* dl = GetWindowDrawList();
    ImVec2 wp = GetWindowPos();
    const float s = winW / 540.0f;

    const float headerH = 56.0f * s;
    const float footerH = 54.0f * s;
    const float padX = 14.0f * s;
    const float bodyTop = headerH + 6.0f * s;
    const float footerY = winH - footerH;
    const float contentW = winW - padX * 2.0f;
    const ImFont* font = GetFont();
    const float textPx = 14.0f * s;
    const float titlePx = 13.0f * s;
    const float tabPx = 14.0f * s;
    const float mutedPx = 13.0f * s;
    const int tab = g_menu.currentTab;

    const ImU32 cText  = IM_COL32(228, 228, 234, 255);
    const ImU32 cMuted = IM_COL32(140, 140, 150, 230);
    const ImU32 cRow   = IM_COL32(24, 24, 29, 255);
    const ImU32 cRowHi = IM_COL32(33, 33, 40, 255);
    const ImU32 cLine  = IM_COL32(70, 65, 27, 220);

    auto TextAt = [&](const char* text, ImVec2 pos, ImU32 color, float px) {
        dl->AddText(font, px, pos, color, text);
    };
    auto CenterText = [&](const char* text, ImVec2 center, ImU32 color, float px) {
        ImVec2 ts = font->CalcTextSizeA(px, FLT_MAX, 0.0f, text);
        dl->AddText(font, px, ImVec2(center.x - ts.x * 0.5f, center.y - ts.y * 0.5f), color, text);
    };

    // ---- tab change animation ------------------------------------------------------------
    if (tab != g_lastTab) { g_lastTab = tab; g_tabAnim = 0.0f; g_colOpen = -1; }
    g_tabAnim = ImMin(1.0f, g_tabAnim + io.DeltaTime * 4.5f);
    const float slide = (1.0f - EaseOutQuart(g_tabAnim)) * 20.0f * s;
    const float tabAlpha = g_tabAnim;

    // ---- header: logo + name + license chip ------------------------------------------------
    {
        static GLuint hdrLogo = LoadTextureFromMemory(embedded_assets::dragonLogo.data, embedded_assets::dragonLogo.size);
        const float ls = 40.0f * s;
        dl->AddImageRounded((void*)(intptr_t)hdrLogo, ImVec2(wp.x + padX, wp.y + 8.0f * s),
                            ImVec2(wp.x + padX + ls, wp.y + 8.0f * s + ls), ImVec2(0, 0), ImVec2(1, 1),
                            IM_COL32_WHITE, ls * 0.5f);
        dl->AddCircle(ImVec2(wp.x + padX + ls * 0.5f, wp.y + 8.0f * s + ls * 0.5f), ls * 0.5f,
                      IM_COL32(255, 215, 0, 200), 32, 1.5f * s);
        TextAt(O("DRAGON ENGINE"), ImVec2(wp.x + padX + ls + 10.0f * s, wp.y + 9.0f * s), UI_GOLD, titlePx * 1.3f);
        TextAt(O("CARROM POOL  |  PREMIUM"), ImVec2(wp.x + padX + ls + 10.0f * s, wp.y + 31.0f * s), cMuted, mutedPx * 0.82f);

        static std::string chip; static double chipT = -10.0;
        if (GetTime() - chipT > 1.0) { chip = KlExpiryText(); chipT = GetTime(); }
        ImVec2 cs = font->CalcTextSizeA(mutedPx * 0.9f, FLT_MAX, 0.0f, chip.c_str());
        const float cw = cs.x + 18.0f * s, chh = 22.0f * s;
        ImVec2 ca(wp.x + winW - padX - cw, wp.y + 17.0f * s), cb(ca.x + cw, ca.y + chh);
        dl->AddRectFilled(ca, cb, IM_COL32(30, 52, 33, 255), chh * 0.5f);
        dl->AddRect(ca, cb, IM_COL32(70, 200, 100, 200), chh * 0.5f, 0, 1.0f * s);
        CenterText(chip.c_str(), ImVec2((ca.x + cb.x) * 0.5f, (ca.y + cb.y) * 0.5f), IM_COL32(120, 235, 150, 255), mutedPx * 0.9f);
    }
    dl->AddLine(ImVec2(wp.x + padX, wp.y + headerH), ImVec2(wp.x + winW - padX, wp.y + headerH),
                IM_COL32(90, 72, 18, 180), 1.0f * s);

    // ---- scroll (touch drag on the body) ---------------------------------------------------
    const ImRect body(ImVec2(wp.x, wp.y + bodyTop), ImVec2(wp.x + winW, wp.y + footerY));
    static bool tracking = false, dragging = false;
    static float dragStartY = 0.0f, scrollStart = 0.0f;
    if (IsMouseClicked(0) && body.Contains(io.MousePos)) {
        tracking = true; dragging = false;
        dragStartY = io.MousePos.y; scrollStart = g_scrollTarget[tab];
        for (const ImRect& r : g_sliderRectsPrev) if (r.Contains(io.MousePos)) { tracking = false; break; }
    }
    if (tracking && io.MouseDown[0]) {
        if (!dragging && fabsf(io.MousePos.y - dragStartY) > 12.0f * s) dragging = true;
        if (dragging) {
            g_scrollTarget[tab] = ImClamp(scrollStart - (io.MousePos.y - dragStartY), 0.0f, g_scrollMax[tab]);
            g_scrollShown[tab] = g_scrollTarget[tab];
        }
    }
    const bool swallow = dragging;                    // a drag must not trigger the row under the finger
    if (IsMouseReleased(0)) { tracking = false; dragging = false; }
    g_scrollTarget[tab] = ImClamp(g_scrollTarget[tab], 0.0f, g_scrollMax[tab]);
    g_scrollShown[tab] += (g_scrollTarget[tab] - g_scrollShown[tab]) * ImMin(1.0f, io.DeltaTime * 18.0f);
    g_sliderRectsNow.clear();

    PushClipRect(body.Min, body.Max, true);

    float cy = bodyTop + slide - g_scrollShown[tab];
    const float rowH = 40.0f * s;
    const float rowGap = 7.0f * s;
    const float rowR = 8.0f * s;

    auto Section = [&](const char* label) {
        TextAt(label, ImVec2(wp.x + padX, wp.y + cy + 1.0f * s), IM_COL32(255, 215, 0, (int)(255 * tabAlpha)), textPx);
        cy += 28.0f * s;
    };

    auto DrawRefToggle = [&](const char* idText, const char* label, bool* value,
                             const char* sub = nullptr, bool enabled = true) {
        ImGuiWindow* w = GetCurrentWindow();
        ImGuiID id = w->GetID(idText);
        ImVec2 a(wp.x + padX, wp.y + cy);
        ImVec2 b(a.x + contentW, a.y + rowH);
        ImRect bb(a, b);
        ItemSize(ImVec2(contentW, rowH));
        if (ItemAdd(bb, id)) {
            bool hovered = false, held = false;
            if (ButtonBehavior(bb, id, &hovered, &held) && !swallow && enabled) {
                *value = !*value;
                need_save = true;
            }
            const float hv = UiAnim(id + 1, (hovered || held) && enabled ? 1.0f : 0.0f, 14.0f);
            dl->AddRectFilled(a, b, UiLerpCol(cRow, cRowHi, hv), rowR);
            dl->AddRect(a, b, cLine, rowR, 0, 1.0f * s);

            const ImU32 tcol = enabled ? cText : IM_COL32(120, 120, 128, 255);
            ImVec2 ts = font->CalcTextSizeA(textPx, FLT_MAX, 0.0f, label);
            const float ty = sub ? a.y + 5.0f * s : a.y + (rowH - ts.y) * 0.5f;
            TextAt(label, ImVec2(a.x + 10.0f * s, ty), tcol, textPx);
            if (sub) TextAt(sub, ImVec2(a.x + 10.0f * s, ty + ts.y + 1.0f * s), IM_COL32(140, 140, 150, 210), mutedPx * 0.82f);

            const float tw = 46.0f * s, th = 24.0f * s, r = th * 0.5f;
            const float k = UiAnim(id + 2, (*value && enabled) ? 1.0f : 0.0f, 16.0f);
            ImVec2 ta(b.x - tw - 9.0f * s, a.y + (rowH - th) * 0.5f);
            ImVec2 tb(ta.x + tw, ta.y + th);
            dl->AddRectFilled(ta, tb, UiLerpCol(IM_COL32(61, 63, 73, 255), UI_GOLD, k), r);
            dl->AddRect(ta, tb, IM_COL32(48, 48, 54, 180), r, 0, 1.0f * s);
            const float kx = (ta.x + r) + ((tb.x - r) - (ta.x + r)) * EaseOutQuart(k);
            dl->AddCircleFilled(ImVec2(kx + 0.6f * s, ta.y + r + 1.0f * s), 8.6f * s, IM_COL32(0, 0, 0, 50), 24);
            dl->AddCircleFilled(ImVec2(kx, ta.y + r), 8.0f * s, IM_COL32(250, 250, 250, 255), 24);
        }
        cy += rowH + rowGap;
    };

    auto DrawRefSlider = [&](const char* label, const char* id, float* value,
                             float minV, float maxV, bool integerValue) {
        TextAt(label, ImVec2(wp.x + padX, wp.y + cy + 1.0f * s), cText, textPx);
        cy += 25.0f * s;
        ImGuiWindow* w = GetCurrentWindow();
        ImGuiID iid = w->GetID(id);
        ImVec2 a(wp.x + padX, wp.y + cy);
        ImVec2 b(a.x + contentW, a.y + 32.0f * s);
        ImRect bb(a, b);
        ItemSize(ImVec2(contentW, 32.0f * s));
        if (ItemAdd(bb, iid)) {
            g_sliderRectsNow.push_back(bb);
            bool hovered = false, held = false;
            ButtonBehavior(bb, iid, &hovered, &held);
            float t = integerValue ? ((*((int*)value) - minV) / (maxV - minV)) : ((*value - minV) / (maxV - minV));
            t = ImClamp(t, 0.0f, 1.0f);
            if (held) {
                float nt = ImClamp((io.MousePos.x - bb.Min.x) / bb.GetWidth(), 0.0f, 1.0f);
                if (integerValue) *((int*)value) = (int)lroundf(minV + nt * (maxV - minV));
                else *value = minV + nt * (maxV - minV);
                need_save = true;
                t = nt;
            }
            const float ts = UiAnim(iid + 1, t, 30.0f);
            dl->AddRectFilled(a, b, IM_COL32(23, 23, 29, 255), 8.0f * s);
            dl->AddRectFilled(a, ImVec2(a.x + ts * bb.GetWidth(), b.y), IM_COL32(255, 215, 0, 40), 8.0f * s);
            dl->AddRect(a, b, IM_COL32(55, 53, 62, 220), 8.0f * s, 0, 1.0f * s);
            const float thumbX = a.x + ts * bb.GetWidth();
            dl->AddRectFilled(ImVec2(thumbX - 5.0f * s, a.y + 4.0f * s), ImVec2(thumbX + 5.0f * s, b.y - 4.0f * s), UI_GOLD, 5.0f * s);
            char valueText[32];
            if (integerValue) snprintf(valueText, sizeof(valueText), "%d", *((int*)value));
            else snprintf(valueText, sizeof(valueText), "%.1f", *value);
            CenterText(valueText, ImVec2((a.x + b.x) * 0.5f, (a.y + b.y) * 0.5f), IM_COL32(205, 205, 210, 255), mutedPx);
        }
        cy += 44.0f * s;
    };

    // Segmented selector. Returns true when the value changed.
    auto DrawSeg = [&](const char* idPrefix, const char* const* labels, int n, int* value) -> bool {
        bool changed = false;
        const float gap = 6.0f * s;
        const float bw = (contentW - gap * (n - 1)) / (float)n;
        const float bh = 40.0f * s;
        for (int i = 0; i < n; i++) {
            ImVec2 a(wp.x + padX + i * (bw + gap), wp.y + cy), b(a.x + bw, a.y + bh);
            char idb[64]; snprintf(idb, sizeof(idb), "%s%d", idPrefix, i);
            ImGuiID iid = GetCurrentWindow()->GetID(idb);
            ImRect bb(a, b);
            ItemSize(ImVec2(bw, bh));
            if (ItemAdd(bb, iid)) {
                bool hovered = false, held = false;
                if (ButtonBehavior(bb, iid, &hovered, &held) && !swallow) { *value = i; changed = true; need_save = true; }
                const float sel = UiAnim(iid + 1, *value == i ? 1.0f : 0.0f, 16.0f);
                dl->AddRectFilled(a, b, UiLerpCol(IM_COL32(22, 22, 27, 255), UI_GOLD, sel), 8.0f * s);
                dl->AddRect(a, b, UiLerpCol(IM_COL32(55, 53, 62, 230), IM_COL32(255, 220, 35, 255), sel), 8.0f * s, 0, 1.0f * s);
                CenterText(labels[i], ImVec2((a.x + b.x) * 0.5f, (a.y + b.y) * 0.5f),
                           UiLerpCol(IM_COL32(215, 215, 220, 255), IM_COL32(20, 20, 20, 255), sel), mutedPx);
            }
        }
        cy += bh + 9.0f * s;
        return changed;
    };

    // A coloured gradient slider (0..1). kind: 0 hue, 1 saturation, 2 brightness.
    auto DrawGradSlider = [&](const char* id, float* v, int kind, float hue, float sat, float val) -> bool {
        const float h = 26.0f * s;
        ImVec2 a(wp.x + padX, wp.y + cy), b(a.x + contentW, a.y + h);
        ImGuiID iid = GetCurrentWindow()->GetID(id);
        ImRect bb(a, b);
        ItemSize(ImVec2(contentW, h));
        bool changed = false;
        if (ItemAdd(bb, iid)) {
            g_sliderRectsNow.push_back(bb);
            bool hovered = false, held = false;
            ButtonBehavior(bb, iid, &hovered, &held);
            if (held) { *v = ImClamp((io.MousePos.x - bb.Min.x) / bb.GetWidth(), 0.0f, 1.0f); changed = true; }
            const float tr = 5.0f * s;
            ImVec2 ta(a.x, a.y + tr), tb(b.x, b.y - tr);
            if (kind == 0) {
                const int seg = 6;
                const float segW = (tb.x - ta.x) / seg;
                for (int i = 0; i < seg; i++) {
                    float r0, g0, b0, r1, g1, b1;
                    ColorConvertHSVtoRGB(i / (float)seg, 1, 1, r0, g0, b0);
                    ColorConvertHSVtoRGB((i + 1) / (float)seg, 1, 1, r1, g1, b1);
                    dl->AddRectFilledMultiColor(ImVec2(ta.x + i * segW, ta.y), ImVec2(ta.x + (i + 1) * segW, tb.y),
                        ColorConvertFloat4ToU32(ImVec4(r0, g0, b0, 1)), ColorConvertFloat4ToU32(ImVec4(r1, g1, b1, 1)),
                        ColorConvertFloat4ToU32(ImVec4(r1, g1, b1, 1)), ColorConvertFloat4ToU32(ImVec4(r0, g0, b0, 1)));
                }
            } else {
                float r, g, bl;
                if (kind == 1) { ColorConvertHSVtoRGB(hue, 1, val, r, g, bl);
                    dl->AddRectFilledMultiColor(ta, tb, ColorConvertFloat4ToU32(ImVec4(val, val, val, 1)),
                        ColorConvertFloat4ToU32(ImVec4(r, g, bl, 1)), ColorConvertFloat4ToU32(ImVec4(r, g, bl, 1)),
                        ColorConvertFloat4ToU32(ImVec4(val, val, val, 1)));
                } else { ColorConvertHSVtoRGB(hue, sat, 1, r, g, bl);
                    dl->AddRectFilledMultiColor(ta, tb, IM_COL32(0, 0, 0, 255), ColorConvertFloat4ToU32(ImVec4(r, g, bl, 1)),
                        ColorConvertFloat4ToU32(ImVec4(r, g, bl, 1)), IM_COL32(0, 0, 0, 255));
                }
            }
            dl->AddRect(ta, tb, IM_COL32(80, 80, 90, 220), 3.0f * s, 0, 1.0f * s);
            const float x = a.x + ImClamp(*v, 0.0f, 1.0f) * bb.GetWidth();
            dl->AddCircleFilled(ImVec2(x, (a.y + b.y) * 0.5f), 9.5f * s, IM_COL32(0, 0, 0, 90), 24);
            dl->AddCircleFilled(ImVec2(x, (a.y + b.y) * 0.5f), 8.0f * s, IM_COL32(250, 250, 250, 255), 24);
        }
        cy += h + 8.0f * s;
        return changed;
    };

    // One colour row; tap to expand a Hue / Saturation / Brightness picker with presets.
    auto DrawColorRow = [&](int idx, const char* label, ImVec4* col) {
        char idb[32]; snprintf(idb, sizeof(idb), "##colRow%d", idx);
        ImGuiID id = GetCurrentWindow()->GetID(idb);
        ImVec2 a(wp.x + padX, wp.y + cy), b(a.x + contentW, a.y + rowH);
        ImRect bb(a, b);
        ItemSize(ImVec2(contentW, rowH));
        if (ItemAdd(bb, id)) {
            bool hovered = false, held = false;
            if (ButtonBehavior(bb, id, &hovered, &held) && !swallow) g_colOpen = (g_colOpen == idx) ? -1 : idx;
            const float hv = UiAnim(id + 1, (hovered || held) ? 1.0f : 0.0f, 14.0f);
            dl->AddRectFilled(a, b, UiLerpCol(cRow, cRowHi, hv), rowR);
            dl->AddRect(a, b, g_colOpen == idx ? UI_GOLD : cLine, rowR, 0, 1.0f * s);
            ImVec2 ts = font->CalcTextSizeA(textPx, FLT_MAX, 0.0f, label);
            TextAt(label, ImVec2(a.x + 10.0f * s, a.y + (rowH - ts.y) * 0.5f), cText, textPx);
            ImVec2 sa(b.x - 56.0f * s, a.y + 8.0f * s), sb(b.x - 12.0f * s, b.y - 8.0f * s);
            dl->AddRectFilled(sa, sb, ColorConvertFloat4ToU32(ImVec4(col->x, col->y, col->z, 1)), 6.0f * s);
            dl->AddRect(sa, sb, IM_COL32(255, 255, 255, 170), 6.0f * s, 0, 1.5f * s);
        }
        cy += rowH + rowGap;
        if (g_colOpen == idx) {
            float h, sa, v;
            ColorConvertRGBtoHSV(col->x, col->y, col->z, h, sa, v);
            static float hueMemo[16]; static bool hueInit[16];
            if (!hueInit[idx]) { hueMemo[idx] = h; hueInit[idx] = true; }
            if (sa > 0.02f && v > 0.02f) hueMemo[idx] = h; else h = hueMemo[idx];
            bool ch = false;
            char i1[32], i2[32], i3[32];
            snprintf(i1, sizeof(i1), "##cH%d", idx); snprintf(i2, sizeof(i2), "##cS%d", idx); snprintf(i3, sizeof(i3), "##cV%d", idx);
            if (DrawGradSlider(i1, &h, 0, h, sa, v)) { hueMemo[idx] = h; ch = true; }
            if (DrawGradSlider(i2, &sa, 1, h, sa, v)) ch = true;
            if (DrawGradSlider(i3, &v, 2, h, sa, v)) ch = true;
            // presets
            static const ImU32 presets[10] = {
                IM_COL32(255, 215, 0, 255), IM_COL32(255, 80, 80, 255), IM_COL32(255, 140, 0, 255), IM_COL32(60, 255, 90, 255),
                IM_COL32(0, 230, 255, 255), IM_COL32(40, 140, 255, 255), IM_COL32(190, 90, 255, 255), IM_COL32(255, 70, 170, 255),
                IM_COL32(255, 255, 255, 255), IM_COL32(120, 120, 130, 255)};
            const float pg = 6.0f * s, pw = (contentW - pg * 9) / 10.0f, ph = 26.0f * s;
            for (int i = 0; i < 10; i++) {
                ImVec2 pa(wp.x + padX + i * (pw + pg), wp.y + cy), pb(pa.x + pw, pa.y + ph);
                char pid[32]; snprintf(pid, sizeof(pid), "##pre%d_%d", idx, i);
                ImGuiID piid = GetCurrentWindow()->GetID(pid);
                ImRect pbb(pa, pb);
                ItemSize(ImVec2(pw, ph));
                if (ItemAdd(pbb, piid)) {
                    bool hov = false, hel = false;
                    if (ButtonBehavior(pbb, piid, &hov, &hel) && !swallow) {
                        ImVec4 c = ColorConvertU32ToFloat4(presets[i]);
                        col->x = c.x; col->y = c.y; col->z = c.z; g_colDirty = true; hueInit[idx] = false;
                    }
                    dl->AddRectFilled(pa, pb, presets[i], 6.0f * s);
                    dl->AddRect(pa, pb, IM_COL32(255, 255, 255, hov ? 230 : 90), 6.0f * s, 0, 1.0f * s);
                }
            }
            cy += ph + 12.0f * s;
            if (ch) {
                float r, g, bl; ColorConvertHSVtoRGB(h, sa, v, r, g, bl);
                col->x = r; col->y = g; col->z = bl; g_colDirty = true;
            }
        }
    };

    auto DrawLinkButton = [&](const char* idText, const char* label, const char* url, ImU32 fill, ImU32 border) {
        ImGuiID id = GetCurrentWindow()->GetID(idText);
        const float btnH = 46.0f * s;
        ImVec2 a(wp.x + padX, wp.y + cy), b(a.x + contentW, a.y + btnH);
        ImRect bb(a, b);
        ItemSize(ImVec2(contentW, btnH));
        if (ItemAdd(bb, id)) {
            bool hovered = false, held = false;
            const bool pressed = ButtonBehavior(bb, id, &hovered, &held);
            const float hv = UiAnim(id + 1, (hovered || held) ? 1.0f : 0.0f, 14.0f);
            dl->AddRectFilled(a, b, UiLerpCol(fill, IM_COL32(40, 170, 245, 255), hv * 0.6f), 10.0f * s);
            dl->AddRect(a, b, border, 10.0f * s, 0, 1.5f * s);
            CenterText(label, ImVec2((a.x + b.x) * 0.5f, (a.y + b.y) * 0.5f), IM_COL32(255, 255, 255, 255), textPx);
            if (pressed && !swallow) KlOpenUrl(url);
        }
        cy += btnH + 9.0f * s;
    };

    // =========================================================================================
    if (tab == 0) {
        // ── COMBAT: Auto Play + Auto Queue ───────────────────────────────────────────────
        Section(O("Auto Play"));
        DrawRefToggle("##autoPlay", "Auto Play", &persistent_bool[O("bAutoPlay")], "Plays the shots for you");

        if (persistent_bool[O("bAutoPlay")]) {
            TextAt(O("Auto Play Mode"), ImVec2(wp.x + padX, wp.y + cy + 1.0f * s), cMuted, mutedPx);
            cy += 24.0f * s;
            static const char* const modeLabels[3] = {"FAST", "HUMAN", "ULTRA FAST"};
            int m = g_refAutoPlayMode;
            if (DrawSeg("##apMode", modeLabels, 3, &m)) {
                g_refAutoPlayMode = m;
                // 0=FAST uses ScanFast, 1=HUMAN uses ScanSlow, 2=ULTRA_FAST forces FAST with no delay
                AutoPlay::scan = (m == 1) ? AutoPlay::SLOW : AutoPlay::FAST;
            }
        }

        Section(O("Auto Queue"));
        DrawRefToggle("##autoMatchQueue", "Auto Queue", &persistent_bool[O("bAutoQueue")], "Finds the next match automatically");
        TextAt(O("Select Table"), ImVec2(wp.x + padX, wp.y + cy + 1.0f * s), cMuted, mutedPx);
        cy += 24.0f * s;
        {
            static const char* const tableLabels[3] = {"Carrom", "Disc Pool", "Freestyle"};
            int& selectedMode = persistent_int[O("iAutoQueue_FixTable")];
            if (selectedMode < 0 || selectedMode > 2) selectedMode = 0;
            int sel = selectedMode;
            if (DrawSeg("##tableMode", tableLabels, 3, &sel)) selectedMode = sel;
        }
        DrawRefToggle("##cleanTable", "Clean Table", &persistent_bool[O("bCleanTable")]);

    } else if (tab == 1) {
        // ── VISUAL: prediction lines + all colours ───────────────────────────────────────
        Section(O("Prediction Line"));
        DrawRefToggle("##enablePrediction", "Enable Prediction", &persistent_bool[O("bESP_DrawPredictionLine")]);
        DrawRefToggle("##strikerPath", "Show Striker Path", &persistent_bool[O("bESP_DrawPocketsShotState")]);
        DrawRefToggle("##puckPaths", "Show Puck Paths", &persistent_bool[O("bESP_DrawPockets")]);
        DrawRefToggle("##predictionAfterShot", "Prediction After Shot", &persistent_bool[O("bESP_DrawPredictionAfterShot")]);

        Section(O("Line Style"));
        {
            const float styleGap = 10.0f * s;
            const float styleW = (contentW - styleGap) * 0.5f;
            const float styleH = 88.0f * s;
            const float previewPad = 10.0f * s;
            const char* styleNames[2] = {"Classic Mode", "Sea Blue Glow"};
            for (int i = 0; i < 2; ++i) {
                const float x = wp.x + padX + i * (styleW + styleGap);
                ImVec2 a(x, wp.y + cy), b(x + styleW, wp.y + cy + styleH);
                ImGuiID id = GetCurrentWindow()->GetID(i == 0 ? "##classicLineStyle" : "##blueLineStyle");
                ImRect bb(a, b);
                ItemSize(ImVec2(styleW, styleH));
                if (ItemAdd(bb, id)) {
                    bool hovered = false, held = false;
                    if (ButtonBehavior(bb, id, &hovered, &held) && !swallow) { g_refEspLineStyle = i; need_save = true; }
                    const float sel = UiAnim(id + 1, g_refEspLineStyle == i ? 1.0f : 0.0f, 14.0f);
                    dl->AddRectFilled(a, b, IM_COL32(18, 18, 23, 255), 9.0f * s);
                    dl->AddRect(a, b, UiLerpCol(IM_COL32(55, 53, 62, 230), UI_GOLD, sel), 9.0f * s, 0, (1.0f + sel) * s);

                    const float left = a.x + previewPad, right = b.x - previewPad;
                    const float mid = a.y + 31.0f * s, span = right - left;
                    const float phase = fmodf(g_refLineAnim * 0.12f, 1.0f);
                    ImVec2 prev(left, mid + 4.0f * s), ballPos = prev;
                    const ImVec4 lc = (i == 0) ? g_colStrikerLine : g_colGlowLine;
                    for (int k = 1; k <= 28; ++k) {
                        const float t = (float)k / 28.0f;
                        const float wave = sinf((t * 3.2f + phase) * 3.14159265f) * 5.0f * s;
                        ImVec2 cur(left + span * t, mid + wave);
                        ImU32 c = ColorConvertFloat4ToU32(ImVec4(lc.x, lc.y, lc.z, g_refLineOpacity));
                        dl->AddLine(prev, cur, c, ImMax(1.5f * s, g_refLineThickness * 0.35f * s));
                        prev = cur; ballPos = cur;
                    }
                    dl->AddCircleFilled(ballPos, 4.2f * s, ColorConvertFloat4ToU32(ImVec4(lc.x, lc.y, lc.z, g_refLineOpacity)), 20);
                    dl->AddCircle(ballPos, 6.0f * s, IM_COL32(255, 255, 255, (int)(110.0f * g_refLineOpacity)), 20, 1.0f * s);
                    CenterText(styleNames[i], ImVec2((a.x + b.x) * 0.5f, b.y - 17.0f * s),
                               g_refEspLineStyle == i ? IM_COL32(235, 235, 235, 255) : IM_COL32(185, 185, 190, 255), mutedPx);
                }
            }
            cy += styleH + 12.0f * s;
        }
        DrawRefSlider(O("Line Thickness"), "##refLineThickness", &g_refLineThickness, 1.0f, 10.0f, false);
        DrawRefSlider(O("Line Opacity"), "##refLineOpacity", &g_refLineOpacity, 0.1f, 1.0f, false);
        g_refLineAnim += io.DeltaTime * 2.0f;

        Section(O("Line Colors"));
        DrawColorRow(0, "Striker line (Classic)", &g_colStrikerLine);
        DrawColorRow(1, "Puck paths (Classic)", &g_colPieceLine);
        DrawColorRow(2, "Line (Sea Blue Glow)", &g_colGlowLine);

        Section(O("Pucks"));
        {
            bool before = g_puckRings;
            DrawRefToggle("##puckRings", "Puck rings", &g_puckRings);
            if (before != g_puckRings) g_colDirty = true;
        }
        DrawColorRow(3, "My pucks", &g_colMyPuck);
        DrawColorRow(4, "Opponent pucks", &g_colOppPuck);
        DrawColorRow(5, "Queen", &g_colQueenPuck);
        TextAt(O("My side (if game value unavailable)"), ImVec2(wp.x + padX, wp.y + cy + 1.0f * s), cMuted, mutedPx);
        cy += 24.0f * s;
        {
            static const char* const sideLabels[3] = {"Auto", "White", "Black"};
            int v = g_mySideManual;
            if (DrawSeg("##mySide", sideLabels, 3, &v)) { g_mySideManual = v; g_colDirty = true; }
        }

        Section(O("Pockets"));
        {
            static const char* const pocketLabels[4] = {"Off", "Ring", "Glow", "Target"};
            int v = g_pocketStyle;
            if (DrawSeg("##pocketStyle", pocketLabels, 4, &v)) { g_pocketStyle = v; g_colDirty = true; }
        }
        DrawColorRow(6, "Pocket color", &g_colPocket);

    } else if (tab == 2) {
        // ── TOOL: Disable Ads + Unlock Skins ─────────────────────────────────────────────
        Section(O("Ads"));
        {
            bool& v = persistent_bool[O("bNoAds")];
            DrawRefToggle("##noAds", "Disable Ads", &v, kAdsAvailable ? "Skips video / banner ads" : "needs game offset (see README)", kAdsAvailable);
        }
        Section(O("Skins"));
        {
            bool before = g_skinUnlockEnabled;
            DrawRefToggle("##skinUnlock", "Unlock Skins", &g_skinUnlockEnabled,
                          kSkinAvailable ? "Applies on your side only" : "needs game offset (see README)", kSkinAvailable);
            if (g_skinUnlockEnabled && !before) {
#if defined(SKIN_INDEX_OFFSET) && SKIN_INDEX_OFFSET != 0
                if (g_cgs.gameManager) {
                    ptr usm = g_cgs.userSettingsManager;
                    if (usm) W<int32_t>(usm + SKIN_INDEX_OFFSET) = 0x7FFF;
                }
#endif
            }
        }

    } else if (tab == 3) {
        // ── ABOUT: license, admin, devices, Telegram ─────────────────────────────────────
        static KlSession sess; static double sessT = -10.0; static std::string devShort;
        if (GetTime() - sessT > 1.0) { sess = KlGetSession(); devShort = KlDeviceId(); sessT = GetTime(); }

        Section(O("License"));
        {
            const float rowsH = 34.0f * s;
            const float cardH = rowsH * 5 + 8.0f * s;
            ImVec2 a(wp.x + padX, wp.y + cy), b(a.x + contentW, a.y + cardH);
            dl->AddRectFilled(a, b, cRow, rowR);
            dl->AddRect(a, b, cLine, rowR, 0, 1.0f * s);
            auto Row = [&](int i, const char* k, const std::string& v, ImU32 vc) {
                const float y = a.y + 4.0f * s + i * rowsH;
                if (i > 0) dl->AddLine(ImVec2(a.x + 10.0f * s, y), ImVec2(b.x - 10.0f * s, y), IM_COL32(45, 45, 52, 200), 1.0f * s);
                ImVec2 ks = font->CalcTextSizeA(textPx, FLT_MAX, 0.0f, k);
                TextAt(k, ImVec2(a.x + 12.0f * s, y + (rowsH - ks.y) * 0.5f), cMuted, textPx);
                ImVec2 vs = font->CalcTextSizeA(textPx, FLT_MAX, 0.0f, v.c_str());
                TextAt(v.c_str(), ImVec2(b.x - 12.0f * s - vs.x, y + (rowsH - vs.y) * 0.5f), vc, textPx);
            };
            char devs[48]; snprintf(devs, sizeof(devs), "%d / %d", sess.deviceCount, sess.deviceLimit);
            Row(0, O("Status"), NovaEngine_IsLoggedIn() ? "ACTIVE" : "INACTIVE", IM_COL32(110, 235, 140, 255));
            Row(1, O("Expires"), KlExpiryDate(), cText);
            Row(2, O("Time left"), KlExpiryText(), UI_GOLD);
            Row(3, O("Created by"), sess.createdBy.empty() ? std::string("Admin") : sess.createdBy, cText);
            Row(4, O("Devices used"), devs, cText);
            ItemSize(ImVec2(contentW, cardH));
            cy += cardH + 10.0f * s;
        }
        {
            TextAt(O("Device ID"), ImVec2(wp.x + padX, wp.y + cy), cMuted, mutedPx * 0.9f);
            ImVec2 ds = font->CalcTextSizeA(mutedPx * 0.9f, FLT_MAX, 0.0f, devShort.c_str());
            TextAt(devShort.c_str(), ImVec2(wp.x + winW - padX - ds.x, wp.y + cy), cText, mutedPx * 0.9f);
            cy += 26.0f * s;
        }

        Section(O("About"));
        {
            const char* aboutText = sess.about.empty() ? "Dragon Engine for Carrom Pool.  Created By @Memon_salim" : sess.about.c_str();
            ImVec2 ts = font->CalcTextSizeA(mutedPx, FLT_MAX, contentW - 20.0f * s, aboutText);
            const float cardH = ts.y + 20.0f * s;
            ImVec2 a(wp.x + padX, wp.y + cy), b(a.x + contentW, a.y + cardH);
            dl->AddRectFilled(a, b, cRow, rowR);
            dl->AddRect(a, b, cLine, rowR, 0, 1.0f * s);
            dl->AddText(font, mutedPx, ImVec2(a.x + 10.0f * s, a.y + 10.0f * s), cText, aboutText, nullptr, contentW - 20.0f * s);
            ItemSize(ImVec2(contentW, cardH));
            cy += cardH + 12.0f * s;
        }

        Section(O("Telegram"));
        if (sess.channels.empty()) {
            DrawLinkButton("##tgChannel", O("Dragon Engine Official  (Channel)"), O(KL_TELEGRAM_URL), IM_COL32(19, 139, 224, 255), IM_COL32(38, 177, 246, 255));
        } else {
            int n = 0;
            for (const auto& ch : sess.channels) {
                if (n >= 4) break;
                char idb[32]; snprintf(idb, sizeof(idb), "##tgCh%d", n++);
                DrawLinkButton(idb, ch.first.c_str(), ch.second.c_str(), IM_COL32(19, 139, 224, 255), IM_COL32(38, 177, 246, 255));
            }
        }
        DrawLinkButton("##tgOwner", O("Owner  @Memon_salim"), O("https://t.me/Memon_salim"), IM_COL32(24, 24, 29, 255), IM_COL32(38, 177, 246, 255));

        // Log out
        {
            ImGuiID id = GetCurrentWindow()->GetID("##logout");
            const float btnH = 44.0f * s;
            ImVec2 a(wp.x + padX, wp.y + cy), b(a.x + contentW, a.y + btnH);
            ImRect bb(a, b);
            ItemSize(ImVec2(contentW, btnH));
            if (ItemAdd(bb, id)) {
                bool hovered = false, held = false;
                const bool pressed = ButtonBehavior(bb, id, &hovered, &held);
                const float hv = UiAnim(id + 1, (hovered || held) ? 1.0f : 0.0f, 14.0f);
                dl->AddRectFilled(a, b, UiLerpCol(IM_COL32(34, 16, 16, 255), IM_COL32(70, 24, 24, 255), hv), 10.0f * s);
                dl->AddRect(a, b, IM_COL32(255, 82, 82, 220), 10.0f * s, 0, 1.2f * s);
                CenterText(O("LOG OUT"), ImVec2((a.x + b.x) * 0.5f, (a.y + b.y) * 0.5f), IM_COL32(255, 110, 110, 255), textPx);
                if (pressed && !swallow) {
                    persistent_bool[O("bAutoPlay")] = false;
                    persistent_bool[O("bAutoQueue")] = false;
                    persistent_string.erase(O("key"));
                    need_save = true;
                    KlLogout();
                }
            }
            cy += btnH + 14.0f * s;
        }
        CenterText(O("Dragon Engine  |  Created By @Memon_salim"), ImVec2(wp.x + winW * 0.5f, wp.y + cy + 6.0f * s), IM_COL32(90, 90, 98, 200), mutedPx * 0.85f);
        cy += 22.0f * s;
    }

    // scroll range for next frame
    g_scrollMax[tab] = ImMax(0.0f, (cy + g_scrollShown[tab] - slide) - footerY + 12.0f * s);
    g_sliderRectsPrev = g_sliderRectsNow;
    PopClipRect();

    // scroll indicator
    if (g_scrollMax[tab] > 1.0f) {
        const float trackH = footerY - bodyTop - 8.0f * s;
        const float thumbH = ImMax(24.0f * s, trackH * trackH / (trackH + g_scrollMax[tab]));
        const float ty = bodyTop + 4.0f * s + (trackH - thumbH) * (g_scrollShown[tab] / g_scrollMax[tab]);
        dl->AddRectFilled(ImVec2(wp.x + winW - 6.0f * s, wp.y + ty), ImVec2(wp.x + winW - 3.5f * s, wp.y + ty + thumbH),
                          IM_COL32(255, 215, 0, 110), 2.0f * s);
    }

    // ---- bottom tabs ---------------------------------------------------------------------
    dl->AddLine(ImVec2(wp.x + padX, wp.y + footerY), ImVec2(wp.x + winW - padX, wp.y + footerY), IM_COL32(90, 72, 18, 120), 1.0f * s);
    const float tabW = winW / 4.0f;
    auto DrawTab = [&](const char* id, const char* label, float x, bool selected, int tabIdx) {
        ImGuiID iid = GetCurrentWindow()->GetID(id);
        ImVec2 a(wp.x + x + 4.0f * s, wp.y + footerY + 4.0f * s), b(wp.x + x + tabW - 4.0f * s, wp.y + winH - 4.0f * s);
        ImRect bb(a, b);
        ItemSize(ImVec2(tabW, footerH));
        if (!ItemAdd(bb, iid)) return;
        bool hovered = false, held = false;
        bool pressed = ButtonBehavior(bb, iid, &hovered, &held);
        const float sel = UiAnim(iid + 1, selected ? 1.0f : 0.0f, 14.0f);
        const float hv = UiAnim(iid + 2, hovered ? 1.0f : 0.0f, 14.0f);
        dl->AddRectFilled(a, b, UiLerpCol(IM_COL32(255, 215, 0, (int)(28 * hv)), UI_GOLD, sel), 9.0f * s);
        CenterText(label, ImVec2((a.x + b.x) * 0.5f, (a.y + b.y) * 0.5f),
                   UiLerpCol(IM_COL32(220, 220, 225, 255), IM_COL32(15, 15, 15, 255), sel), tabPx);
        if (pressed) g_menu.currentTab = tabIdx;
    };
    DrawTab("##combatTab", O("COMBAT"), 0,          g_menu.currentTab == 0, 0);
    DrawTab("##visualTab", O("VISUAL"), tabW,       g_menu.currentTab == 1, 1);
    DrawTab("##toolTab",   O("TOOL"),   tabW * 2.0f, g_menu.currentTab == 2, 2);
    DrawTab("##aboutTab",  O("ABOUT"),  tabW * 3.0f, g_menu.currentTab == 3, 3);

    if (g_colDirty && !io.MouseDown[0]) { svConfig_Save(); g_colDirty = false; }
    if (need_save) save_persistence();
}

INLINE void DrawColorPanel() {
    using namespace ImGui;
    SetNextWindowPos(ImVec2(Width * 0.02f, Height * 0.28f), ImGuiCond_FirstUseEver);
    if (!Begin("Colors##dragonColors", nullptr, ImGuiWindowFlags_AlwaysAutoResize)) { End(); return; }
    static bool dirty = false;
    const ImGuiColorEditFlags cf = ImGuiColorEditFlags_NoInputs;
    dirty |= ColorEdit3("Striker line", &g_colStrikerLine.x, cf);
    dirty |= ColorEdit3("Piece lines (Classic)", &g_colPieceLine.x, cf);
    dirty |= ColorEdit3("Line (Sea Blue Glow)", &g_colGlowLine.x, cf);
    Separator();
    dirty |= Checkbox("Puck rings", &g_puckRings);
    dirty |= ColorEdit3("My pucks", &g_colMyPuck.x, cf);
    dirty |= ColorEdit3("Opponent pucks", &g_colOppPuck.x, cf);
    dirty |= ColorEdit3("Queen", &g_colQueenPuck.x, cf);
    dirty |= Combo("My side if auto unknown", &g_mySideManual, "Auto\0White\0Black\0\0");
    Separator();
    dirty |= Combo("Pocket style", &g_pocketStyle, "Off\0Ring\0Glow\0Target\0\0");
    dirty |= ColorEdit3("Pocket color", &g_colPocket.x, cf);
    End();
    if (dirty && !IsAnyItemActive()) { svConfig_Save(); dirty = false; }
}

INLINE void DrawMenu(ImGuiIO& io) {
    g_MenuConsumesTouch = g_menu.isOpen;
    g_noAdsOn.store(kAdsAvailable && NovaEngine_IsLoggedIn() && persistent_bool[O("bNoAds")], std::memory_order_relaxed);
    if (NovaEngine_IsLoggedIn()) {

        jump_buffer_active = 1;
        g_espStep = 0; g_espStepName = "frame start";
        jump_buffer_active = 1;
        if (!sigsetjmp(jump_buffer, 1)) DrawESP(GetBackgroundDrawList());
        else {
            jump_buffer_active = 0;
            bug_log_write("ESP: SIGSEGV at step %d (%s) — recovering", g_espStep, g_espStepName);
            bug_log_flush();
        }
        jump_buffer_active = 0;
        jump_buffer_active = 0;

        if (g_cgs.gameManager) {
            jump_buffer_active = 1;
            if (sigsetjmp(jump_buffer, 1) == 0) {
                if (persistent_bool[O("bAutoPlay")]) AutoPlay::Update();
            } else {
                jump_buffer_active = 0;
                bug_log_write("AutoPlay: SIGSEGV caught — recovering");
            }
            jump_buffer_active = 0;

            jump_buffer_active = 1;
            if (sigsetjmp(jump_buffer, 1) == 0) {
                AutoAim::Draw();
            } else {
                jump_buffer_active = 0;
                bug_log_write("AutoAim: SIGSEGV caught — recovering");
            }
            jump_buffer_active = 0;
        }

        if (g_menu.isOpen) g_menu.menuAlpha += (1.0f-g_menu.menuAlpha)*io.DeltaTime*12.0f;
        else g_menu.menuAlpha=0.0f;

        if (g_menu.menuAlpha>0.01f) {
            const float s = ImMax(0.55f, Width/694.0f);
            const float winW=g_menuW*s;
            const float winH=g_menuH*s;

            float px=g_menuX*s;
            float py=g_menuY*s;

            SetNextWindowSize(ImVec2(winW,winH),ImGuiCond_Always);
            SetNextWindowPos(ImVec2(px,py),ImGuiCond_Always);
            PushStyleColor(ImGuiCol_WindowBg,ImVec4(0,0,0,0));
            PushStyleVar(ImGuiStyleVar_WindowRounding,18*s);
            PushStyleVar(ImGuiStyleVar_WindowPadding,ImVec2(0,0));
            PushStyleVar(ImGuiStyleVar_WindowBorderSize,0);
            PushStyleVar(ImGuiStyleVar_Alpha,g_menu.menuAlpha);

            ImGuiWindowFlags flags=ImGuiWindowFlags_NoCollapse|ImGuiWindowFlags_NoTitleBar|
                ImGuiWindowFlags_NoScrollbar|ImGuiWindowFlags_NoScrollWithMouse|ImGuiWindowFlags_NoResize|ImGuiWindowFlags_NoMove;
            if(Begin(O("##MainMenu"),&g_menu.isOpen,flags)) {
                ImDrawList* dl=GetWindowDrawList();
                ImVec2 a=GetWindowPos(), b(a.x+winW,a.y+winH);
                dl->AddRectFilled(a,b,IM_COL32(5,5,7,248),18*s);
                dl->AddRect(a,b,IM_COL32(112,82,15,255),18*s,0,2*s);
                dl->AddRect(ImVec2(a.x+3*s,a.y+3*s),ImVec2(b.x-3*s,b.y-3*s),IM_COL32(235,195,70,210),15*s,0,1*s);

                SetCursorPos(ImVec2(0,0));
                InvisibleButton(O("##MenuDrag"),ImVec2(winW,56*s));
                if(IsItemActive() && IsMouseDragging(ImGuiMouseButton_Left,2.0f)) {

                    g_menuX += io.MouseDelta.x/s;
                    g_menuY += io.MouseDelta.y/s;
                    if(g_menuX<0) g_menuX=0; if(g_menuY<0) g_menuY=0;
                    if(g_menuX>694-g_menuW) g_menuX=694-g_menuW;
                    if(g_menuY>1536-g_menuH) g_menuY=1536-g_menuH;
                }
                SetCursorPos(ImVec2(0,0));
                DrawContentArea(winW,winH);
            }
            End();
            PopStyleVar(4); PopStyleColor();
        }
    }
}

static void DrawToggleButton(bool cancelMode) {
    ImGuiIO& io=GetIO();
    static GLuint play_on_tex=LoadTextureFromMemory(embedded_assets::playOn.data, embedded_assets::playOn.size);
    static GLuint play_off_tex=LoadTextureFromMemory(embedded_assets::playOff.data, embedded_assets::playOff.size);

    const float s=ImMax(0.55f,io.DisplaySize.x/694.0f);
    const float buttonSize=g_playBtnSize*s;
    g_playBtnX=ImClamp(g_playBtnX,0.0f,694.0f-g_playBtnSize);
    g_playBtnY=ImClamp(g_playBtnY,0.0f,1536.0f-g_playBtnSize);
    const float px=g_playBtnX*s, py=g_playBtnY*s;

    const bool showModes = (!cancelMode && AutoPlay::bAutoPlaying);
    const float modeW=56.0f*s;
    const float modeH=30.0f*s;
    const float modeGap=2.0f*s;
    const float verticalGap=10.0f*s;
    const float modesW=modeW*3.0f+modeGap*2.0f;
    const float windowW=ImMax(buttonSize,modesW);
    const float windowH=buttonSize+8.0f*s+(showModes?verticalGap+modeH:0.0f);

    SetNextWindowSize(ImVec2(windowW,windowH),ImGuiCond_Always);
    SetNextWindowPos(ImVec2(px-(windowW-buttonSize)*0.5f,py),ImGuiCond_Always);
    PushStyleColor(ImGuiCol_WindowBg,IM_COL32(0,0,0,0));
    PushStyleVar(ImGuiStyleVar_WindowPadding,ImVec2(0,0));
    if(Begin("##ToggleBtn",nullptr,ImGuiWindowFlags_NoTitleBar|ImGuiWindowFlags_NoResize|ImGuiWindowFlags_NoScrollbar|ImGuiWindowFlags_NoSavedSettings|ImGuiWindowFlags_NoMove|ImGuiWindowFlags_NoBackground)) {
        ImDrawList* dl=GetWindowDrawList();
        const float playOffsetX=(windowW-buttonSize)*0.5f;
        ImVec2 pos(GetWindowPos().x+playOffsetX,GetWindowPos().y);

        SetCursorScreenPos(pos);
        InvisibleButton("##TglBtnHit",ImVec2(buttonSize,buttonSize));
        if(IsItemActive() && IsMouseDragging(ImGuiMouseButton_Left,2.0f)) {
            g_playBtnX+=io.MouseDelta.x/s;
            g_playBtnY+=io.MouseDelta.y/s;
        } else if(IsItemHovered() && IsMouseReleased(ImGuiMouseButton_Left) &&
                  (GetMouseDragDelta(ImGuiMouseButton_Left).x*GetMouseDragDelta(ImGuiMouseButton_Left).x+
                   GetMouseDragDelta(ImGuiMouseButton_Left).y*GetMouseDragDelta(ImGuiMouseButton_Left).y)<9.0f) {
            if(cancelMode) {
                persistent_bool[O("bAutoQueue")]=false;
                g_aqCounting=false;
                g_aqLastCall=std::chrono::steady_clock::now();
            } else {
                AutoPlay::bAutoPlaying=!AutoPlay::bAutoPlaying;
                if(AutoPlay::bAutoPlaying) AutoPlay::ClearState();
            }
        }

        GLuint tex=(!cancelMode && AutoPlay::bAutoPlaying)?play_on_tex:play_off_tex;
        dl->AddImageRounded((void*)(intptr_t)tex,pos,ImVec2(pos.x+buttonSize,pos.y+buttonSize),ImVec2(0,0),ImVec2(1,1),IM_COL32_WHITE,buttonSize*0.5f);

        if(showModes) {
            const float bx=GetWindowPos().x+(windowW-modesW)*0.5f;
            const float by=GetWindowPos().y+buttonSize+verticalGap;
            struct { const char* label; const char* id; int idx; } floatModes[3] = {
                {"FAST",       "##attachedFast",      0},
                {"HUMAN",      "##attachedHuman",     1},
                {"ULTRA",      "##attachedUltra",     2},
            };
            for(int i=0;i<3;++i) {
                const float x=bx+i*(modeW+modeGap);
                ImVec2 a(x,by),b(x+modeW,by+modeH);
                const char* label=floatModes[i].label;
                ImGuiID id=GetCurrentWindow()->GetID(floatModes[i].id);
                ImRect bb(a,b);
                ItemSize(ImVec2(modeW,modeH));
                if(ItemAdd(bb,id)) {
                    bool hovered=false,held=false;
                    if(ButtonBehavior(bb,id,&hovered,&held)) {
                        g_refAutoPlayMode=floatModes[i].idx;
                        AutoPlay::scan = (floatModes[i].idx == 1) ? AutoPlay::SLOW : AutoPlay::FAST;
                    }
                    const bool selected=(g_refAutoPlayMode==floatModes[i].idx);
                    const ImU32 fill=selected?IM_COL32(190,158,35,255):IM_COL32(27,27,34,245);
                    const ImU32 border=selected?IM_COL32(218,188,65,255):IM_COL32(70,68,78,235);
                    dl->AddRectFilled(a,b,fill,6.0f*s);
                    dl->AddRect(a,b,border,6.0f*s,0,1.0f*s);
                    const ImVec2 ts=GetFont()->CalcTextSizeA(10.0f*s,FLT_MAX,0.0f,label);
                    const ImVec2 tp((a.x+b.x-ts.x)*0.5f,(a.y+b.y-ts.y)*0.5f);
                    dl->AddText(GetFont(),10.0f*s,tp,selected?IM_COL32(20,20,20,255):IM_COL32(225,225,230,255),label);
                }
            }
        }
    }
    End();
    PopStyleVar();
    PopStyleColor();
}

// Floating menu logo. Works in pixels (any screen size / rotation), taps are detected on release of the
// ACTIVE item (touch has no "hover" after the finger lifts), dragging has a dead zone and the button
// glides to the nearest screen edge when released.
static void DrawFloatingButton(ImGuiIO& io) {
    static GLuint logo_tex = LoadTextureFromMemory(embedded_assets::dragonLogo.data, embedded_assets::dragonLogo.size);
    static float fx = -1.0f, fy = -1.0f;
    static bool dragging = false, snapping = false;
    static ImVec2 downPos(0, 0);

    const float W = io.DisplaySize.x, H = io.DisplaySize.y;
    if (W < 16.0f || H < 16.0f) return;
    const float size = ImClamp(ImMin(W, H) * 0.14f, 64.0f, 140.0f);
    const float margin = size * 0.12f;
    const float pad = size * 0.14f;                    // room for the glow ring around the logo
    const float winSz = size + pad * 2.0f;
    if (fx < 0.0f) { fx = margin; fy = H * 0.20f; }
    fx = ImClamp(fx, margin, ImMax(margin, W - size - margin));
    fy = ImClamp(fy, margin, ImMax(margin, H - size - margin));

    SetNextWindowPos(ImVec2(fx - pad, fy - pad), ImGuiCond_Always);
    SetNextWindowSize(ImVec2(winSz, winSz), ImGuiCond_Always);
    PushStyleColor(ImGuiCol_WindowBg, IM_COL32(0, 0, 0, 0));
    PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
    PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);
    if (Begin("##FloatBtn", nullptr, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar |
              ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings |
              ImGuiWindowFlags_NoFocusOnAppearing | ImGuiWindowFlags_NoNav | ImGuiWindowFlags_NoScrollWithMouse)) {
        ImDrawList* dl = GetWindowDrawList();
        const ImVec2 origin = GetWindowPos();
        SetCursorScreenPos(ImVec2(origin.x + pad, origin.y + pad));
        InvisibleButton("##FloatBtnHit", ImVec2(size, size));
        const bool active = IsItemActive();

        if (IsItemActivated()) { downPos = io.MousePos; dragging = false; snapping = false; }
        if (active) {
            const float dx = io.MousePos.x - downPos.x, dy = io.MousePos.y - downPos.y;
            if (!dragging && (dx * dx + dy * dy) > (10.0f * 10.0f)) dragging = true;
            if (dragging) { fx += io.MouseDelta.x; fy += io.MouseDelta.y; }
        }
        if (IsItemDeactivated()) {
            if (!dragging) g_menu.isOpen = !g_menu.isOpen;       // a tap
            else snapping = true;                                  // a drag: glide to the nearest edge
            dragging = false;
        }
        if (snapping && !active) {
            const float target = (fx + size * 0.5f < W * 0.5f) ? margin : (W - size - margin);
            fx += (target - fx) * ImMin(1.0f, io.DeltaTime * 14.0f);
            if (fabsf(target - fx) < 0.5f) { fx = target; snapping = false; }
        }

        // visuals: soft shadow, pulsing ring while the menu is open, press-scale
        const float press = UiAnim(GetID("##floatPress"), active ? 1.0f : 0.0f, 18.0f);
        const float openA = UiAnim(GetID("##floatOpen"), g_menu.isOpen ? 1.0f : 0.0f, 10.0f);
        const float r = size * 0.5f * (1.0f - 0.07f * press);
        const ImVec2 c(origin.x + pad + size * 0.5f, origin.y + pad + size * 0.5f);
        const float pulse = 0.5f + 0.5f * sinf((float)GetTime() * 3.0f);
        dl->AddCircleFilled(ImVec2(c.x, c.y + size * 0.04f), r * 1.05f, IM_COL32(0, 0, 0, 90), 48);
        if (openA > 0.01f)
            dl->AddCircle(c, r + size * (0.05f + 0.03f * pulse), IM_COL32(255, 215, 0, (int)(170 * openA)), 48, 2.5f);
        dl->AddImageRounded((void*)(intptr_t)logo_tex, ImVec2(c.x - r, c.y - r), ImVec2(c.x + r, c.y + r),
                            ImVec2(0, 0), ImVec2(1, 1), IM_COL32_WHITE, r);
        dl->AddCircle(c, r, IM_COL32(255, 215, 0, 230), 48, 2.0f);
    }
    End(); PopStyleVar(2); PopStyleColor();
}

static bool first_time = true;

static bool RefLoginButton(const char* id, const char* text, const ImVec2& pos,
                           const ImVec2& size, ImU32 fill, ImU32 border,
                           GLuint iconTex = 0, bool darkText = false) {
    SetCursorPos(pos);
    InvisibleButton(id, size);
    const bool pressed = IsItemClicked(ImGuiMouseButton_Left);
    const bool hovered = IsItemHovered();
    ImDrawList* dl = GetWindowDrawList();
    ImVec2 a = GetItemRectMin();
    ImVec2 b = GetItemRectMax();
    const ImU32 drawFill = hovered ? ColorConvertFloat4ToU32(ImVec4(
        ImMin(1.0f, ((fill >> IM_COL32_R_SHIFT) & 0xff) / 255.0f + 0.035f),
        ImMin(1.0f, ((fill >> IM_COL32_G_SHIFT) & 0xff) / 255.0f + 0.035f),
        ImMin(1.0f, ((fill >> IM_COL32_B_SHIFT) & 0xff) / 255.0f + 0.035f), 1.0f)) : fill;
    dl->AddRectFilled(a, b, drawFill, 18.0f);
    dl->AddRect(a, b, border, 18.0f, 0, 1.8f);

    const float iconW = iconTex ? size.y * 0.45f : 0.0f;
    const float gap = iconTex ? size.y * 0.12f : 0.0f;
    SetWindowFontScale(size.y / 76.0f);
    ImVec2 ts = CalcTextSize(text);
    const float groupW = iconW + gap + ts.x;
    float gx = a.x + (size.x - groupW) * 0.5f;
    const float gy = a.y + (size.y - ts.y) * 0.5f;
    if (iconTex) {
        float iy = a.y + (size.y - iconW) * 0.5f;
        dl->AddImage((void*)(intptr_t)iconTex,
                     ImVec2(gx, iy), ImVec2(gx + iconW, iy + iconW));
        gx += iconW + gap;
    }
    dl->AddText(ImVec2(gx, gy), darkText ? IM_COL32(8,8,8,255) : IM_COL32(255,255,255,255), text);
    SetWindowFontScale(1.0f);
    return pressed;
}

static void RefGoldHeading(ImDrawList* dl, const ImVec2& center, const char* text, float scale) {
    SetWindowFontScale(scale);
    ImVec2 ts = CalcTextSize(text);
    const float lineW = scale * 58.0f;
    const float gap = scale * 22.0f;
    const float total = lineW + gap + ts.x + gap + lineW;
    float x = center.x - total * 0.5f;
    const float y = center.y - ts.y * 0.5f;
    const ImU32 gold = IM_COL32(255, 205, 0, 255);

    for (int i = 0; i < 3; ++i) {
        float yy = y + ts.y * (0.20f + i * 0.30f);
        float len = lineW * (1.0f - i * 0.20f);
        dl->AddLine(ImVec2(x, yy), ImVec2(x + len, yy), gold, 2.0f);
        dl->AddLine(ImVec2(x + total - len, yy), ImVec2(x + total, yy), gold, 2.0f);
    }
    x += lineW + gap;
    dl->AddText(ImVec2(x, y), gold, text);
    SetWindowFontScale(1.0f);
}

INLINE void DrawLogin(ImGuiIO& io) {
    // Poll Firebase verification result every frame
    PollVerify();
    SetNextWindowPos(ImVec2(0, 0));
    SetNextWindowSize(io.DisplaySize);
    PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.0f, 0.0f, 0.0f, 0.42f));
    Begin(O("##Overlay"), nullptr,
          ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize |
          ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoScrollbar |
          ImGuiWindowFlags_NoInputs | ImGuiWindowFlags_NoBringToFrontOnFocus |
          ImGuiWindowFlags_NoSavedSettings);
    PopStyleColor();
    End();

    const float refAspect = 1216.0f / 1536.0f;
    const float maxW = ImMin(io.DisplaySize.x * 0.92f, 980.0f);
    const float cardW = maxW;
    const float cardH = ImMin(cardW / refAspect, io.DisplaySize.y * 0.88f);
    const float scale = cardW / 900.0f;

    SetNextWindowSize(ImVec2(cardW, cardH), ImGuiCond_Always);
    SetNextWindowPos(ImVec2(io.DisplaySize.x * 0.5f, io.DisplaySize.y * 0.5f),
                     ImGuiCond_Always, ImVec2(0.5f, 0.5f));
    PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.035f, 0.038f, 0.042f, 0.965f));
    PushStyleColor(ImGuiCol_Border, ImVec4(1.0f, 0.82f, 0.0f, 1.0f));
    PushStyleVar(ImGuiStyleVar_WindowRounding, 26.0f * scale);
    PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
    PushStyleVar(ImGuiStyleVar_WindowBorderSize, 2.0f * scale);

    if (Begin(O("##LoginCard"), nullptr,
              ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize |
              ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoTitleBar |
              ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoSavedSettings)) {
        ImDrawList* dl = GetWindowDrawList();
        const ImVec2 wp = GetWindowPos();
        const float s = scale;

        dl->AddRect(ImVec2(wp.x + 1.0f*s, wp.y + 1.0f*s),
                    ImVec2(wp.x + cardW - 1.0f*s, wp.y + cardH - 1.0f*s),
                    IM_COL32(255, 210, 0, 255), 26.0f*s, 0, 1.7f*s);

        static GLuint blackLogoTex = LoadTextureFromMemory(embedded_assets::dragonLogo.data, embedded_assets::dragonLogo.size);
        static GLuint keyTex = LoadTextureFromMemory(embedded_assets::refKey.data, embedded_assets::refKey.size);
        static GLuint pasteTex = LoadTextureFromMemory(embedded_assets::refPaste.data, embedded_assets::refPaste.size);
        static GLuint telegramTex = LoadTextureFromMemory(embedded_assets::refTelegram.data, embedded_assets::refTelegram.size);

        const float logoSize = cardW * 0.405f;
        const float logoTop = cardH * 0.047f;
        dl->AddImage((void*)(intptr_t)blackLogoTex,
                     ImVec2(wp.x + (cardW-logoSize)*0.5f, wp.y + logoTop),
                     ImVec2(wp.x + (cardW+logoSize)*0.5f, wp.y + logoTop + logoSize));

        RefGoldHeading(dl, ImVec2(wp.x + cardW*0.5f, wp.y + cardH*0.405f),
                       O("ENTER LICENSE KEY"), 1.55f*s);

        const float left = cardW * 0.062f;
        const float fieldW = cardW - left*2.0f;
        const float fieldH = cardH * 0.102f;
        const float fieldY = cardH * 0.485f;
        const float buttonH = cardH * 0.103f;
        const float loginY = cardH * 0.595f;
        const float pasteY = cardH * 0.705f;
        const float telegramY = cardH * 0.815f;

        const ImVec2 fa(wp.x + left, wp.y + fieldY);
        const ImVec2 fb(fa.x + fieldW, fa.y + fieldH);
        dl->AddRectFilled(fa, fb, IM_COL32(9,10,12,245), 18.0f*s);
        dl->AddRect(fa, fb, IM_COL32(92,92,92,255), 18.0f*s, 0, 2.0f*s);

        const float iconSize = fieldH * 0.42f;
        dl->AddImage((void*)(intptr_t)keyTex,
                     ImVec2(fa.x + fieldH*0.29f, fa.y + (fieldH-iconSize)*0.5f),
                     ImVec2(fa.x + fieldH*0.29f + iconSize, fa.y + (fieldH+iconSize)*0.5f));

        static char keyBuf[256] = {0};
        static bool keyLoaded = false;
        if (!keyLoaded) {
            auto it = persistent_string.find(O("key"));
            if (it != persistent_string.end() && !it->second.empty()) {
                strncpy(keyBuf, it->second.c_str(), sizeof(keyBuf)-1);
                keyBuf[sizeof(keyBuf)-1] = '\0';
            }
            keyLoaded = true;
            // A key saved by a previous successful login is verified again automatically (server check, not a cache).
            if (KlKeyFormatOk(KlNormalizeKey(keyBuf)) && !g_auth_checking) StartVerify(keyBuf);
        }

        SetCursorPos(ImVec2(left + fieldH*0.90f, fieldY + fieldH*0.07f));
        PushItemWidth(fieldW - fieldH*1.12f);
        PushStyleColor(ImGuiCol_FrameBg, ImVec4(0,0,0,0));
        PushStyleColor(ImGuiCol_FrameBgHovered, ImVec4(0,0,0,0));
        PushStyleColor(ImGuiCol_FrameBgActive, ImVec4(0,0,0,0));
        PushStyleColor(ImGuiCol_Text, ImVec4(0.68f,0.68f,0.70f,1.0f));
        PushStyleColor(ImGuiCol_TextDisabled, ImVec4(0.48f,0.48f,0.50f,1.0f));
        PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(0, fieldH*0.18f));
        PushStyleVar(ImGuiStyleVar_FrameRounding, 0.0f);
        SetWindowFontScale(1.30f*s);
        InputTextWithHint(O("##license_input"), O("Enter your key  XXXXX-XXXXX-XXXXX-XXXXX"),
                          keyBuf, sizeof(keyBuf), ImGuiInputTextFlags_CharsUppercase | ImGuiInputTextFlags_CharsNoBlank);
        SetWindowFontScale(1.0f);
        PopStyleVar(2);
        PopStyleColor(5);
        PopItemWidth();

        const ImU32 yellow = IM_COL32(255, 198, 0, 255);
        const ImU32 dark = IM_COL32(7, 7, 8, 255);
        const ImU32 grey = IM_COL32(25, 26, 29, 245);
        const ImU32 greyBorder = IM_COL32(86, 86, 88, 255);
        const ImU32 blue = IM_COL32(19, 139, 224, 255);
        const ImU32 blueBorder = IM_COL32(38, 177, 246, 255);

        if (RefLoginButton(O("##ref_login"), O("LOGIN"), ImVec2(left, loginY),
                           ImVec2(fieldW, buttonH), yellow, IM_COL32(255,221,75,255), 0, true)) {
            std::string keyToUse = keyBuf;
            if (keyToUse.empty()) {
                JNIEnv* env2 = nullptr;
                bool attachedClip = false;
                if (VM) {
                    jint r = VM->GetEnv((void**)&env2, JNI_VERSION_1_6);
                    if (r == JNI_EDETACHED) {
                        if (VM->AttachCurrentThread(&env2, nullptr) == 0)
                            attachedClip = true;
                    }
                }
                if (env2) {
                    keyToUse = getClipboard(env2);
                    if (attachedClip) VM->DetachCurrentThread();
                }
            }
            // ── Firebase verification (no bypass possible) ──────────────────
            if (!keyToUse.empty()) {
                persistent_string[O("key")] = KlNormalizeKey(keyToUse);
                save_persistence();
                StartVerify(keyToUse);   // async SHA-256 + Firebase check
            }
            first_time = false;
        }

        if (RefLoginButton(O("##ref_paste"), O("PASTE LICENSE KEY"), ImVec2(left, pasteY),
                           ImVec2(fieldW, buttonH), grey, greyBorder, pasteTex, false)) {
            JNIEnv* env2 = nullptr;
            bool attached2 = false;
            if (VM) {
                jint r = VM->GetEnv((void**)&env2, JNI_VERSION_1_6);
                if (r == JNI_EDETACHED) {
                    if (VM->AttachCurrentThread(&env2, nullptr) == 0)
                        attached2 = true;
                }
            }
            if (env2) {
                std::string clip = getClipboard(env2);
                if (!clip.empty()) {
                    strncpy(keyBuf, clip.c_str(), sizeof(keyBuf)-1);
                    keyBuf[sizeof(keyBuf)-1] = '\0';
                    persistent_string[O("key")] = clip;
                }
                if (attached2) VM->DetachCurrentThread();
            }
        }

        if (RefLoginButton(O("##ref_telegram"), O("GET KEY  (TELEGRAM)"), ImVec2(left, telegramY),
                           ImVec2(fieldW, buttonH), blue, blueBorder, telegramTex, false)) {
            KlOpenUrl(O(KL_TELEGRAM_URL));
        }

        // ── Firebase status display ───────────────────────────────────────────
        {
            const std::string status = KlGetStatus();
            if (!status.empty()) {
                ImVec4 statusCol = g_klStatusOk
                    ? ImVec4(0.1f, 0.9f, 0.3f, 1.0f)
                    : (g_auth_checking ? ImVec4(1.0f, 0.85f, 0.0f, 1.0f)
                                       : ImVec4(1.0f, 0.2f, 0.2f, 1.0f));
                SetCursorPos(ImVec2(left, cardH * 0.925f));
                TextColored(statusCol, "%s", status.c_str());
            }
        }
    }
    End();
    PopStyleVar(3);
    PopStyleColor(2);
}

INLINE void SetupImgui() {
    if (bImguiSetup) return;

    if (PACKAGE_NAME.empty()) {
        PACKAGE_NAME = "com.miniclip.carrom";
    }

    LOGF("SetupImgui: creating context");
    ImGui::CreateContext();

    auto& style = ImGui::GetStyle();
    auto& io = ImGui::GetIO();

    io.ConfigFlags |= ImGuiConfigFlags_IsTouchScreen;

    LOGF("SetupImgui: loading theme");
    switch_theme(current_theme);

    LOGF("SetupImgui: loading persistence");
    load_persistence();
    persistent_bool[O("bESP_DrawPockets")] = true;
    persistent_bool[O("bESP_DrawPredictionAfterShot")] = true;
    persistent_bool[O("bAutoPlay")] = false;
    persistent_bool[O("bCleanTable")] = false;
    AutoPlay::bAutoPlaying = false;

    LOGF("SetupImgui: loading svConfig");
    svConfig_Load();

    LOGF("SetupImgui: loading imgui style");
    load_imgui_style();

    static string INI_PATH = O("/data/user_de/0/") + PACKAGE_NAME + O("/no_backup/.ini");
    io.IniFilename = persistent_bool["bImguiAutoSave"] ? INI_PATH.c_str() : nullptr;
    io.ConfigWindowsMoveFromTitleBarOnly = persistent_bool["bMoveOnlyWithTitleBar"];

    ImFontConfig font_cfg;
    float fontSize = persistent_float["fFontScale"];
    if (fontSize < 1.0f) fontSize = 40.0f;
    font_cfg.SizePixels = fontSize;
    font_cfg.OversampleH = 3;            // crisp text: oversampled TrueType instead of the blurry bitmap font
    font_cfg.OversampleV = 2;
    font_cfg.PixelSnapH = false;
    {
        ImFont* uiFont = nullptr;
        static const char* const kFonts[] = {"/system/fonts/Roboto-Regular.ttf", "/system/fonts/NotoSans-Regular.ttf",
                                              "/system/fonts/DroidSans.ttf", "/system/fonts/SamsungOne-400.ttf"};
        for (const char* path : kFonts) {
            if (access(path, R_OK) == 0) { uiFont = io.Fonts->AddFontFromFileTTF(path, fontSize, &font_cfg); if (uiFont) break; }
        }
        if (!uiFont) io.Fonts->AddFontDefault(&font_cfg);
    }
    style.AntiAliasedLines = true;
    style.AntiAliasedLinesUseTex = true;
    style.AntiAliasedFill = true;
    style.CircleTessellationMaxError = 0.2f;

    LOGF("SetupImgui: initializing OpenGL3");
    ImGui_ImplOpenGL3_Init(O("#version 300 es"));

    bImguiSetup = true;
    LOGF("SetupImgui: DONE");
}

static int draw_call_count = 0;
DEFINES(EGLBoolean, Draw, EGLDisplay dpy, EGLSurface surface) {
    draw_call_count++;
    if (draw_call_count <= 3) LOGF("Draw: called #%d", draw_call_count);

    eglQuerySurface(dpy, surface, EGL_WIDTH, &Width);
    eglQuerySurface(dpy, surface, EGL_HEIGHT, &Height);
    if (draw_call_count <= 3) LOGF("Draw: W=%d H=%d", Width, Height);

    if (Width <= 0 || Height <= 0) return _Draw(dpy, surface);

    screenCenter = Vector2(Width / 2, Height / 2);

    if (!bImguiSetup) {
        LOGF("Draw: calling SetupImgui");
        SetupImgui();
        LOGF("Draw: SetupImgui returned, bImguiSetup=%d", bImguiSetup);
    }

    ImGuiIO& io = ImGui::GetIO();

    io.DisplaySize = ImVec2((float)Width, (float)Height);
    static double lastTime = 0.0;
    double currentTime = (double)std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::steady_clock::now().time_since_epoch()).count() / 1000.0;
    io.DeltaTime = lastTime > 0.0 ? (float)(currentTime - lastTime) : 1.0f / 60.0f;
    lastTime = currentTime;

    ImGui_ProcessPendingTouch();

    ImGui_ImplOpenGL3_NewFrame();
    ImGui::NewFrame();

    if (IsExpired()) {
        DrawExpired(io);
    } else if (NovaEngine_IsLoggedIn()) {
        DrawMenu(io);

        DrawFloatingButton(io);
        DrawToggleButton(persistent_bool[O("bAutoQueue")]);

{
    SetNextWindowPos(ImVec2(Width * 0.5f, Height - 60.0f), ImGuiCond_Always, ImVec2(0.5f, 1.0f));

    Begin(O("##PoweredBy"), nullptr,
          ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize |
          ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoScrollbar |
          ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_AlwaysAutoResize |
          ImGuiWindowFlags_NoInputs);

    TextColored(ImColor(255, 215, 0, 255), O("Dragon Engine  |  t.me/DragonEngineOfficial"));

    End();
}

        if (g_autoPlayCalculating) DrawCalculating(io);
    } else {
        DrawLogin(io);
    }
    ImGui::EndFrame();
    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    ImGui_ClearHoverEffect();

    return _Draw(dpy, surface);
}

void __IMGUI__() {
    create_directory_recursive(CONC(O("/data/user_de/0/"), PACKAGE_NAME.c_str(), O("/no_backup")));
}
