// Created By @GoToHellxD | @HwMods
// Base64: Q3JlYXRlZCBCeSBAR29Ub0hlbGx4RA==
#include <atomic>
#include <cstring>
#include <dlfcn.h>
#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <jni.h>
#include <mutex>
#include <pthread.h>
#include <string>
#include <unistd.h>

#include "Includes/Logger.h"
#include "Includes/obfuscate.h"
#include "Includes/Utils.h"
#include <And64InlineHook/And64InlineHook.hpp>

#include "name.h"
#include "HwModsApi.h"
#include "Menu.h"

#include "ImGui/imgui.h"
#include "ImGui/backends/imgui_impl_android.h"
#include "ImGui/backends/imgui_impl_opengl3.h"

namespace {

static std::mutex g_CoreMutex;
static CrmCoreCallbacks g_Core{};
static bool g_CoreLoaded = false;

static double HostGetTime() {
    return ImGui::GetTime();
}
static int HostIsMouseClicked(int button) {
    return (ImGui::GetCurrentContext() && ImGui::IsMouseClicked(button)) ? 1 : 0;
}
static int HostWantCaptureMouse() {
    return (ImGui::GetCurrentContext() && ImGui::GetIO().WantCaptureMouse) ? 1 : 0;
}
static void HostAddLine(float x1, float y1, float x2, float y2, uint32_t col, float thickness) {
    if (ImDrawList* draw = ImGui::GetForegroundDrawList()) {
        draw->AddLine(ImVec2(x1, y1), ImVec2(x2, y2), col, thickness);
    }
}
static void HostAddCircle(float cx, float cy, float radius, uint32_t col, int segments, float thickness) {
    if (ImDrawList* draw = ImGui::GetForegroundDrawList()) {
        draw->AddCircle(ImVec2(cx, cy), radius, col, segments, thickness);
    }
}
static void HostAddCircleFilled(float cx, float cy, float radius, uint32_t col, int segments) {
    if (ImDrawList* draw = ImGui::GetForegroundDrawList()) {
        draw->AddCircleFilled(ImVec2(cx, cy), radius, col, segments);
    }
}
static void HostAddRectFilled(float x1, float y1, float x2, float y2, uint32_t col, float rounding) {
    if (ImDrawList* draw = ImGui::GetForegroundDrawList()) {
        draw->AddRectFilled(ImVec2(x1, y1), ImVec2(x2, y2), col, rounding);
    }
}
static void HostAddRect(float x1, float y1, float x2, float y2, uint32_t col, float rounding, float thickness) {
    if (ImDrawList* draw = ImGui::GetForegroundDrawList()) {
        draw->AddRect(ImVec2(x1, y1), ImVec2(x2, y2), col, rounding, 0, thickness);
    }
}
static void HostAddText(float x, float y, uint32_t col, const char* text) {
    if (!text) return;
    if (ImDrawList* draw = ImGui::GetForegroundDrawList()) {
        draw->AddText(ImVec2(x, y), col, text);
    }
}
static void HostCalcTextSize(const char* text, float* outW, float* outH) {
    ImVec2 sz = (text && ImGui::GetCurrentContext()) ? ImGui::CalcTextSize(text) : ImVec2(0, 0);
    if (outW) *outW = sz.x;
    if (outH) *outH = sz.y;
}

static bool EnsureCoreBootstrapped() {
    std::lock_guard<std::mutex> lock(g_CoreMutex);
    if (g_CoreLoaded && g_Core.initialized) return true;

    void* handle = dlopen(OBFUSCATE("libHwMods.so"), RTLD_NOW | RTLD_NOLOAD);
    if (!handle) {
        handle = dlopen(OBFUSCATE("libHwMods.so"), RTLD_NOW);
    }
    if (!handle) {
        Dl_info selfInfo{};
        if (dladdr(reinterpret_cast<const void*>(&EnsureCoreBootstrapped), &selfInfo) && selfInfo.dli_fname) {
            std::string path(selfInfo.dli_fname);
            const size_t slash = path.find_last_of('/');
            if (slash != std::string::npos) {
                std::string sibling = path.substr(0, slash + 1) + static_cast<const char*>(OBFUSCATE("libHwMods.so"));
                handle = dlopen(sibling.c_str(), RTLD_NOW);
            }
        }
    }
    if (!handle) {
        LOGE(OBFUSCATE("libCrash: failed to open libHwMods.so: %s"), dlerror());
        return false;
    }

    using BootstrapFn = int (*)(const CrmPublicConfig*, const CrmDrawHost*, CrmCoreCallbacks*);
    BootstrapFn bootstrap = reinterpret_cast<BootstrapFn>(dlsym(handle, OBFUSCATE("hwm_bootstrap")));
    if (!bootstrap) {
        bootstrap = &hwm_bootstrap;
    }

    CrmPublicConfig cfg{};
    cfg.structSize = sizeof(CrmPublicConfig);
    cfg.abiVersion = HWM_ABI_VERSION;
    cfg.loginEnabled = MOD_LOGIN_ENABLED ? 1 : 0;
    cfg.modName = MOD_NAME;
    cfg.modSubtitle = MOD_SUBTITLE;
    cfg.modCredit = MOD_CREDIT;
    cfg.modStatusFree = MOD_FREE_STATUS;
    cfg.modFreeExpiry = MOD_FREE_EXPIRY_TEXT;
    cfg.panelUrl = MOD_PANEL_URL;
    cfg.panelGame = MOD_PANEL_GAME;
    cfg.panelSalt = MOD_PANEL_SALT;
    cfg.paramGame = MOD_PANEL_PARAM_GAME;
    cfg.paramKey = MOD_PANEL_PARAM_KEY;
    cfg.paramSerial = MOD_PANEL_PARAM_SERIAL;
    cfg.extraParams = MOD_PANEL_EXTRA_PARAMS;
    cfg.gameLibrary = MOD_TARGET_GAME_LIB;

    CrmDrawHost host{};
    host.structSize = sizeof(CrmDrawHost);
    host.getTime = &HostGetTime;
    host.isMouseClicked = &HostIsMouseClicked;
    host.wantCaptureMouse = &HostWantCaptureMouse;
    host.addLine = &HostAddLine;
    host.addCircle = &HostAddCircle;
    host.addCircleFilled = &HostAddCircleFilled;
    host.addRectFilled = &HostAddRectFilled;
    host.addRect = &HostAddRect;
    host.addText = &HostAddText;
    host.calcTextSize = &HostCalcTextSize;

    CrmCoreCallbacks cb{};
    cb.structSize = sizeof(CrmCoreCallbacks);
    if (!bootstrap(&cfg, &host, &cb) || !cb.initialized) {
        LOGE(OBFUSCATE("libCrash: hwm_bootstrap rejected module"));
        return false;
    }
    g_Core = cb;
    g_CoreLoaded = true;
    return true;
}

static std::string s_RealHardwareID;
static std::mutex s_DeviceIdMutex;

static std::string getDeviceHWID(JNIEnv* env, jobject context) {
    std::lock_guard<std::mutex> lock(s_DeviceIdMutex);
    if (!env || !context || env->ExceptionCheck()) return "";
    if (!s_RealHardwareID.empty()) return s_RealHardwareID;
    jclass contextClass = env->GetObjectClass(context);
    if (!contextClass) return "";
    jmethodID resolverMethod = env->GetMethodID(contextClass, "getContentResolver", "()Landroid/content/ContentResolver;");
    if (!resolverMethod) return "";
    jobject resolver = env->CallObjectMethod(context, resolverMethod);
    if (env->ExceptionCheck() || !resolver) return "";
    jclass secure = env->FindClass("android/provider/Settings$Secure");
    if (!secure) return "";
    jmethodID getter = env->GetStaticMethodID(secure, "getString", "(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;");
    if (!getter) return "";
    jstring name = env->NewStringUTF("android_id");
    if (!name) return "";
    jstring id = (jstring)env->CallStaticObjectMethod(secure, getter, resolver, name);
    if (env->ExceptionCheck()) {
        env->ExceptionClear();
        id = nullptr;
    }
    if (id && env->GetStringLength(id) >= 8 && env->GetStringLength(id) <= 128 &&
        env->GetStringUTFLength(id) <= 128) {
        const char* chars = env->GetStringUTFChars(id, nullptr);
        if (chars) {
            s_RealHardwareID = chars;
            env->ReleaseStringUTFChars(id, chars);
            return s_RealHardwareID;
        }
    }
    jclass buildCls = env->FindClass("android/os/Build");
    if (buildCls) {
        auto readBuildField = [&](const char* fieldName) -> std::string {
            jfieldID fid = env->GetStaticFieldID(buildCls, fieldName, "Ljava/lang/String;");
            if (!fid || env->ExceptionCheck()) {
                if (env->ExceptionCheck()) env->ExceptionClear();
                return "";
            }
            jstring val = (jstring)env->GetStaticObjectField(buildCls, fid);
            if (!val || env->ExceptionCheck()) {
                if (env->ExceptionCheck()) env->ExceptionClear();
                return "";
            }
            const char* cstr = env->GetStringUTFChars(val, nullptr);
            std::string out = cstr ? cstr : "";
            if (cstr) env->ReleaseStringUTFChars(val, cstr);
            env->DeleteLocalRef(val);
            return out;
        };
        std::string rawFallback = readBuildField("BRAND") + "-" + readBuildField("MODEL") + "-" +
                                  readBuildField("BOARD") + "-" + readBuildField("HARDWARE");
        env->DeleteLocalRef(buildCls);
        std::string sanitized;
        sanitized.reserve(rawFallback.size());
        for (unsigned char c : rawFallback) {
            if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
                (c >= '0' && c <= '9') || c == '_' || c == '-') {
                sanitized.push_back(static_cast<char>(c));
            } else {
                sanitized.push_back('-');
            }
        }
        if (sanitized.size() < 8) sanitized += "-evdevice";
        if (!sanitized.empty() && sanitized != "---") {
            s_RealHardwareID = sanitized.substr(0, 128);
            return s_RealHardwareID;
        }
    } else if (env->ExceptionCheck()) {
        env->ExceptionClear();
    }
    return "";
}

static std::string getAppVersionName(JNIEnv* env, jobject context) {
    if (!env || !context) return "";
    jclass contextClass = env->GetObjectClass(context);
    if (!contextClass) return "";
    jmethodID getPackageName = env->GetMethodID(contextClass, "getPackageName", "()Ljava/lang/String;");
    jmethodID getPackageManager = env->GetMethodID(contextClass, "getPackageManager", "()Landroid/content/pm/PackageManager;");
    if (!getPackageName || !getPackageManager) return "";
    jstring pkgName = (jstring)env->CallObjectMethod(context, getPackageName);
    jobject pm = env->CallObjectMethod(context, getPackageManager);
    if (env->ExceptionCheck() || !pkgName || !pm) {
        if (env->ExceptionCheck()) env->ExceptionClear();
        return "";
    }
    jclass pmClass = env->GetObjectClass(pm);
    jmethodID getPackageInfo = env->GetMethodID(pmClass, "getPackageInfo", "(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;");
    if (!getPackageInfo) return "";
    jobject pkgInfo = env->CallObjectMethod(pm, getPackageInfo, pkgName, 0);
    if (env->ExceptionCheck() || !pkgInfo) {
        if (env->ExceptionCheck()) env->ExceptionClear();
        return "";
    }
    jclass piClass = env->GetObjectClass(pkgInfo);
    jfieldID versionNameField = env->GetFieldID(piClass, "versionName", "Ljava/lang/String;");
    if (!versionNameField) return "";
    jstring versionName = (jstring)env->GetObjectField(pkgInfo, versionNameField);
    if (!versionName) return "";
    const char* chars = env->GetStringUTFChars(versionName, nullptr);
    std::string ver = chars ? chars : "";
    if (chars) env->ReleaseStringUTFChars(versionName, chars);
    return ver;
}

static jstring AuthLabel(JNIEnv* env, const std::string& text) {
    jclass cls = env->FindClass("java/lang/String");
    if (!cls) return nullptr;
    jmethodID ctor = env->GetMethodID(cls, "<init>", "([BLjava/lang/String;)V");
    if (!ctor) { env->DeleteLocalRef(cls); return nullptr; }
    jbyteArray bytes = env->NewByteArray((jsize)text.size());
    if (!bytes) { env->DeleteLocalRef(cls); return nullptr; }
    jstring charset = env->NewStringUTF("UTF-8");
    jstring result = nullptr;
    if (ctor && bytes && charset && !env->ExceptionCheck()) {
        env->SetByteArrayRegion(bytes, 0, (jsize)text.size(), reinterpret_cast<const jbyte*>(text.data()));
        if (!env->ExceptionCheck()) result = (jstring)env->NewObject(cls, ctor, bytes, charset);
    }
    env->DeleteLocalRef(bytes);
    env->DeleteLocalRef(charset);
    env->DeleteLocalRef(cls);
    return result;
}

static jstring CheckCrmKey(JNIEnv* env, jobject context, jstring userKey, bool renewal) {
    if (!EnsureCoreBootstrapped() || !g_Core.prepareAuth || !g_Core.finishAuth) {
        return AuthLabel(env, "ERR|AUTH_LIB: Core module libHwMods.so unavailable.");
    }
    if (!MOD_LOGIN_ENABLED) {
        return env->NewStringUTF("OK|");
    }

    std::string license;
    if (!renewal && userKey && env->GetStringLength(userKey) > 0 &&
        env->GetStringLength(userKey) <= 64 && env->GetStringUTFLength(userKey) <= 64) {
        const char* chars = env->GetStringUTFChars(userKey, nullptr);
        if (chars) {
            license = chars;
            env->ReleaseStringUTFChars(userKey, chars);
        }
    }
    const std::string device = getDeviceHWID(env, context);
    const std::string version = getAppVersionName(env, context);

    char wireBuf[4096]{};
    char errBuf[512]{};
    uint64_t attemptTok = 0;
    if (!g_Core.prepareAuth(license.c_str(), device.c_str(), version.c_str(),
                            renewal ? 1 : 0, wireBuf, sizeof(wireBuf),
                            errBuf, sizeof(errBuf), &attemptTok)) {
        std::memset(&license[0], 0, license.size());
        return AuthLabel(env, std::string("ERR|") + (errBuf[0] ? errBuf : "Login rejected"));
    }
    if (!license.empty()) std::memset(&license[0], 0, license.size());

    std::string response;
    std::string transportErr;
    const size_t wireLen = std::strlen(wireBuf);

    if (env->PushLocalFrame(24) == 0) {
        jclass transport = env->FindClass(OBFUSCATE("com/easyvictory/mods/CrmAuth"));
        if (!transport) {
            if (env->ExceptionCheck()) env->ExceptionClear();
            transportErr = "AUTH_TRANSPORT: com/easyvictory/mods/CrmAuth class not found.";
        } else {
            bool twoArgs = true;
            jmethodID exchange = env->GetStaticMethodID(transport, OBFUSCATE("exchange"), OBFUSCATE("(Ljava/lang/String;[B)[B"));
            if (!exchange) {
                env->ExceptionClear();
                exchange = env->GetStaticMethodID(transport, OBFUSCATE("exchange"), OBFUSCATE("([B)[B"));
                twoArgs = false;
            }
            if (!exchange) {
                if (env->ExceptionCheck()) env->ExceptionClear();
                transportErr = "AUTH_TRANSPORT: CrmAuth.exchange method not found.";
            } else {
                jbyteArray request = env->NewByteArray((jsize)wireLen);
                jstring endpointUrl = env->NewStringUTF(OBFUSCATE(MOD_PANEL_URL));
                if (request && endpointUrl) {
                    env->SetByteArrayRegion(request, 0, (jsize)wireLen, reinterpret_cast<const jbyte*>(wireBuf));
                    jbyteArray reply = nullptr;
                    if (!env->ExceptionCheck()) {
                        reply = twoArgs
                                ? (jbyteArray)env->CallStaticObjectMethod(transport, exchange, endpointUrl, request)
                                : (jbyteArray)env->CallStaticObjectMethod(transport, exchange, request);
                    }
                    if (env->ExceptionCheck()) {
                        jthrowable ex = env->ExceptionOccurred();
                        env->ExceptionClear();
                        jclass exClass = env->GetObjectClass(ex);
                        jmethodID getMsg = env->GetMethodID(exClass, "toString", "()Ljava/lang/String;");
                        jstring msgStr = (jstring)env->CallObjectMethod(ex, getMsg);
                        if (msgStr) {
                            const char* cStr = env->GetStringUTFChars(msgStr, nullptr);
                            if (cStr) {
                                transportErr = std::string("AUTH_JAVA_EX: ") + cStr;
                                env->ReleaseStringUTFChars(msgStr, cStr);
                            }
                            env->DeleteLocalRef(msgStr);
                        }
                        env->DeleteLocalRef(exClass);
                        env->DeleteLocalRef(ex);
                    } else if (reply) {
                        const jsize size = env->GetArrayLength(reply);
                        if (size > 0 && size <= 16384) {
                            response.resize(size);
                            env->GetByteArrayRegion(reply, 0, size, reinterpret_cast<jbyte*>(&response[0]));
                        }
                    }
                }
                if (endpointUrl) env->DeleteLocalRef(endpointUrl);
                if (request) env->DeleteLocalRef(request);
            }
            env->DeleteLocalRef(transport);
        }
        if (env->ExceptionCheck()) {
            env->ExceptionClear();
            response.clear();
        }
        env->PopLocalFrame(nullptr);
    }

    char finishErr[512]{};
    const int finished = g_Core.finishAuth(
        attemptTok, response.data(), response.size(),
        renewal ? 1 : 0, finishErr, sizeof(finishErr));

    if (finished) {
        if (!response.empty()) std::memset(&response[0], 0, response.size());
        return env->NewStringUTF("OK|");
    }

    std::string error = finishErr[0] ? std::string(finishErr) : std::string("AUTH_RESPONSE: Invalid response.");
    if (response == "E:AUTH_ENDPOINT") error = "AUTH_ENDPOINT: CRM secure login endpoint unavailable.";
    else if (response == "E:AUTH_REDIRECT") error = "AUTH_REDIRECT: Login endpoint must not redirect.";
    else if (response == "E:AUTH_RATE") error = "AUTH_RATE: Wait one minute before retrying.";
    else if (response == "E:AUTH_BUSY") error = "AUTH_BUSY: A login connection is still closing. Please retry shortly.";
    else if (response == "E:AUTH_SERVER") error = "AUTH_SERVER: Login service unavailable.";
    else if (response == "E:AUTH_REJECTED") error = "AUTH_REJECTED: Check automatic date/time and CRM server setup.";
    else if (response == "E:AUTH_TLS") error = "AUTH_TLS: Certificate verification failed. Check date/time.";
    else if (response == "E:AUTH_DEVICE_KEY") error = "AUTH_DEVICE_KEY: Android 6+ device Keystore required. No insecure fallback.";
    else if (response == "E:AUTH_TIMEOUT") error = "AUTH_TIMEOUT: Login timed out.";
    else if (response == "E:AUTH_DNS" || response == "E:AUTH_NETWORK") error = "AUTH_NETWORK: Cannot reach secure login.";
    else if (response == "E:AUTH_RESPONSE") error = "AUTH_RESPONSE: Server returned empty or invalid response.";
    else if (response.rfind("E:AUTH_ERR:", 0) == 0) error = "AUTH_TRANSPORT_ERR: " + response.substr(11);
    else if (!transportErr.empty() && response.empty()) error = transportErr;

    if (!response.empty()) std::memset(&response[0], 0, response.size());
    jstring res = AuthLabel(env, "ERR|" + error);
    return res ? res : env->NewStringUTF("ERR|Login rejected");
}

static bool g_ImGuiInitialized = false;
static int g_ScreenWidth = 0;
static int g_ScreenHeight = 0;

static void InitImGui() {
    if (g_ImGuiInitialized) return;
    if (eglGetCurrentContext() == EGL_NO_CONTEXT) return;
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;
    io.LogFilename = nullptr;
    ImGui::StyleColorsDark();
    ImGui_ImplOpenGL3_Init("#version 300 es");
    ImGui_ImplAndroid_Init(nullptr);
    g_ImGuiInitialized = true;
}

static EGLBoolean (*old_eglSwapBuffers)(EGLDisplay dpy, EGLSurface surface) = nullptr;
static EGLBoolean hook_eglSwapBuffers(EGLDisplay dpy, EGLSurface surface) {
    if (dpy != EGL_NO_DISPLAY && surface != EGL_NO_SURFACE && eglGetCurrentContext() != EGL_NO_CONTEXT) {
        eglQuerySurface(dpy, surface, EGL_WIDTH, &g_ScreenWidth);
        eglQuerySurface(dpy, surface, EGL_HEIGHT, &g_ScreenHeight);
        if (g_ScreenWidth > 0 && g_ScreenHeight > 0) {
            if (!g_ImGuiInitialized) InitImGui();
            if (g_ImGuiInitialized) {
                ImGuiIO& io = ImGui::GetIO();
                io.DisplaySize = ImVec2((float)g_ScreenWidth, (float)g_ScreenHeight);
                io.DisplayFramebufferScale = ImVec2(1.0f, 1.0f);

                ImGui_ImplOpenGL3_NewFrame();
                ImGui_ImplAndroid_NewFrame(g_ScreenWidth, g_ScreenHeight);
                ImGui::NewFrame();

                if (g_CoreLoaded && g_Core.initialized && g_Core.onFrame) {
                    g_Core.onFrame((float)g_ScreenWidth, (float)g_ScreenHeight);
                }

                ImGui::Render();
                ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
            }
        }
    }
    if (old_eglSwapBuffers) {
        return old_eglSwapBuffers(dpy, surface);
    }
    return eglSwapBuffers(dpy, surface);
}

static void* egl_hook_thread(void*) {
    if (EnsureCoreBootstrapped() && g_Core.startHooks) {
        g_Core.startHooks();
    }
    do {
        sleep(1);
    } while (!isLibraryLoaded(OBFUSCATE(MOD_TARGET_GAME_LIB)));

#if defined(__aarch64__) || defined(__arm__)
    void* eglLib = dlopen("libEGL.so", RTLD_NOW);
    void* eglSym = eglLib ? dlsym(eglLib, "eglSwapBuffers") : nullptr;
    if (eglSym) {
        A64HookFunction(eglSym, (void*)hook_eglSwapBuffers, (void**)&old_eglSwapBuffers);
    }
#endif
    return nullptr;
}

static jboolean JniIsGameLibLoaded(JNIEnv*, jobject) {
    return (EnsureCoreBootstrapped() && g_Core.isGameLibLoaded && g_Core.isGameLibLoaded()) ? JNI_TRUE : JNI_FALSE;
}
static jstring JniCheckKey(JNIEnv* env, jobject, jobject context, jstring userKey) {
    return CheckCrmKey(env, context, userKey, false);
}
static jstring JniRenewKey(JNIEnv* env, jobject, jobject context) {
    return CheckCrmKey(env, context, nullptr, true);
}
static jstring JniGetAuthEndpoint(JNIEnv* env, jclass) {
    return env->NewStringUTF(OBFUSCATE(MOD_PANEL_URL));
}
static jboolean JniIsKeyAuthenticated(JNIEnv*, jobject) {
    return (EnsureCoreBootstrapped() && g_Core.isKeyAuthenticated && g_Core.isKeyAuthenticated()) ? JNI_TRUE : JNI_FALSE;
}
static jboolean JniIsLoginEnabled(JNIEnv*, jobject) {
    return MOD_LOGIN_ENABLED ? JNI_TRUE : JNI_FALSE;
}
static void JniSetFreeMode(JNIEnv*, jobject, jboolean freeMode) {
    if (EnsureCoreBootstrapped() && g_Core.setFreeMode) {
        g_Core.setFreeMode(freeMode ? 1 : 0);
    }
}
static jstring JniGetExpiryDate(JNIEnv* env, jobject) {
    char buf[128]{};
    if (EnsureCoreBootstrapped() && g_Core.getInfo) g_Core.getInfo(buf, sizeof(buf), nullptr, 0, nullptr, 0, nullptr, 0);
    return AuthLabel(env, buf[0] ? buf : (!MOD_LOGIN_ENABLED ? MOD_FREE_EXPIRY_TEXT : ""));
}
static jstring JniGetModStatus(JNIEnv* env, jobject) {
    char buf[128]{};
    if (EnsureCoreBootstrapped() && g_Core.getInfo) g_Core.getInfo(nullptr, 0, buf, sizeof(buf), nullptr, 0, nullptr, 0);
    return AuthLabel(env, buf[0] ? buf : MOD_FREE_STATUS);
}
static jstring JniGetModCredit(JNIEnv* env, jobject) {
    char buf[128]{};
    if (EnsureCoreBootstrapped() && g_Core.getInfo) g_Core.getInfo(nullptr, 0, nullptr, 0, buf, sizeof(buf), nullptr, 0);
    return AuthLabel(env, buf[0] ? buf : MOD_CREDIT);
}
static jstring JniGetModName(JNIEnv* env, jobject) {
    char buf[128]{};
    if (EnsureCoreBootstrapped() && g_Core.getInfo) g_Core.getInfo(nullptr, 0, nullptr, 0, nullptr, 0, buf, sizeof(buf));
    return AuthLabel(env, buf[0] ? buf : MOD_NAME);
}
static jstring JniGetModSubtitle(JNIEnv* env, jobject) {
    return AuthLabel(env, OBFUSCATE(MOD_SUBTITLE));
}
static jstring JniGetTelegramHandle(JNIEnv* env, jobject) {
    return AuthLabel(env, OBFUSCATE(MOD_TELEGRAM_HANDLE));
}
static jstring JniGetTelegramUrl(JNIEnv* env, jobject) {
    return AuthLabel(env, OBFUSCATE(MOD_TELEGRAM_CHANNEL));
}
static jstring JniGetBuyKeyUrl(JNIEnv* env, jobject) {
    return AuthLabel(env, OBFUSCATE(MOD_BUY_KEY_URL));
}
static jstring JniGetFreeKeyUrl(JNIEnv* env, jobject) {
    return AuthLabel(env, OBFUSCATE(MOD_FREE_KEY_URL));
}
static jstring JniGetLoginTitle(JNIEnv* env, jobject) {
    return AuthLabel(env, OBFUSCATE(MOD_LOGIN_TITLE));
}
static jstring JniGetLoginBanner(JNIEnv* env, jobject) {
    return AuthLabel(env, OBFUSCATE(MOD_LOGIN_BANNER));
}
static jstring JniGetStatusBadge(JNIEnv* env, jobject) {
    return AuthLabel(env, MOD_LOGIN_ENABLED ? OBFUSCATE(MOD_STATUS_BADGE_ONLINE) : OBFUSCATE(MOD_STATUS_BADGE_FREE));
}

static jobjectArray JniGetFeatureList(JNIEnv* env, jobject context) {
    MakeToast(env, context, OBFUSCATE(MOD_LOADED_TOAST), Toast::LENGTH_LONG);
    const char* features[] = {
        OBFUSCATE("Global_19_Toggle_Auto Queue"),
        OBFUSCATE("Tab_Visuals"),
        OBFUSCATE("TabAdd_True_1_Toggle_Show Prediction"),
        OBFUSCATE("TabAdd_True_2_Toggle_Highlight Pockets"),
        OBFUSCATE("TabAdd_True_18_Toggle_Freeze Shot Lines"),
        OBFUSCATE("Tab_Play"),
        OBFUSCATE("TabAdd_True_5_Toggle_Auto Aim Target"),
        OBFUSCATE("TabAdd_13_NativeSpinner_Autoplay_Off,V1 | Fast,V2 | Natural,V3 | 360 Scan"),
        OBFUSCATE("TabAdd_16_NativeSpinner_Clean Table_Off,Own Pucks,Aggressive"),
        OBFUSCATE("TabAdd_14_SeekBar_Scanner Depth_1_5_5"),
        OBFUSCATE("TabAdd_15_SeekBar_Shot Force_5_100_60"),
        OBFUSCATE("Tab_Queue"),
        OBFUSCATE("TabAdd_27_ChoiceGrid_Queue Style_Select style,Fast,Human_1"),
        OBFUSCATE("TabAdd_20_Spinner_Game Mode_Select mode,Disc Pool,Free Style,Carrom Pool"),
        OBFUSCATE("TabAdd_22_ChoiceGrid_Table Price_Select price,200,500,2.6K,4K,5.5K,11K,27K,55K,140K,170K,280K,580K,Highest affordable"),
        OBFUSCATE("TabAdd_22_Status_Status"),
        OBFUSCATE("TabAdd_RichTextView_Matches use coins. Highest affordable may use most of your balance."),
        OBFUSCATE("Tab_Extras"),
        OBFUSCATE("TabAdd_24_ColorGrid_Target Colour_Select colour,Yellow,Red,Cyan_0_#F2D64B,#F26B74,#58D5DA"),
        OBFUSCATE("TabAdd_25_Button_Play Shot"),
        OBFUSCATE("TabAdd_26_Button_Cancel"),
        OBFUSCATE("TabAdd_24_Status_Status"),
        OBFUSCATE("TabAdd_RichTextView_One shot may use one ticket."),
        OBFUSCATE("TabAdd_True_11_Toggle_No Ads"),
    };
    const int total = (int)(sizeof(features) / sizeof(features[0]));
    jobjectArray ret = env->NewObjectArray(total, env->FindClass(OBFUSCATE("java/lang/String")), env->NewStringUTF(""));
    for (int i = 0; i < total; i++) {
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));
    }
    return ret;
}

static void JniChanges(JNIEnv*, jclass, jobject, jint featNum, jstring, jint value, jboolean boolean, jstring) {
    if (EnsureCoreBootstrapped() && g_Core.onChange) {
        g_Core.onChange(featNum, value, boolean ? 1 : 0);
    }
}

static jstring JniGetFeatureStatus(JNIEnv* env, jobject, jint feature) {
    char buf[256]{};
    if (EnsureCoreBootstrapped() && g_Core.getFeatureStatus) {
        g_Core.getFeatureStatus(feature, buf, sizeof(buf));
    }
    return env->NewStringUTF(buf);
}

static jint JniGetFeatureValue(JNIEnv*, jobject, jint feature) {
    if (EnsureCoreBootstrapped() && g_Core.getFeatureValue) {
        return g_Core.getFeatureValue(feature);
    }
    return 0;
}

static void JniStartGameEngine(JNIEnv*, jobject) {
    if (EnsureCoreBootstrapped() && g_Core.startHooks) {
        g_Core.startHooks();
    }
}

} // namespace

__attribute__((constructor))
void lib_main() {
    static std::atomic<bool> started{false};
    if (!started.exchange(true)) {
        pthread_t ptid;
        pthread_create(&ptid, nullptr, egl_hook_thread, nullptr);
    }
}

extern "C" {

JNIEXPORT jstring JNICALL Java_com_easyvictory_mods_CrmAuth_nativeGetAuthEndpoint(JNIEnv* env, jclass) {
    return env->NewStringUTF(OBFUSCATE(MOD_PANEL_URL));
}

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void*) {
    JNIEnv* globalEnv = nullptr;
    if (vm->GetEnv((void**)&globalEnv, JNI_VERSION_1_6) != JNI_OK) return JNI_ERR;

    if (!EnsureCoreBootstrapped()) {
        return JNI_ERR;
    }
    //GoToHellxD | @HwMods
    jclass c = globalEnv->FindClass(OBFUSCATE("com/easyvictory/mods/Menu"));
    if (c != nullptr) {
        static const JNINativeMethod menuMethods[] = {
            {OBFUSCATE("setTitleText"),       OBFUSCATE("(Landroid/widget/TextView;)V"), reinterpret_cast<void*>(setTitleText)},
            {OBFUSCATE("setHeadingText"),     OBFUSCATE("(Landroid/widget/TextView;)V"), reinterpret_cast<void*>(setHeadingText)},
            {OBFUSCATE("Icon"),               OBFUSCATE("()Ljava/lang/String;"),         reinterpret_cast<void*>(Icon)},
            {OBFUSCATE("IconWebViewData"),    OBFUSCATE("()Ljava/lang/String;"),         reinterpret_cast<void*>(IconWebViewData)},
            {OBFUSCATE("getFeatureList"),     OBFUSCATE("()[Ljava/lang/String;"),        reinterpret_cast<void*>(JniGetFeatureList)},
            {OBFUSCATE("getFeatureStatus"),   OBFUSCATE("(I)Ljava/lang/String;"),         reinterpret_cast<void*>(JniGetFeatureStatus)},
            {OBFUSCATE("getFeatureValue"),    OBFUSCATE("(I)I"),                         reinterpret_cast<void*>(JniGetFeatureValue)},
            {OBFUSCATE("settingsList"),       OBFUSCATE("()[Ljava/lang/String;"),        reinterpret_cast<void*>(settingsList)},
            {OBFUSCATE("isGameLibLoaded"),    OBFUSCATE("()Z"),                          reinterpret_cast<void*>(JniIsGameLibLoaded)},
            {OBFUSCATE("nativeCheckKey"),     OBFUSCATE("(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;"), reinterpret_cast<void*>(JniCheckKey)},
            {OBFUSCATE("nativeRenewKey"),     OBFUSCATE("(Landroid/content/Context;)Ljava/lang/String;"), reinterpret_cast<void*>(JniRenewKey)},
            {OBFUSCATE("isKeyAuthenticated"), OBFUSCATE("()Z"),                          reinterpret_cast<void*>(JniIsKeyAuthenticated)},
            {OBFUSCATE("isLoginEnabled"),     OBFUSCATE("()Z"),                          reinterpret_cast<void*>(JniIsLoginEnabled)},
            {OBFUSCATE("getExpiryDate"),      OBFUSCATE("()Ljava/lang/String;"),         reinterpret_cast<void*>(JniGetExpiryDate)},
            {OBFUSCATE("getModStatus"),       OBFUSCATE("()Ljava/lang/String;"),         reinterpret_cast<void*>(JniGetModStatus)},
            {OBFUSCATE("getModCredit"),       OBFUSCATE("()Ljava/lang/String;"),         reinterpret_cast<void*>(JniGetModCredit)},
            {OBFUSCATE("getModName"),         OBFUSCATE("()Ljava/lang/String;"),         reinterpret_cast<void*>(JniGetModName)},
            {OBFUSCATE("getModSubtitle"),     OBFUSCATE("()Ljava/lang/String;"),         reinterpret_cast<void*>(JniGetModSubtitle)},
            {OBFUSCATE("getTelegramHandle"),  OBFUSCATE("()Ljava/lang/String;"),         reinterpret_cast<void*>(JniGetTelegramHandle)},
            {OBFUSCATE("getTelegramUrl"),     OBFUSCATE("()Ljava/lang/String;"),         reinterpret_cast<void*>(JniGetTelegramUrl)},
            {OBFUSCATE("getBuyKeyUrl"),       OBFUSCATE("()Ljava/lang/String;"),         reinterpret_cast<void*>(JniGetBuyKeyUrl)},
            {OBFUSCATE("getFreeKeyUrl"),      OBFUSCATE("()Ljava/lang/String;"),         reinterpret_cast<void*>(JniGetFreeKeyUrl)},
            {OBFUSCATE("getLoginTitle"),      OBFUSCATE("()Ljava/lang/String;"),         reinterpret_cast<void*>(JniGetLoginTitle)},
            {OBFUSCATE("getLoginBanner"),     OBFUSCATE("()Ljava/lang/String;"),         reinterpret_cast<void*>(JniGetLoginBanner)},
            {OBFUSCATE("getStatusBadge"),     OBFUSCATE("()Ljava/lang/String;"),         reinterpret_cast<void*>(JniGetStatusBadge)},
            {OBFUSCATE("nativeSetFreeMode"),  OBFUSCATE("(Z)V"),                         reinterpret_cast<void*>(JniSetFreeMode)},
        };
        if (globalEnv->RegisterNatives(c, menuMethods, sizeof(menuMethods) / sizeof(JNINativeMethod)) != JNI_OK) return JNI_ERR;
        globalEnv->DeleteLocalRef(c);
    } else return JNI_ERR;

    jclass pref = globalEnv->FindClass(OBFUSCATE("com/easyvictory/mods/Preferences"));
    if (pref != nullptr) {
        static const JNINativeMethod prefMethods[] = {
            {OBFUSCATE("Changes"), OBFUSCATE("(Landroid/content/Context;ILjava/lang/String;IZLjava/lang/String;)V"), reinterpret_cast<void*>(JniChanges)},
        };
        if (globalEnv->RegisterNatives(pref, prefMethods, sizeof(prefMethods) / sizeof(JNINativeMethod)) != JNI_OK) return JNI_ERR;
        globalEnv->DeleteLocalRef(pref);
    } else return JNI_ERR;

    jclass authCls = globalEnv->FindClass(OBFUSCATE("com/easyvictory/mods/CrmAuth"));
    if (authCls != nullptr) {
        static const JNINativeMethod authMethods[] = {
            {OBFUSCATE("nativeGetAuthEndpoint"), OBFUSCATE("()Ljava/lang/String;"), reinterpret_cast<void*>(JniGetAuthEndpoint)},
        };
        if (globalEnv->RegisterNatives(authCls, authMethods, sizeof(authMethods) / sizeof(JNINativeMethod)) != JNI_OK) {
            globalEnv->ExceptionClear();
        }
        globalEnv->DeleteLocalRef(authCls);
    } else {
        globalEnv->ExceptionClear();
    }

    jclass bridgeCls = globalEnv->FindClass(OBFUSCATE("com/easyvictory/mods/CrmExternalMenu$Bridge"));
    if (bridgeCls != nullptr) {
        static const JNINativeMethod bridgeMethods[] = {
            {OBFUSCATE("nativeStartGameEngine"), OBFUSCATE("()V"),                       reinterpret_cast<void*>(JniStartGameEngine)},
            {OBFUSCATE("setTitleText"),          OBFUSCATE("(Landroid/widget/TextView;)V"), reinterpret_cast<void*>(setTitleText)},
            {OBFUSCATE("setHeadingText"),        OBFUSCATE("(Landroid/widget/TextView;)V"), reinterpret_cast<void*>(setHeadingText)},
            {OBFUSCATE("Icon"),                  OBFUSCATE("()Ljava/lang/String;"),         reinterpret_cast<void*>(Icon)},
            {OBFUSCATE("IconWebViewData"),       OBFUSCATE("()Ljava/lang/String;"),         reinterpret_cast<void*>(IconWebViewData)},
            {OBFUSCATE("getFeatureList"),        OBFUSCATE("()[Ljava/lang/String;"),        reinterpret_cast<void*>(JniGetFeatureList)},
            {OBFUSCATE("settingsList"),          OBFUSCATE("()[Ljava/lang/String;"),        reinterpret_cast<void*>(settingsList)},
            {OBFUSCATE("getFeatureStatus"),      OBFUSCATE("(I)Ljava/lang/String;"),         reinterpret_cast<void*>(JniGetFeatureStatus)},
            {OBFUSCATE("getFeatureValue"),       OBFUSCATE("(I)I"),                         reinterpret_cast<void*>(JniGetFeatureValue)},
            {OBFUSCATE("isGameLibLoaded"),       OBFUSCATE("()Z"),                          reinterpret_cast<void*>(JniIsGameLibLoaded)},
            {OBFUSCATE("nativeCheckKey"),        OBFUSCATE("(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;"), reinterpret_cast<void*>(JniCheckKey)},
            {OBFUSCATE("nativeRenewKey"),        OBFUSCATE("(Landroid/content/Context;)Ljava/lang/String;"), reinterpret_cast<void*>(JniRenewKey)},
            {OBFUSCATE("isKeyAuthenticated"),    OBFUSCATE("()Z"),                          reinterpret_cast<void*>(JniIsKeyAuthenticated)},
            {OBFUSCATE("isLoginEnabled"),        OBFUSCATE("()Z"),                          reinterpret_cast<void*>(JniIsLoginEnabled)},
            {OBFUSCATE("getExpiryDate"),         OBFUSCATE("()Ljava/lang/String;"),         reinterpret_cast<void*>(JniGetExpiryDate)},
            {OBFUSCATE("getModStatus"),          OBFUSCATE("()Ljava/lang/String;"),         reinterpret_cast<void*>(JniGetModStatus)},
            {OBFUSCATE("getModCredit"),          OBFUSCATE("()Ljava/lang/String;"),         reinterpret_cast<void*>(JniGetModCredit)},
            {OBFUSCATE("getModName"),            OBFUSCATE("()Ljava/lang/String;"),         reinterpret_cast<void*>(JniGetModName)},
            {OBFUSCATE("getModSubtitle"),        OBFUSCATE("()Ljava/lang/String;"),         reinterpret_cast<void*>(JniGetModSubtitle)},
            {OBFUSCATE("getTelegramHandle"),     OBFUSCATE("()Ljava/lang/String;"),         reinterpret_cast<void*>(JniGetTelegramHandle)},
            {OBFUSCATE("getTelegramUrl"),        OBFUSCATE("()Ljava/lang/String;"),         reinterpret_cast<void*>(JniGetTelegramUrl)},
            {OBFUSCATE("getBuyKeyUrl"),          OBFUSCATE("()Ljava/lang/String;"),         reinterpret_cast<void*>(JniGetBuyKeyUrl)},
            {OBFUSCATE("getFreeKeyUrl"),         OBFUSCATE("()Ljava/lang/String;"),         reinterpret_cast<void*>(JniGetFreeKeyUrl)},
            {OBFUSCATE("getLoginTitle"),         OBFUSCATE("()Ljava/lang/String;"),         reinterpret_cast<void*>(JniGetLoginTitle)},
            {OBFUSCATE("getLoginBanner"),        OBFUSCATE("()Ljava/lang/String;"),         reinterpret_cast<void*>(JniGetLoginBanner)},
            {OBFUSCATE("getStatusBadge"),        OBFUSCATE("()Ljava/lang/String;"),         reinterpret_cast<void*>(JniGetStatusBadge)},
            {OBFUSCATE("nativeSetFreeMode"),     OBFUSCATE("(Z)V"),                         reinterpret_cast<void*>(JniSetFreeMode)},
            {OBFUSCATE("Changes"),               OBFUSCATE("(Landroid/content/Context;ILjava/lang/String;IZLjava/lang/String;)V"), reinterpret_cast<void*>(JniChanges)},
        };
        if (globalEnv->RegisterNatives(bridgeCls, bridgeMethods, sizeof(bridgeMethods) / sizeof(JNINativeMethod)) != JNI_OK) {
            globalEnv->ExceptionClear();
        }
        globalEnv->DeleteLocalRef(bridgeCls);
    } else {
        globalEnv->ExceptionClear();
    }

    return JNI_VERSION_1_6;
}

} // extern "C"
