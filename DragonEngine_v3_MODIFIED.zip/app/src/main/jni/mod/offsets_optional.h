// Optional game offsets. They are NOT known in this source tree, so they default to 0 (= feature unavailable).
// Fill a value (offset inside libgame-CARROM*.so) and the matching feature turns on automatically; the Tool tab
// shows "needs game offset" for every feature whose offset is still 0.
#pragma once
#include <atomic>

#ifndef NOAD_HOOK1_OFFSET
#define NOAD_HOOK1_OFFSET 0x0      // ad request #1 (sets result+0x30 = 0)
#endif
#ifndef NOAD_HOOK2_OFFSET
#define NOAD_HOOK2_OFFSET 0x0      // ad request #2 (sets result+0x18 = 1)
#endif
#ifndef SKIN_INDEX_OFFSET
#define SKIN_INDEX_OFFSET 0x0      // skin index field inside UserSettingsManager
#endif

static const bool kAdsAvailable  = (NOAD_HOOK1_OFFSET != 0) || (NOAD_HOOK2_OFFSET != 0);
static const bool kSkinAvailable = (SKIN_INDEX_OFFSET != 0);
static std::atomic<bool> g_noAdsOn{false};     // set every frame from the Tool tab toggle AND the login gate
